<template>
    <header>
    	<div class="sm-header font">
    <!--  *********************导航栏第一部分******************* --> 
            <div class="header-tab">
                <div class="header-top">
                    <div class="header-right">
                        <span>在线时间08:30~21:30</span>
                        <span>欢迎访问数码家电在线商城！</span>
                    </div>
                    <div class="header-left">
                        <div class="header-left-1">
                            <router-link to="/login">登录</router-link>
                            <router-link to="/register">注册</router-link>
                        </div>
                        <div class="header-left-2" id="shop-car" @mouseover="disBlock" @mouseout="disNone">
                            <div class="left-2">
                                <a href="" target="-blank">
                                    <img src="../assets/img/headfoot/shop_car.png">
                                </a>
                            </div>
                            
                            <div class="header-shop" :style="dis">
                                <ul>
                                    <li>购物车里没有商品</li>
                                </ul>
                            </div>
                        </div>   
                    </div>
                </div>   
            </div>
   <!--  **********************导航栏第二部分****************** -->
    		<div class="header-navbar" id="totop">
                <div class="header-nav1" :class="logo">
                    <div class="md-img">
                        <div class="md-img1">
                            <a href="javacript:;" class="navbar-brand">
                                <img :src="i==true?src2[0]:src2[1]" @mouseover="img" @mouseout="imgs" @click="change()">
                            </a>
                        </div>
                        <div class="md-img3">
                            <a href="index.html" target="_blank" class="navbar-brand">
                                <img src="../assets/img/headfoot/login.png"/>
                            </a>
                        </div>
                        <div class="md-img2">
                            <a href="javacript:;" class="navbar-brand">
                                <img :src="j==true?src1[0]:src1[1]" @mouseover="img1" @mouseout="img1s" @click="change1()">
                            </a>
                        </div>
                    </div>
                </div>  
                <div class="header-nav">
                    <!-- <div class="nav-left" :style="log"> -->
                    <div class="nav-left">
                        <a href="index.html" target="-blank" class="navbar-brand">
                            <img src="../assets/img/headfoot/login.png"/>
                        </a>
                    </div>
                    <div id="content" :class="navbar">
                    	<ul class="navbar-nav">
                    		<!-- <li class="n-item">
                                <router-link to="/" :class="cols1" @click.native="show1">首页</router-link>
                    		</li>
                            <li class="n-item">
                                <router-link to="/ProductLaptop" :class="cols2" @click.native="show2">笔记本</router-link>
                            </li>
                            <li class="n-item">
                                <router-link to="/ProductDesktop" :class="cols3" @click.native="show3">台式机</router-link>
                            </li>
                            <li class="n-item">
                                <router-link to="/ProductPreip" :class="cols4" @click.native="show4">外设系列</router-link>
                            </li>
                            <li class="n-item">
                                <router-link to="/Evaluating" :class="cols5" @click.native="show5">评测中心</router-link>
                            </li>
                            <li class="n-item">
                                <router-link to="/AfterSales" :class="cols6" @click.native="show6">售后服务</router-link>
                            </li> -->
                            <!-- <li class="n-item">
                            	<a href="javascript:;" :class="cols?selectColor:nativeColor" @click="show(0)">首页</a> -->
                            <li class="n-item">
                               <a href="javascript:;"  @click="show(0)">首页</a>
                            </li>
                    		<li class="n-item">
                    			<a href="javascript:;"  @click="show(1)">笔记本</a>
                    		</li>
                    		<li class="n-item">
                    			<a href="javascript:;"  @click="show(2)">台式机</a>
                    		</li>
                    		<li class="n-item">
                    			<a href="javascript:;" @click="show(3)">外系系列</a>
                    		</li>
                    		<li class="n-item">
                    			<a href="javascript:;"  @click="show(4)">评测中心</a>
                    		</li>
                    		<li class="n-item">
                    			<a href="javascript:;"  @click="show(5)">售后服务</a>
                    		</li>
                    	</ul>
                    </div>
                    <!-- <div class="nav-right" :style="inpu"> -->
                    <div class="nav-right">
                    	<input type="text" name="" id="" value="" placeholder="游戏笔记本">
                    </div>
                </div>
    		</div>
            <!-- <!********************侧边导航栏************************* -->
            <div id="aside-nav">
                <div :class="aside" @mouseover="aside2" @mouseout="aside3">
                    <div class="">
                        <img src="../assets/img/headfoot/phone.png" >
                    </div>
                    <div class="">
                        <span>4006-999-999</span>
                    </div>  
                </div>
                <div class="aside2">
                    <img src="../assets/img/headfoot/dangao.png" >
                </div>
                <div class="aside3">
                    <a href="#">
                        <img src="../assets/img/headfoot/backtop1.png" >
                    </a> 
                </div>
            </div>
            
    <!-- <!在中屏时，点击md-img1下的图标，出现的显示页面************************* -->
            <div class="md-all" id="aside">
                <div class="all-left" :class="leftA">
                    <div class="all-left1">
                        <div class="left-log">
                            <router-link to="/login">登录</router-link>
                        </div>
                        <div class="left-reg">
                           <router-link to="/register">注册</router-link>
                        </div>
                    </div>
                    <div class="all-left2">
                        <img src="../assets/img/headfoot/login.png" >
                    </div>
                    <div class="all-left3">
                        <ul class="all-nav">
                        	<li class="n-item">
                        	    <router-link to="/" >首页</router-link>
                        	</li>
                        	<li class="n-item">
                        	    <router-link to="/product/laptop" >笔记本</router-link>
                        	</li>
                        	<li class="n-item">
                        	    <router-link to="/product/desktop" >台式机</router-link>
                        	</li>
                        	<li class="n-item">
                        	    <router-link to="/product/preip" >外设系列</router-link>
                        	</li>
                        	<li class="n-item">
                        	    <router-link to="/evaluating">评测中心</router-link>
                        	</li>
                        	<li class="n-item">
                        	    <router-link to="/aftersales">售后服务</router-link>
                        	</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- <! 当点击搜索按钮，出现搜索框 --> 
            <div class="search" id="sbtn">
                <div :class="searchs" >
                    <div class="search1">
                        <p>搜索</p>
                    </div>
                    <div class="search2">
                        <input type="text" name="" placeholder="请输入关键字">
                    </div>
                    <div class="search3">
                        <button type="button">确认</button>
                        <button type="button" @click="trans1()">取消</button>
                    </div>
                </div>
            </div>
            
    <!-- **************整个屏幕透明************************************************* -->
            <div  id="tran1" :class="tran" @click="trans()"></div>
            <div  id="tran2" :class="tran1"></div>
            <!-- <! 当页面滚动到底部时，会出现回到顶部标志 --> 
            <div class="scorll-top" v-if="btnFlag">
                <a href="#" class="top2"></a>
            </div>
    	</div>
    </header>
</template>

<script>
   export default{
       data(){
           return{
               i:true,j:true,
               // 鼠标移入切换图标
               src1:[
                  require('../assets/img/headfoot/search1.png'),
                  require('../assets/img/headfoot/search2.png'),
               ],
               src2:[
                  require('../assets/img/headfoot/jihe1.png'),
                  require('../assets/img/headfoot/jihe2.png'),
               ],
               dis:{display:"none"},
               // 右侧固定导航栏
               aside:{
                   aside1:true,
                   aside1s:false
               },
               tran:{all:false},
               tran1:{all:false},
               // 集合
               leftA:{
                   all_left:true,
                   all_lefts:false
               },
               // 搜索      
               searchs:{
                   search_nav1:true,
                   search_nav:false
               },
               // 导航栏下部分首页等标题样式
               cols:false,
               // cols:[
               //     {col:false},
               //     {col:false},
               //     {col:false},
               //     {col:false},
               //     {col:false},
               //     {col:false}
               // ],
               // 底部回顶部图标
               btnFlag:false,
               // 页面滑动距离大于200，导航栏样式
               // log:{display:"block"},
               // inpu:{display:"block"},
              
               navbar:{
                   navbar1:false,
                   navCenter:true
               },
               logo:{
                   logo1:false,
                   logo2:true
               },
               paths:[
                   {path:"/"},
                   {path:"/product/laptop"},
                   {path:"/product/desktop"},
                   {path:"/product/preip"},
                   {path:"/evaluating"},
                   {path:"/aftersales"},
               ]
               // paths:[
               //     {path:"/",text:"首页"},
               //     {path:"/ProductLaptop",text:"笔记本"},
               //     {path:"/ProductDesktop",text:"台式机"},
               //     {path:"/ProductPreip",text:"外设系列"},
               //     {path:"/Evaluating",text:"评测中心"},
               //     {path:"/AfterSales",text:"售后服务"},
               // ]
           }
       },
       // 定义页面滚动效果函数
       mounted () {
            window.addEventListener('scroll', this.scrollToTop)
       },
       created() {
           console.log(this.url);
       },
       methods:{
            // 当鼠标移入到购物车图标，显示购物车列表
            disBlock(){
                this.dis.display="block";
            },
            // 当鼠标移出购物车图标，列表隐藏
            disNone(){
                this.dis.display="none";
            },
            // 侧边导航栏
            aside2(){
                this.aside={
                    aside1:false,
                    aside1s:true
                }
            },
            aside3(){
                this.aside={
                    aside1:true,
                    aside1s:false
                }
            },
            // 中屏时，鼠标移入md-img1和md-img2下的图标，图标颜色发生变化
            img(){this.i=false},
            imgs(){this.i=true},
            img1(){this.j=false},
            img1s(){this.j=true},
        
            // 在中屏的时候，点击md-img1,class为md-all和class值为all出现
            change(){
                this.leftA={
                    all_left:false,
                    all_lefts:true
                }
                this.tran={all:true}
            },
            change1(){
                this.searchs={
                    search_nav1:false,
                    search_nav:true
                }
                this.tran1={all:true}
            },
            //当点击在class值为all的div上，leftAside和alls隐藏
            trans(){
                this.leftA={
                    all_left:true,
                    all_lefts:false
                }
                this.tran={all:false}
            },
            trans1(){
                this.searchs={
                    search_nav1:true,
                    search_nav:false
                }
                this.tran1={all:false}
            },
            //导航栏下部分中的首页、计算机等选项，点击变色
            show(n){
                for(var i=0;i<this.paths.length;i++){
                    if(n==i){
                       this.$router.push(this.paths[i].path)
                       // var url=window.location.href.split("#")[1];
                       // if(this.paths[i].path==url){
                       //     this.cols=true;
                       // }else{
                       //     this.cols=false;
                       // } 
                    }
                    
                }
            },
            // 调用页面滚动函数
            scrollToTop(){
                var st=document.documentElement.scrollTop || document.body.scrollTop
                this.scrollToTop=st;
                // 当鼠标滚动距离为200，顶部导航栏效果发生变化
                if(this.scrollToTop>=200){
                    this.navbar={
                       navbar1:true,
                       navCenter:false
                   }; 
                }else{
                     this.navbar={
                        navbar1:false,
                        navCenter:true
                    }; 
                }
                // 当鼠标滚动距离为600，回到顶部标志出现
                if(this.scrollToTop>=600){
                    this.btnFlag=true;
                }else{
                    this.btnFlag=false;
                }
                // 中屏时导航栏样式
                if(this.scrollToTop>=100){
                    this.logo={
                        logo1:true,
                        logo2:false
                    }
                }else{
                    this.logo={
                        logo1:false,
                        logo2:true
                    }
                }
            },
        
        },
       

   }
</script>

<style scoped>
    @import url("../assets/css/header.css");
</style>
