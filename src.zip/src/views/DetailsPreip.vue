<template>
    <div>
        <sm-header></sm-header>
        <div class="details-preip font">
           <!--*******************评测中心导航栏**********************-->
           		<div class="preip-first">
           			<div class="nav">
           				<a href="#">首页</a>
           				<span>&gt;</span>
           				<span><a href="">外设系列</a></span>
           				<span>&gt;</span>
                        <span><a href="">游戏耳机</a></span>
                        <span>&gt;</span>
           				<span>惠普（HP）暗影精灵3代 游戏台式电脑主机（i7-8700 16G高频 1T+256GSSD GTX1060 6G独显 三年上门）</span>
           			</div>
           		</div>
           <!--************************************内容部分******************************-->
           		<div class="preip-second">
           			<div class="preip-container">
           				<div class="content">
           					<div class="con-img">
                                   <!-- 描述上部分右侧 -->
           						<div class="con-right">
           					 		<div class="con-right-t">
           					 			<img src="../assets/img/product_details/sony-md.jpg"/>
           					 		</div>
           					 		<div class="con-right-b">
           					 			<img src="../assets/img/product_details/sony-sm.jpg"/>
           					 			<img src="../assets/img/product_details/sony1.jpg"/>
           					 			<img src="../assets/img/product_details/sony2.jpg"/>
                                        <img src="../assets/img/product_details/sony3.jpg"/>
                                        <img src="../assets/img/product_details/sony4.jpg"/>
           					 		</div>
           					 	</div>
                    <!--***************************** 描述上部分左侧**************************** -->
           					 	<div class="con-left">
           					 		<h1>索尼（SONY）WH-1000XM3 高解析度无线蓝牙降噪耳机（触控面板 智能降噪 长久续航）黑色</h1>
           					 		<div class="big-line">
           					 			<div></div>
           					 		</div>
           					 		<p class="con-details">新款黑科技，超强降噪，佩戴更舒适，快充更方便！</p>
           					 		<p class="con-price"><span>¥2899</span><span>¥1699</span></p>
           					 		<form action="" class="con-cart">
                                        <div class="con-shop">
                                            <button type="button">加入购物车</button>
                                            <button type="button">-</button>
                                            <input type="" name="" id="" value="1" />
                                            <button type="button">+</button>
                                        </div>
                                    </form>   
                                       <div class="con-lid">
                                           <p><span>商品编号：</span><span> SONY225145</span></p>
                                           <p><span>分类：</span><span>游戏耳机</span></p>
                                       </div>                           
           					 	</div>
           					</div> 
           				</div>
           			</div>
           		</div>
                <!--************************* 商品描述部分 ********************************-->
                <div class="preip-three">
                    <div class="preip-msg">
                        <div class="msgs">
                            <div class="msgs-nav">
                                <ul>
                                    <li><a href="javascript:;" class="active">描述</a></li>
                                    <li><a href="javascript:;">用户评价(0)</a></li>
                                </ul>
                            </div>
                            <div class="msgs-desc">
                                <div class="desc-cont">
                                    <div class="desc-img">
                                        <img src="../assets/img/product_details/sony-lg.jpg" >
                                    </div>
                                </div>
                                <div class="desc-com">
                                    <div></div>
                                    <p>目前还未有评论</p>
                                    <p>只有买过此商品的客户登录后才能发表评论</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ********************相关商品****************************************** -->
                <div class="preip-four">
                    <div class="preip-pro">
                        <div class="relevant-pro">
                            <div class="pro-nav1">
                                <h2>热门商品</h2>
                            </div>
                            <ul>
                                <div class="pro-li1"> 
                                    <li>
                                        <div class="pro-1">
                                            <a href="" title="联想大红点M120Pro有线鼠标 台式机鼠标 笔记本鼠标">
                                            <img src="../assets/img/product_details/m120p-md.jpg" class="p-img"/></a>
                                        </div>
                                        <div class="pro-2">
                                            <a href="#">联想大红点M120Pro有线鼠标 台式机鼠标 笔记本鼠标</a>
                                            <p><span>¥99</span></p>
                                        </div>
                                    </li>
                                     
                                    <li class="p-li">
                                        <div class="pro-1">
                                            <a href="" title="M330 无线静音鼠标 舒适曲线 黑色 M275升级版">
                                            <img src="../assets/img/product_details/m330-md.jpg" class="p-img"/></a>
                                        </div>
                                        <div class="pro-2">
                                            <a href="#">M330 无线静音鼠标 舒适曲线 黑色 M275升级版</a>
                                            <p><span>¥109</span></p>
                                        </div>
                                    </li> 
                                </div>
                                <div class="pro-li2">
                                    <li>    
                                        <div class="pro-1">
                                           <a href="" title=" Pico G2小怪兽2 VR一体机 4K高清视频 体感游戏 VR眼镜 3D头盔">
                                            <img src="../assets/img/product_details/pico-sm.jpg" class="p-img"/></a>
                                        </div>
                                        <div class="pro-2">
                                            <a href="#">Pico G2小怪兽2 VR一体机 4K高清视频 体感游戏 VR眼镜 3D头盔</a>
                                            <p><span>¥1899</span></p>
                                        </div>
                                                                          
                                    </li>
                                    <li class="p-li">
                                        <div class="pro-1">
                                            <a href="" title=" 小米米家（MIJIA）智能摄像机 云台版 白色 1080P">
                                            <img src="../assets/img/product_details/mijia-md.jpg" class="p-img"/></a>
                                        </div>
                                        <div class="pro-2">
                                            <a href="#"> 小米米家（MIJIA）智能摄像机 云台版 白色 1080P</a>
                                           <p><span>¥199</span></p>
                                        </div>
                                    </li>
                                </div>	
                            </ul>
                        </div>
                    </div>
                </div> 
        </div>
        <sm-footer></sm-footer>
    </div>
</template>

<script>
</script>

<style>
    @import url("../assets/css/details-preip.css");
</style>
