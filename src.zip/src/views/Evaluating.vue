<template>
    <div>
        <sm-header></sm-header>
        <div class="evaluating">
        <!--*******************评测中心导航栏**********************-->
        		<div class="eval-first">
        			<div class="enav1">
        				<router-link to="/">首页</router-link>
        				<span>&gt;</span>
        				<span>评测中心</span>
        			</div>
        		</div>
        <!--*******************评测中心内容部分********************-->
        		<div class="eval-second">
        			<div class="eval-content">
        				<!--左侧导航部分-->
        				<div class="content-left" id="run">
                            <div class="left1">
                                <div class="dis">
                                    <a href="javascript:;">
                                        <span>按分类浏览</span>
                                        <img src="../assets/img/eval/xia.png" >
                                    </a> 
                                </div>
                                <ul class="">
                                    <li>
                                        <a href="javascript:;" class="click">
                                            <div class="right-img"></div>
                                            <div class="font1">
                                                <span>全部资讯</span>  
                                            </div>
                                        </a>  
                                    </li>
                                    <li>
                                        <a href="javascript:;" class="click">
                                            <div class="right-img"></div>
                                            <div class="font1">
                                                <span>技术分析</span>  
                                            </div>
                                        </a>  
                                    </li>
                                    <li>
                                        <a href="javascript:;" class="click">
                                            <div class="right-img"></div>
                                            <div class="font1">
                                                <span>行业新闻</span>  
                                            </div>
                                        </a> 
                                    </li>
                                </ul>
                            </div> 
        				</div>
        				<!--右侧部分-->
        				<div class="content-right" id="conceal">
        					<ul>
        						<li>
        							<div class="first-info1">
        								<a href="#"><img src="../assets/img/eval/eval2.jpg"/></a>
        							</div>
        							<div class="first-info2">
                                        <div class="">
                                            <a href="#">大屏轻薄笔记本？17英寸LG gram开箱体验</a>
                                            <h6 class="font">发布日期：2019-03-05</h6>
                                            <p class="font">RTX 20系显卡登陆移动平台可谓是近期笔记本市场最大的事件，虽然第八代酷睿处理器的登场为移动平台带来了六核心的强悍规格，但颇为“长寿”的10系显卡始终是一些消费者换机的...</p> 
                                        </div>
        								
        							</div>
        						</li>
        						<li>
        							<div class="first-info1">
        								<a href="#"><img src="../assets/img/eval/eval5.jpg"/></a>
        							</div>
        							<div class="first-info2">
                                        <div class="">
                                            <a href="#">八千元RTX游戏本真香 惠普暗影精灵4 Pro</a>
                                            <h6 class="font">发布日期：2019-03-05</h6>
                                            <p class="font">RTX独显游戏本的到来是今年初PC领域最受关注的事件之一，而在众多首发产品中，惠普暗影精灵4 Pro可以说是最受追捧的型号之一，这是因为惠普暗影精灵4 Pro在拥有RTX...</p> 
                                        </div>
        								
        							</div>
        						</li>
        						<li>
        							<div class="first-info1">
        								<a href="#"><img src="../assets/img/eval/eval3.jpg"/></a>
        							</div>
        							<div class="first-info2">
                                        <div class="">
                                            <a href="#"> 一眼即世界 92%屏占比华硕灵耀U 2代体验</a>
                                            <h6 class="font">发布日期：2019-03-05</h6>
                                            <p class="font">华硕顽石热血版YX570U相信很多人都有了解，这款产品采用酷睿低压处理器+GTX1050显卡的配置组合，相比游戏本拥有更加时尚内敛的外观设计，只不过堪比游戏本的售价让人有...</p> 
                                        </div>
        								
        							</div>
        						</li>
        						<li>
        							<div class="first-info1">
        								<a href="#"><img src="../assets/img/eval/eval1.jpg"/></a>
        							</div>
        							<div class="first-info2">
                                        <div class="">
                                            <a href="#">实测：数据佐证RTX Max-Q版与标准版差多少</a>
                                            <h6 class="font">发布日期：2019-03-05</h6>
                                            <p class="font">与10系显卡先推标准版再推Max-Q版不同，20系RTX显卡登陆游戏本之时，同时推出了标准版和Max-Q版。近期收到多名网友咨询同一型号下两者性能相差多少的问题，相信很多...</p>
                                        </div>
        								
        							</div>
        						</li>
        						<li>
        							<div class="first-info1">
        								<a href="#"><img src="../assets/img/eval/eval6.png"/></a>
        							</div>
        							<div class="first-info2">
                                        <div class="">
                                            <a href="#">锐不可当！华硕顽石YX570锐龙版游戏测试</a>
                                            <h6 class="font">发布日期：2019-03-05</h6>
                                            <p class="font">华硕顽石热血版YX570U相信很多人都有了解，这款产品采用酷睿低压处理器+GTX1050显卡的配置组合，相比游戏本拥有更加时尚内敛的外观设计，只不过堪比游戏本的售价让人有...</p>
                                        </div>
        								
        							</div>
        						</li>
                                <li class="show">
                                    <ul>
                                        <li>
                                            <div class="first-info1">
                                            	<a href="#"><img src="../assets/img/eval/eval5.jpg"/></a>
                                            </div>
                                            <div class="first-info2">
                                                <div class="">
                                                    <a href="#">极致体验性能爆表 惠普暗影精灵4 Pro游戏测试</a>
                                                    <h6 class="font">发布日期：2017-05-16</h6>
                                                    <p class="font">RTX独显游戏本的到来是今年初PC领域最受关注的事件之一，而在众多首发产品中，惠普暗影精灵4 Pro可以说是最受追捧的型号之一，这是因为惠普暗影精灵4 Pro在拥有RT...</p>
                                                </div>
                                            	
                                            </div>
                                        </li>
                                        <li>
                                            <div class="first-info1">
                                            	<a href="#"><img src="../assets/img/eval/eval10.jpg"/></a>
                                            </div>
                                            <div class="first-info2">
                                                <div class="">
                                                    <a href="#">APEX英雄玩家必看 光影精灵4的实测表现强劲</a>
                                                    <h6 class="font">发布日期：2017-05-16</h6>
                                                    <p class="font">最近，《APEX英雄》火到已经被作弊器团队盯上了，网传腾讯也在与EA洽谈国服代理事宜。那么目前主流游戏本运行《APEX英雄》会有怎样表现呢，此次我们使用惠普光影精灵4绿刃...</p>
                                                </div>
                                            	
                                            </div>
                                        </li>
                                        <li>
                                           <div class="first-info1">
                                           	<a href="#"><img src="../assets/img/eval/eval2.jpg"/></a>
                                           </div>
                                           <div class="first-info2">
                                               <div class="">
                                                   <a href="#">RTX时代来临 机械革命深海幽灵Z2评测</a>
                                                   <h6 class="font">发布日期：2017-05-16</h6>
                                                   <p class="font">RTX 20系显卡登陆移动平台可谓是近期笔记本市场最大的事件，虽然第八代酷睿处理器的登场为移动平台带来了六核心的强悍规格，但颇为“长寿”的10系显卡始终是一些消费者换机...</p>
                                               </div>
                                           	
                                           </div> 
                                        </li>
                                    </ul>
                                </li>
        					</ul>
        					<div class="but">
        						<a href="javascript:;">查看更多</a>
        					</div>
        				</div>
        			</div>
        		</div>
        	</div>
        <sm-footer></sm-footer>
    </div>
</template>

<script>
    export default{
        data(){
            return{
                
            }
        }
    }
</script>

<style>
    @import url("../assets/css/evaluating.css");
</style>
