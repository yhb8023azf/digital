<template>
    <div>
        <sm-header></sm-header>
        <div class="driveDown font">
            <!-- 导航栏 -->
            <div class="drive-nav">
            	<div class="dnav">
            		<a href="#">首页</a>
            		<span>&gt;</span>
            		<a href="#">驱动下载</a>
            	</div>
            </div>
            <div class="drive-content">
                <div class="drive-con">
                    <div class="drive-left">
                       <div class="left-top ddbg">
                           <div>
                               <h2>主板驱动</h2>
                           </div>
                           <div>
                               <ul>
                                   <li>万能显卡驱动 for win10 32bit v2017.11.15.955</li>
                                   <li>万能显卡驱动 for win10 32bit v2017.11.15.955</li>
                                   <li>万能显卡驱动 for win10 64bit v2017.11.15.95</li>
                                   <li>万能显卡驱动 for win7 32bit v2017.11.15.955</li>
                                   <li>万能显卡驱动 for win7 64bit v2017.11.15.955</li>
                                   <li>万能显卡驱动 for winXP 32bit v2017.11.15.955</li>
                                   <li>万能显卡驱动 for win10 64bit v2017.11.15.95</li>
                                   <li>万能显卡驱动 for win7 32bit v2017.11.15.955</li>
                                   <li>万能显卡驱动 for win7 64bit v2017.11.15.955</li>
                               </ul>
                           </div>
                       </div>
                       <div class="left-bot ddbg">
                          <div>
                              <h2>网卡驱动</h2>
                          </div>
                          <div>
                              <ul>
                                  <li>万能显卡驱动 for win10 32bit v2017.11.15.955</li>
                                  <li>万能显卡驱动 for win10 32bit v2017.11.15.955</li>
                                  <li>万能显卡驱动 for win10 64bit v2017.11.15.95</li>
                                  <li>万能显卡驱动 for win7 32bit v2017.11.15.955</li>
                                  <li>万能显卡驱动 for win7 64bit v2017.11.15.955</li>
                                  <li>万能显卡驱动 for winXP 32bit v2017.11.15.955</li> 
                                  
                              </ul>
                          </div> 
                       </div>
                    </div>
                    <div class="drive-right">
                        <div class="right-top ddbg">
                            <div>
                                <h2>显卡驱动</h2>
                            </div>
                            <div>
                                <ul>
                                    <li>万能显卡驱动 for win10 32bit v2017.11.15.955</li>
                                    <li>万能显卡驱动 for win10 32bit v2017.11.15.955</li>
                                    <li>万能显卡驱动 for win10 64bit v2017.11.15.95</li>
                                    <li>万能显卡驱动 for win7 32bit v2017.11.15.955</li>
                                    
                                </ul>
                            </div> 
                        </div>
                        <div class="right-bot ddbg">
                            <div>
                                <h2>声卡驱动</h2>
                            </div>
                            <div>
                                <ul>
                                    <li>万能显卡驱动 for win10 32bit v2017.11.15.955</li>
                                    <li>万能显卡驱动 for win10 32bit v2017.11.15.955</li>
                                    <li>万能显卡驱动 for win10 64bit v2017.11.15.95</li>
                                    <li>万能显卡驱动 for win7 32bit v2017.11.15.955</li>
                                    <li>万能显卡驱动 for win7 64bit v2017.11.15.955</li>
                                    <li>万能显卡驱动 for winXP 32bit v2017.11.15.955</li>                          
                                    <li>万能显卡驱动 for win10 64bit v2017.11.15.95</li>
                                    <li>万能显卡驱动 for win7 32bit v2017.11.15.955</li>
                                    <li>万能显卡驱动 for win7 64bit v2017.11.15.955</li>
                                    <li>万能显卡驱动 for win7 32bit v2017.11.15.955</li>
                                    <li>万能显卡驱动 for win7 64bit v2017.11.15.955</li>
                                </ul>
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <sm-footer></sm-footer>
    </div>
</template>

<script>
</script>

<style scoped>
    *{margin:0px;padding:0px;}
    body{box-sizing:border-box;}
    .font{
        word-spacing: normal;
        font-family: "微软雅黑",Helvetica,Arial,Verdana,sans-serif;
        font-style: normal;
        font-weight: normal;
        font-size:14px;
    }
    .driveDown{background:#f2f2f2;padding-bottom:60px;}
    /* ********************导航栏******************** */
    .driveDown>.drive-nav{ 
        background:#fff;
        width:100%;
        margin-bottom:20px;
    }
    .driveDown>.drive-nav .dnav{
        padding-top:20px;
        padding-bottom:20px;
    }
    .driveDown>.drive-nav .dnav a{color:#757575;}
    @media only screen and (min-width:992px){
        .driveDown>.drive-nav .dnav,.driveDown>.drive-content .drive-con{
        padding-left:7%;
        padding-right:7%;
        }
    }
    @media only screen and (max-width:991px){
        .driveDown>.drive-nav .dnav,.driveDown>.drive-content .drive-con{
        padding-left:7%;
        padding-right:7%;
        }
    }
    @media only screen and (max-width:576px){
        .driveDown>.drive-nav .dnav,.driveDown>.drive-content .drive-con{
            padding:10px;
    	}
    }
    /* ****************************主体内容 ***********************/
    .driveDown>.drive-content{width:100%;}
    .driveDown .drive-con  .ddbg{
        background:#fff;
        margin-bottom:10px;
        padding:18px;
    }
    .driveDown .drive-con  .ddbg h2{
        color: #373a41;
        font-size:20px;
        font-weight:normal;
        border-bottom:1px solid #ccc;
        padding-bottom:8px;
        margin-bottom:8px;
    }
    .driveDown .drive-con  .ddbg li{
        list-style-type: disc;
        list-style-position: inside;
        line-height:28px;
        color:#666;
    }
     @media only screen and (min-width:992px){
         .driveDown>.drive-content .drive-con{
             display:flex;
         }
         
         .driveDown .drive-con>.drive-left{margin-right:10px;width:50%;}
         .driveDown .drive-con>.drive-right{width:50%;}
     }
     @media only screen and (max-width:991px){
         .driveDown .drive-con>.drive-left{width:100%;}
         .driveDown .drive-con>.drive-right{width:100%;}
     }
</style>
