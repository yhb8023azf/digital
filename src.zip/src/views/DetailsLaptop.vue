<template>
    <div>
       <sm-header></sm-header>
        <div class="details-laptop font">
        <!--*******************评测中心导航栏**********************-->
        		<div class="laptop-first">
        			<div class="nav">
        				<a href="#">首页</a>
        				<span>&gt;</span>
        				<span><a href="">笔记本</a></span>
        				<span>&gt;</span>
        				<span>14英寸四核独显轻薄商务便携笔记本电脑</span>
        			</div>
        		</div>
        <!--************************************内容部分******************************-->
        		<div class="laptop-second">
        			<div class="laptop-container">
        				<div class="content">
        					<div class="con-img">
                                <!-- 描述上部分右侧 -->
        						<div class="con-right">
        					 		<div class="con-right-t">
        					 			<img src="../assets/img/product_details/laptop-lg-14.jpg"/>
        					 		</div>
        					 		<div class="con-right-b">
        					 			<img src="../assets/img/product_details/laptop-md-14.jpg"/>
        					 			<img src="../assets/img/product_details/de-laptop2.jpg"/>
        					 			<img src="../assets/img/product_details/de-laptop3.jpg"/>
        					 			<img src="../assets/img/product_details/de-laptop4.jpg"/>
        					 			<img src="../assets/img/product_details/de-laptop1.jpg"/>
        					 		</div>
        					 	</div>
                 <!--***************************** 描述上部分左侧**************************** -->
        					 	<div class="con-left">
        					 		<h1>14英寸四核独显轻薄商务便携笔记本电脑</h1>
        					 		<div class="big-line">
        					 			<div></div>
        					 		</div>
        					 		<p class="con-details">金属游戏本，芯八代六核I7-8750H处理器，GTX1050/4G独显，8G内存，128G固态+1T机械，IPS高清屏</p>
        					 		<p class="con-price"><span>¥5999</span></p>
        					 		<form action="" class="con-cart" id="shop">
                                        <h3>搭配套餐:</h3>
                                        <p><input type="checkbox" name="" id="m3" value=""/><label for="m3" data-price="99">M301炫彩鼠标原价159元 (¥99)</label></p>
                                        <p><input type="checkbox" name="" id="k7" value=""/><label for="k7" data-price="240">K70红轴机械键盘原价299 (¥240)</label></p>
                                        <p><input type="checkbox" name="" id="k8" value=""/><label for="k8" data-price="399">K80樱桃茶轴键盘原价499 (¥399)</label></p>
                                        <p><input type="checkbox" name="" id="dj" value=""/><label for="dj" data-price="1499">27英寸电竞显示器原价1699元 (¥1499)</label></p>
                                        <p> <input type="checkbox" name="" id="sm" value=""/><label for="sm" data-price="349">沙漠风暴H71耳机黑色原价499 (¥349)</label></p> 
                                        <div class="con-total" style="height:0px;">
                                            <p><span>选项累计:</span><span>¥0</span></p>
                                            <p><span>全部总计:</span><span>¥5999</span></p>   
                                        </div>
                                        <div class="con-shop">
                                            <button type="button">加入购物车</button>
                                            <button type="button">-</button>
                                            <span>1</span>
                                            <button type="button">+</button>
                                        </div>
                                    </form>   
                                    <div class="con-lid">
                                        <p><span>商品编号：</span> <span>82FW0209CD</span> </p>
                                        <p><span>分类：</span> <span>笔记本</span> </p>
                                        <p><span>标签：</span> <span>游戏笔记本</span> </p>
                                    </div>                           
        					 	</div>
        					</div> 
        				</div>
        			</div>
        		</div>
                <!--************************* 商品描述部分 ********************************-->
                <div class="laptop-three">
                    <div class="laptop-msg">
                        <div class="msgs" id="message">
                            <div class="msgs-nav">
                                <ul>
                                    <li><a href="javascript:;" class="active" data-target="content1">描述</a></li>
                                    <li><a href="javascript:;" data-target="content2">其它信息</a></li>
                                    <li><a href="javascript:;" data-target="content3">用户评价(0)</a></li>
                                </ul>
                            </div>
                            <div class="msgs-desc">
                                <div class="desc-cont" id="content1">
                                    <h1>处理器</h1>
                                    <span class="msg-span">CPU：第八代智能英特尔® 酷睿™ i5 处理器</span>
                                    <span class="msg-span">CPU型号：i5-8300H</span>
                                    <span class="msg-span">CPU主频：2.3 GHz</span>
                                    <span class="msg-span">核心数：四核</span>
                                    <h1>屏幕</h1>
                                    <span class="msg-span">屏幕尺寸：15.6英寸</span>
                                    <span class="msg-span">物理分辨率：1920x1080</span>
                                    <span class="msg-span">屏幕类型：全高清IPS屏幕</span>
                                    <span class="msg-span">显示比例：16:9</span> 
                                    <h1>内存</h1>
                                    <span class="msg-span">内存容量：8GB</span>
                                    <span class="msg-span">内存类型：DDR4</span>
                                    <h1>硬盘</h1>
                                    <span class="msg-span">硬盘容量：2T+128G SSD</span>
                                    <span class="msg-span">硬盘类型：机械硬盘+固态硬盘</span>
                                    <div class="desc-img">
                                        <img src="../assets/img/product_details/big-laptop.png" >
                                    </div>
                                </div>
                                <div class="msgs-tab" id="content2">
                                    <table class="desc-tab">
                                        <tr>
                                            <th>屏幕尺寸</th>
                                            <td><p>14.0英寸</p></td>
                                        </tr>
                                        <tr>
                                            <th>处理器</th>
                                            <td><p>Intel i5</p></td>
                                        </tr>
                                        <tr>
                                            <th>显卡</th>
                                            <td><p>GTX1060 3G/6G</p></td>
                                        </tr>
                                        <tr>
                                            <th>内存</th>
                                            <td><p>32G</p></td>
                                        </tr>
                                        <tr>
                                            <th>硬盘</th>
                                            <td><p>500GB HDD</p></td>
                                        </tr>
                                        <tr>
                                            <th>品牌</th>
                                            <td><p>神舟</p></td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="desc-com" id="content3">
                                    <div></div>
                                    <p>目前还未有评论</p>
                                    <p>只有买过此商品的客户登录后才能发表评论</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ********************相关商品****************************************** -->
                <div class="laptop-four">
                    <div class="laptop-pro">
                        <div class="relevant-pro">
                            <div class="pro-nav2">
                                <h2>相关商品</h2>
                            </div>
                            <ul>
                            	<div class="pro-li1">   
                                    <li>    
                                        <div class="pro-1">
                                            <a href="" title="14英寸四核独显轻薄商务便携笔记本电脑">
                                            <img src="../assets/img/product/pro-lap6.jpg" class="lap-img"/></a>
                                        </div>
                                        <div class="pro-2">
                                            <a href="#">14英寸四核独显轻薄商务便携笔记本电脑</a>
                                            <p><span>¥5999</span></p>
                                        </div>
                                   
                                    </li>
                                    <li>
                                        <div class="pro-1">
                                            <a href="" title="15.6英寸游戏笔记本 黑色 80WW000TCD">
                                            <img src="../assets/img/product/pro-lap1.jpg" class="lap-img"/></a>
                                        </div>
                                        <div class="pro-2">
                                            <a href="#">15.6英寸游戏笔记本 黑色 80WW000TCD</a>
                                            <p><span>¥5999</span></p>
                                        </div>
                                    </li> 
                                </div>
                                <div class="pro-li2">
                                    <li>
                                        <div class="pro-1">
                                            <a href="" title="E580 笔记本电脑 20KSA001CD">
                                            <img src="../assets/img/product/pro-lap5.jpg" class="lap-img"/></a>
                                        </div>
                                        <div class="pro-2">
                                            <a href="#">E580 笔记本电脑 20KSA001CD</a>
                                            <p><span>¥10899</span></p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="pro-1">
                                            <a href="" title="15.6英寸游戏笔记本 黑色 81HC0007CD">
                                            <img src="../assets/img/product/pro-lap2.jpg" class="lap-img"/></a>
                                        </div>
                                        <div class="pro-2">
                                            <a href="#">15.6英寸游戏笔记本 黑色 81HC0007CD</a>
                                            <p><span>¥5899</span></p>
                                        </div>
                                    </li>
                                </div>	
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
       <sm-footer></sm-footer>
        
    </div>
</template>

<script>
    export default{
        data(){
            return{
                
            }
        }
    }
</script>

<style>
    @import url("../assets/css/details-laptop.css");
</style>
