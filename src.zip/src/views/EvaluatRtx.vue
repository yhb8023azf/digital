<template>
    <div>
        <sm-header></sm-header>
        <div class="evaluating font">
        	<div class="eval-first">
        		<div class="eval-nav font">
        			<router-link to="/">首页</router-link>
        			<span>&gt;</span>
        			<router-link to="/evaluating">全部资讯</router-link>
        			<span>&gt;</span>
        			<span> RTX时代来临 机械革命深海幽灵Z2评测</span>
        		</div>
        	</div>
        	<div class="eval-second">
        		<div class="eval-content">
        			<div class="eval-right">
        				<div class="right-1">
        					<h1>RTX时代来临 机械革命深海幽灵Z2评测</h1>
        				</div>
        				<div class="right-2">
        					<span>发布日期：2019-05-16 15:59</span>
        				</div>
        				<div class="right-3">
        					<span>您可以双击这里或者点击编辑按钮来修改内容。您还可以添加图标，按钮，图片等常用元素。您可以双击这里或者点击编辑按钮来修改内容。您还可以添加图标，按钮，图片等常用元素。您可以双击这里或者点击编辑按钮来修改内容。您还可以添加图标，按钮，图片等常用元素。您可以双击这里或者点击编辑按钮来修改内容。您还可以添加图标，按钮，图片等常用元素。您可以双击这里或者点击编辑按钮来修改内容。您还可以添加图标，按钮，图片等常用元素。您可以双击这里或者点击编辑按钮来修改内容。您还可以添加图标，按钮，图片等常用元素。您可以双击这里或者点击编辑按钮来修改内容。您还可以添加图标，按钮，图片等常用元素。您可以双击这里或者点击编辑按钮来修改内容。您还可以添加图标，按钮，图片等常用元素。您可以双击这里或者点击编辑按钮来修改内容。您还可以添加图标，按钮，图片等常用元素。您可以双击这里或者点击编辑按钮来修改内容。您还可以添加图标，按钮，图片等常用元素。您可以双击这里或者点击编辑按钮来修改内容。您还可以添加图标，按钮，图片等常用元素。您可以双击这里或者点击编辑按钮来修改内容。您还可以添加图标，按钮，图片等常用元素。您可以双击这里或者点击编辑按钮来修改内容。您还可以添加图标，按钮，图片等常用元素。您可以双击这里或者点击编辑按钮来修改内容。您还可以添加图标，按钮，图片等常用元素。您可以双击这里或者点击编辑按钮来修改内容。您还可以添加图标，按钮，图片等常用元素。您可以双击这里或者点击编辑按钮来修改内容。您还可以添加图标，按钮，图片等常用元素。</span>
        				</div>
        				<div class="right-4">
        					<div class="four-1">
        						<router-link to="/evaluating/rtx">
        							<span>上一篇</span>
        							<span>没有了</span>
        						</router-link>
        					</div>
        					<div class="four-2">
        						<router-link to="/evaluating/apex">
        							<span>下一篇</span>
        							<span>APEX英雄玩家必看 光影精灵4的实测表现强劲</span>
        						</router-link>
        					</div>
        				</div>
        				<div class="right-5">
        					<span>分享到：</span>
        					<span>
        						<a href="javascript:;"></a>
        						<a href="javascript:;"></a>
        						<a href="javascript:;"></a>
        					</span>
        				</div>
        			</div>
        			<div class="eval-left">
        				<ul>
        					<li>
        						<div class="">
        							<router-link to="/evaluating/daping" title="大屏轻薄笔记本？17英寸LG gram开箱体验">大屏轻薄笔记本？17英寸LG g...</router-link>
        							<p>发布日期：2019-03-05</p>
        						</div>
        					</li>
        					<li>
        						<div class="">
        							<router-link to="/evaluating/baqian" title="八千元RTX游戏本真香 惠普暗影精灵4 Pro">八千元RTX游戏本真香 惠普暗影...</router-link>
        							<p>发布日期：2019-03-05</p>
        						</div>
        					</li>
        					<li>
        						<div class="">
        							<router-link to="/evaluating/yiyan" title="一眼即世界 92%屏占比华硕灵耀U 2代体验">一眼即世界 92%屏占比华硕灵耀...</router-link>
        							<p>发布日期：2019-03-05</p>
        						</div>
        					</li>
        					<li>
        						<div class="">
        							<router-link to="/evaluating/shice" title="实测：数据佐证RTX Max-Q版与标准版差多少">实测：数据佐证RTX Max-Q...</router-link>
        							<p>发布日期：2019-03-05</p>
        						</div>
        					</li>
        					<li>
        						<div class="">
        							<router-link to="/evaluating/ruibu" title="锐不可当！华硕顽石YX570锐龙版游戏测试">锐不可当！华硕顽石YX570锐龙...</router-link>
        							<p>发布日期：2019-03-05</p>
        						</div>
        					</li>
        					<li>
        						<div class="">
        							<router-link to="/evaluating/jizhi" title="极致体验性能爆表 惠普暗影精灵4 Pro游戏测试">极致体验性能爆表 惠普暗影精灵4...</router-link>
        							<p>发布日期：2019-05-16</p>
        						</div>
        					</li>
        					<li>
        						<div class="">
        							<router-link to="/evaluating/apex" itle="APEX英雄玩家必看 光影精灵4的实测表现强劲">APEX英雄玩家必看 光影精灵4...</router-link>
        							<p>发布日期：2019-05-16</p>
        						</div>
        					</li>
        				</ul>
        			</div>
        		</div>
        	</div>
        </div>
        <sm-footer></sm-footer>
    </div>
</template>

<script>
</script>

<style>
    @import url("../assets/css/evaluating-comm.css");
</style>
