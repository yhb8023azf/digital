<template>
    <div>
       <sm-header></sm-header>
        <div class="product font">
        <!--*************************导航***************************-->		
        		<div class="product-nav">
        			<div class="nav">
        				<router-link to="/">首页</router-link>
        				<span>></span>
        				<span>外设系列</span>
        			</div>
        		</div>
        
        <!--*************************内容部分************************************-->
        <!--******************内容左侧部分****************************************-->
        		<div class="product-content">
        			<div class="content">
        				<div class="ri-cont" id="r1">
                            <div class="left1">
                                <!--******************中屏以下时出现的导航*******************-->
                                <div class="dis">
                                    <a href="javascript:;" @click="classify()">
                                        <span >{{classify1}}</span>
                                        <img src="../assets/img/eval/xia.png" >
                                    </a> 
                                </div>
                                <ul :class="btnUl">
                                    <li>
                                        <a href="javascript:;" class="click">
                                            <div class="right-img"></div>
                                            <div class="font1">
                                                <span>鼠标</span>  
                                            </div>
                                        </a>  
                                    </li>
                                    <li>
                                        <a href="javascript:;" class="click">
                                            <div class="right-img"></div>
                                            <div class="font1">
                                                <span>键盘</span>  
                                            </div>
                                        </a>  
                                    </li>
                                    <li>
                                        <a href="javascript:;" class="click">
                                            <div class="right-img"></div>
                                            <div class="font1">
                                                <span>摄像头</span>  
                                            </div>
                                        </a>  
                                    </li>
                                    <li>
                                        <a href="javascript:;" class="click">
                                            <div class="right-img"></div>
                                            <div class="font1">
                                                <span>游戏耳机</span>  
                                            </div>
                                        </a>  
                                    </li>
                                    <li>
                                        <a href="javascript:;" class="click">
                                            <div class="right-img"></div>
                                            <div class="font1">
                                                <span>VR设备</span>  
                                            </div>
                                        </a>  
                                    </li>
                                </ul>		
                            </div>
                            
        				</div>
        <!--*******************************内容右侧部分************************-->
        				<div class="ple-con">
        					<ul>
                                <span class="con1">
                                    <li>
                                    	<div class="">
                                    		<a href="" title="索尼（SONY）WH-1000XM3 高解析度无线蓝牙降噪耳机（触控面板 智能降噪 长久续航）黑色"><img src="../assets/img/product/perip6.jpg"/></a>
                                    	</div>
                                    	<div class="con">
                                    		<a href="#">索尼（SONY）WH-1000XM3 高解析...</a>
                                    		<p><span>¥1699</span><span>¥2899</span></p>
                                    	</div>
                                    </li>
                                    <li>
                                    	<div class="">
                                    		<a href="" title="小米米家（MIJIA）智能摄像机 云台版 白色 1080P"><img src="../assets/img/product/perip5.jpg"/></a>
                                    	</div>
                                    	<div class="con">
                                    		<a href="#">小米米家（MIJIA）智能摄像机 云台版...</a>
                                    		<p><span>¥199</span></p>
                                    	</div>
                                    </li>
                                </span>
                                <span class="con2">
                                    <li>
                                    	<div class="">
                                    		<a href="" title="Pico G2小怪兽2 VR一体机 4K高清视频 体感游戏 VR眼镜 3D头盔"><img src="../assets/img/product/perip1.jpg"/></a>
                                    	</div>
                                    	<div class="con">
                                    		<a href="#">Pico G2小怪兽2 VR一体机 4K高清视...</a>
                                    		<p><span>¥1899</span></p>
                                    	</div>
                                    </li>
                                    <li>
                                    	<div class="">
                                    		<a href="" title="联想大红点M120Pro有线鼠标 台式机鼠标 笔记本鼠标"><img src="../assets/img/product/perip2.jpg"/></a>
                                    	</div>
                                    	<div class="con">
                                    		<a href="#">联想大红点M120Pro有线鼠标 台式机鼠...</a>
                                    		<p><span>¥99</span></p>
                                    	</div>
                                    </li>
                                </span>
                                <span class="con3">
                                    <li>
                                    	<div class="">
                                    		<a href="" title="M330 无线静音鼠标 舒适曲线 黑色 M275升级版"><img src="../assets/img/product/perip4.jpg"/></a>
                                    	</div>
                                    	<div class="con">
                                    		<a href="#">M330 无线静音鼠标 舒适曲线 黑色 M2...</a>
                                    		<p><span>¥109</span></p>
                                    	</div>
                                    </li>
                                    <li>
                                    	<div class="">
                                    		<a href="" title="全尺寸背光机械游戏键盘 机械键盘 红轴 吃鸡键盘 绝地求生"><img src="../assets/img/product/perip3.jpg"/></a>
                                    	</div>
                                    	<div class="con">
                                    		<a href="#">全尺寸背光机械游戏键盘 机械键盘 红轴...</a>
                                    		<p><span>¥99</span></p>
                                    	</div>
                                    </li>
                                </span>
        					</ul>
        				</div>
        			</div>
        		</div>
        	</div>
       <sm-footer></sm-footer>
        
    </div>
</template>

<script>
    export default{
        data(){
            return{
                btnUl:{
                    dis1:true,
                    dis2:false
                },
                classify1:"按分类浏览"
            }
        },
        methods:{
            classify(){
                if(this.classify1=="按分类浏览"){
                    this.btnUl={
                        dis1:false,
                        dis2:true
                    },
                    this.classify1="关闭"
                }else{
                    this.btnUl={
                        dis1:true,
                        dis2:false
                    },
                    this.classify1="按分类浏览"
                }
            }
        }
    }
</script>

<style>
    @import url("../assets/css/product-preip.css");
</style>
