<template>
    <div>
        <!-- 头部 -->
        <sm-header></sm-header>
        <div class="workComputer font">
          <!-- ************************办公电脑导航栏******************************* -->
            <div class="wc-nav">
                <div class="wnav">
                    <router-link to="/">首页</router-link>
                    <span>&gt;</span>
                    <span>办公电脑</span>
                </div>
            </div>
            <div class="wc-content">
                <div class="wc-con">
                    <div class="wcon w-30 w-r">
                        <div class="computer w-b r1 b1">
                           <div class="w-img">
                           	<a href="" title="ThinkPad T480 笔记本电脑"><img src="../assets/img/product/pro-lap9.jpg"/></a>
                           </div>
                           <div class="w-con">
                           	<a href="#"> ThinkPad T480 笔记本电脑</a>
                           	<p><span>¥8999</span></p>
                           </div> 
                        </div>
                        <div class="computer b1">
                            <div class="w-img">
                            	<a href="" title="13.3英寸触控笔记本 天蝎灰 81CT0001CD"><img src="../assets/img/product/pro-lap3.jpg"/></a>
                            </div>
                            <div class="w-con">
                            	<a href="#">13.3英寸触控笔记本 天蝎灰 81CT0001CD</a>
                            	<p><span>¥7599</span></p>
                            </div>
                        </div>
                    </div>
                    <div class="wcon w-30 w-r">
                        <div class="computer w-b r1 b1">
                            <div class="w-img">
                            	<a href="" title="拯救者 Y7000 15.6英寸游戏笔记本 黑色 81FW0009CD"><img src="../assets/img/product/lap10.jpg"/></a>
                            </div>
                            <div class="w-con">
                            	<a href="#"> 拯救者 Y7000 15.6英寸游戏...</a>
                            	<p><span>¥7599</span></p>
                            </div>
                        </div>
                        <div class="computer b1">
                            <div class="w-img">
                            	<a href="" title="15.6英寸游戏笔记本 黑色 81HC0007CD"><img src="../assets/img/product/pro-lap2.jpg"/></a>
                            </div>
                            <div class="w-con">
                            	<a href="#">15.6英寸游戏笔记本 黑色 81HC0007CD</a>
                            	<p><span>¥5899</span></p>
                            </div>
                        </div>
                    </div>
                    <div class="wcon w-30">
                        <div class="computer w-b r1">
                            <div class="w-img">
                            	<a href="" title="X280 笔记本电脑 20KFA002CD"><img src="../assets/img/product/pro-lap7.jpg"/></a>
                            </div>
                            <div class="w-con">
                            	<a href="#">X280 笔记本电脑 20KFA002CD</a>
                            	<p><span>¥6599</span></p>
                            </div>
                        </div>
                        <div class="computer">
                            <div class="w-img">
                            	<a href="" title="E580 笔记本电脑 20KSA001CD"><img src="../assets/img/product/pro-lap5.jpg"/></a>
                            </div>
                            <div class="w-con">
                            	<a href="#">E580 笔记本电脑 20KSA001CD</a>
                            	<p><span>¥10899</span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- 脚部 -->
        <sm-footer></sm-footer>
    </div>
</template>

<script>
</script>

<style scoped>
    *{margin:0px;padding:0px;}
    body{box-sizing:border-box;}
    .font{
        word-spacing: normal;
        font-family: "微软雅黑",Helvetica,Arial,Verdana,sans-serif;
        font-style: normal;
        font-weight: normal;
        font-size:14px;
    }
    .workComputer{background:#f2f2f2;padding-bottom:60px;width:100%;}
    /* 导航栏部分 */
    .workComputer>.wc-nav{
        background:#fff;
        width:100%;
        margin-bottom:20px;
    }
    .workComputer>.wc-nav .wnav{
        padding-top:20px;
        padding-bottom:20px;
    }
    .workComputer>.wc-nav .wnav a,.workComputer>.wc-nav .wnav span{color:#757575;}
    /* 大屏导航栏样式 */
    @media only screen and (min-width:992px){
        .workComputer>.wc-nav .wnav,.workComputer>.wc-content .wc-con{
        padding-left:7%;
        padding-right:7%;
        }
    }
    /* 中屏导航栏样式 */
    @media only screen and (max-width:991px){
        .workComputer>.wc-nav .wnav,.workComputer>.wc-content .wc-con{
        padding-left:7%;
        padding-right:7%;
        }
    }
    /* 小屏导航栏样式 */
    @media only screen and (max-width:576px){
        .workComputer>.wc-nav .wnav,.workComputer>.wc-content .wc-con{
            padding:10px;
    	}
    }
    /* 内容部分 */
    .workComputer>.wc-content{width:100%;}
    .workComputer .wc-con .w-30{
        width:33.3333%;
        text-align:center;
        }
    .workComputer .wc-con .computer{width:100%;background:#fff;}
    .workComputer .wc-con .computer img{width:100%;}
    .workComputer .wc-con .computer .w-img{padding-top:10px;}
    .workComputer .wc-con .computer .w-con{padding-bottom:10px;}
    .workComputer .wc-con .computer .w-con a{
        color: #000000;
        display:block;
        margin-bottom:15px;
        font-size:16px;
        line-height:21px;
    }
    .workComputer .wc-con .computer .w-con span{
        color: #dd3333;
        font-size:18px;
        display:block;
        margin-bottom:15px;
    }
    /* 大屏内容样式 */
    @media only screen and (min-width:992px){
        .workComputer>.wc-content .wc-con{display:flex;}
        .workComputer .wc-con .w-r{margin-right:20px !important;}
        .workComputer .wc-con .w-b{margin-bottom:20px !important;}
    }
    /* 中屏内容样式 */
    @media only screen and (max-width:991px){
        .workComputer .wc-con .wcon{
            display:flex;
            width:100%;
        }
        .workComputer .wc-con .computer{width:50%;}
        .workComputer .wc-con .r1{margin-right:15px;}
        .workComputer .wc-con .b1{margin-bottom:15px;}
    }
</style>
