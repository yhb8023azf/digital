<template>
    <div>
        <sm-header></sm-header>
        <div class="details-desktop font">
           <!--*******************评测中心导航栏**********************-->
           		<div class="desktop-first">
           			<div class="nav">
           				<a href="#">首页</a>
           				<span>&gt;</span>
           				<span><a href="">台式机/一体机</a></span>
           				<span>&gt;</span>
           				<span>惠普（HP）暗影精灵3代 游戏台式电脑主机（i7-8700 16G高频 1T+256GSSD GTX1060 6G独显 三年上门）</span>
           			</div>
           		</div>
           <!--************************************内容部分******************************-->
           		<div class="desktop-second">
           			<div class="desktop-container">
           				<div class="content">
           					<div class="con-img">
                                   <!-- 描述上部分右侧 -->
           						<div class="con-right">
           					 		<div class="con-right-t">
           					 			<img src="../assets/img/product_details/desktop-lg-h3.jpg"/>
           					 		</div>
           					 		<div class="con-right-b">
           					 			<img src="../assets/img/product_details/desktop-sm-h3.jpg"/>
           					 			<img src="../assets/img/product_details/de-desktop1.jpg"/>
           					 			<img src="../assets/img/product_details/de-desktop2.jpg"/>
                                        <img src="../assets/img/product_details/desktop1.jpg"/>
           					 		</div>
           					 	</div>
                    <!--***************************** 描述上部分左侧**************************** -->
           					 	<div class="con-left">
           					 		<h1>惠普（HP）暗影精灵3代 游戏台式电脑主机（i7-8700 16G高频 1T+256GSSD GTX1060 6G独显 三年上门）</h1>
           					 		<div class="big-line">
           					 			<div></div>
           					 		</div>
           					 		<p class="con-details">全新戴尔灵越酷睿8代超窄边框一体机京东首发，IPS高清大屏，隐藏式摄像头，首发3重好礼</p>
           					 		<p class="con-price"><span>¥4099-¥5999</span></p>
           					 		<form action="" class="con-cart" id="shop">
                                        <div class="versions">
                                            <div class="ver-first">
                                                <span>版本</span>
                                            </div>
                                            <div class="ver-second select">
                                                <span>i5-8400 8G 双硬盘 2G独显</span>
                                            </div>
                                            <div class="ver-three">
                                                <span>i3-8100 4G 双硬盘 2G独显</span>
                                            </div>
                                        </div> 
                                        <p><span class="cart-co">¥5999</span></p>
                                        <div class="con-shop">
                                            <button type="button">加入购物车</button>
                                            <button type="button">-</button>
                                            <span class="shop-sp">1</span>
                                            <button type="button">+</button>
                                        </div>
                                    </form>   
                                       <div class="con-lid">
                                           <p><span>商品编号：</span> <span>82FW0209CD</span> </p>
                                           <p><span>分类：</span> <span>台式机/一体机 </span> </p>
                                       </div>                           
           					 	</div>
           					</div> 
           				</div>
           			</div>
           		</div>
                   <!--************************* 商品描述部分 ********************************-->
                   <div class="desktop-three">
                       <div class="desktop-msg">
                           <div class="msgs" id="message">
                               <div class="msgs-nav">
                                   <ul>
                                       <li><a href="javascript:;" class="active" data-target="content1">描述</a></li>
                                       <li><a href="javascript:;" data-target="content2">其它信息</a></li>
                                       <li><a href="javascript:;" data-target="content3">用户评价(0)</a></li>
                                   </ul>
                               </div>
                               <div class="msgs-desc">
                                   <div class="desc-cont" id="content1">
                                       <div class="desc-img">
                                           <img src="../assets/img/product_details/desktop-lg-h3.jpg" >
                                       </div>
                                   </div>
                                   <div class="msgs-tab" id="content2">
                                       <table class="desc-tab">
                                           <tr>
                                               <th>版本</th>
                                               <td><p>i5-8400 8G 双硬盘 2G独显, i3-8100 4G 双硬盘 2G独显</p></td>
                                           </tr>
                                           <tr>
                                               <th>处理器</th>
                                               <td><p>Intel i5</p></td>
                                           </tr>
                                           <tr>
                                               <th>显卡</th>
                                               <td><p>GTX1070 8G</p></td>
                                           </tr>
                                           <tr>
                                               <th>内存</th>
                                               <td><p>4G</p></td>
                                           </tr>
                                           <tr>
                                               <th>硬盘</th>
                                               <td><p>256GB SSD</p></td>
                                           </tr>
                                           <tr>
                                               <th>品牌</th>
                                               <td><p>惠普</p></td>
                                           </tr>
                                       </table>
                                   </div>
                                   <div class="desc-com" id="content3">
                                       <div></div>
                                       <p>目前还未有评论</p>
                                       <p>只有买过此商品的客户登录后才能发表评论</p>
                                   </div>
                               </div>
                           </div>
                       </div>
                   </div>
                   <!-- ********************相关商品****************************************** -->
                   <div class="desktop-four">
                       <div class="desktop-pro">
                           <div class="relevant-pro">
                               <div class="pro-nav3">
                                   <h2>相关商品</h2>
                               </div>
                               <ul>
                               	<div class="pro-li1"> 
                                        <li>
                                            <div class="pro-1">
                                                <a href="" title="惠普（HP）暗影精灵23代 游戏台式电脑主机">
                                                <img src="../assets/img/product_details/corre-desktop4.jpg" class="pro-img"/></a>
                                            </div>
                                            <div class="pro-2">
                                                <a href="#">惠普（HP）暗影精灵23代 游戏台式电脑主机</a>
                                                <p><span>¥4999</span></p>
                                            </div>
                                        </li>
                                     
                                       <li>
                                           <div class="pro-1">
                                               <a href="" title=" 宏碁（Acer）商祺SQX4270 140N 商用办公台式电脑主机">
                                               <img src="../assets/img/product_details/corre-desktop2.jpg" class="pro-img"/></a>
                                           </div>
                                           <div class="pro-2">
                                               <a href="#"> 宏碁（Acer）商祺SQX4270 140N 商用办公台式电脑主机</a>
                                               <p><span>¥4999</span>-<span>¥5999</span></p>
                                           </div>
                                       </li> 
                                   </div>
                                   <div class="pro-li2">
                                         <li>    
                                            <div class="pro-1">
                                                <a href="" title="惠普（HP）暗影精灵3代 游戏台式电脑主机（i5-8400 16G高频 1T+128GSSD GTX1060 6G独显 三年上门）">
                                                <img src="../assets/img/product_details/corre-desktop1.jpg" class="pro-img"/></a>
                                            </div>
                                            <div class="pro-2">
                                                <a href="#">惠普（HP）暗影精灵3代 游戏台式电脑主机（i5-8400 16G高频 1T+128GSSD GTX1060 6G独显 三年上门）</a>
                                                <p><span>¥2999</span>-<span>¥5899</span></p>
                                            </div>
                                                                          
                                        </li>
                                       <li>
                                           <div class="pro-1">
                                               <a href="" title="惠普（HP）暗影精灵3代 游戏台式电脑主机（i5-8400 16G高频 1T+128GSSD GTX1060 6G独显 三年上门）">
                                               <img src="../assets/img/product_details/corre-desktop5.jpg" class="pro-img"/></a>
                                           </div>
                                           <div class="pro-2">
                                               <a href="#">惠普（HP）暗影精灵3代 游戏台式电脑主机（i5-8400 16G高频 1T+128GSSD GTX1060 6G独显 三年上门）</a>
                                               <p><span>¥5199</span>-<span>¥6999</span></p>
                                           </div>
                                       </li>
                                   </div>	
                               </ul>
                           </div>
                       </div>
                   </div> 
        </div>
        
        <sm-footer></sm-footer>
    </div>
</template>

<script>
    export default{
        data(){
            return{
                
            }
        }
    }
</script>

<style>
    @import url("../assets/css/details-desktop.css");
</style>
