<template>
    <div>
        <!-- ***********************************头部***************************** -->
        <sm-header/>
        <!-- *******************************首页内容********************************* -->
        <div class="index font">
        <!--*****************首页导航和轮播**********************-->
        		<div class="bg-lunbo">
        			<div class="navi">
        				<ul>
        					<li class="li-first">
                                <div class="">
                                    <span>全部分类</span>
                                </div>
                                <div class="back">
                                    
                                </div>
        					</li>
        					<li>
                                <router-link to="product/laptop">游戏笔记本</router-link>
        					</li>
        					<li>
        						<router-link to="product/desktop">游戏台式机</router-link>
        					</li>
        					<li>
        						<router-link to="workcomputer">办公电脑</router-link>
        					</li>
        					<li>
                               <router-link to="product/preip">游戏鼠键/耳机</router-link>
        					</li>
        					<li>
        						<a href="#">高清摄像头</a>
        					</li>
        					<li>
        						<a href="#">VR专区</a>
        					</li>
        					<li>
                                <router-link to="/drivedown">驱动下载</router-link> 
        					</li>
        					<li>
                                <router-link to="/aftersales">保修政策</router-link>
        					</li>
        				</ul>
        			</div>
        		</div>
        <!--*****************导航下固定部分**********************-->
        		<div class="index1">
        			<div class="fiex">
        				<div class="fiex-left">
        					<div class="fiex1">
        						<img src="../assets/img/index/xiao3.png"/>
        						<p class="font-small">以旧换新</p>
        					</div>
        					<div class="fiex2">
        						<img src="../assets/img/index/xiao2.png"/>
        						<p class="font-small">评测中心</p>
        					</div>
        				</div>
        				<div class="fiex-right">
        					<div class="fiex3">
        						<img src="../assets/img/index/xiao4.png"/>
        						<p class="font-small">驱动下载</p>
        					</div>
        					<div class="fiex4">
        						<img src="../assets/img/index/xiao1.png"/>
        						<p class="font-small">售后服务</p>
        					</div>
        				</div>
        			</div>
        			<img src="../assets/img/index/lunbo1.jpg" class="lun1 goto" :class="animations" :style="anmiDely1">
        			<img src="../assets/img/index/lonbo3.jpg" class="lun1 goto" :class="animations" :style="anmiDely2">
        			<img src="../assets/img/index/lunbo2.jpg" class="lun1 goto" :class="animations" :style="anmiDely3">
        		</div>
        <!--*****************精品单选推荐************************-->
        		<div class="index3">
        			<div class="recommendation">
        				<div class="rec-title font-small">
        					<p>精选单品推荐</p>
        				</div>
        				<div class="rec-laptop font-small">
        					<div class="laptop-y7 goto" :class="animations" :style="anmiDely1">
        						<a href="#">
        							<img src="../assets/img/index/recommendation1.jpg"/>
        							<h4 title="拯救者 Y7000 15.6英寸游戏本 黑色81FW0009CD">拯救者 Y7000 15.6英寸游...</h4>
        						</a>
        						<p class="index3-title">i5-8300H/Window...</p>
        					</div>
        					<div class="laptop-sw goto" :class="animations" :style="anmiDely2">
        						<a href="#">
        							<img src="../assets/img/index/recommendation5.jpg"/>
        							<h4 title="14英寸四核独显轻薄商务便携笔记本电脑">14英寸四核独显轻薄商务便...</h4>
        						</a>
        						<p>金属游戏本，芯八代六核I7-8...</p>
        					</div>
        					<div class="laptop-hc goto" :class="animations" :style="anmiDely3">
        						<a href="#">
        							<img src="../assets/img/index/recommendation4.jpg"/>
        							<h4 title="15.6英寸游戏笔记本 黑色 81HC0007CD">15.6英寸游戏笔记本 黑色 8...</h4>
        						</a>
        						<p>i5-8300H/Window...</p>
        					</div>
        					<div class="laptop-tx1 goto" :class="animations" :style="anmiDely4">
        						<a href="#">
        							<img src="../assets/img/index/recommendation2.jpg"/>
        							<h4 title="13.3英寸触控笔记本 天蝎灰 81CT0001CD">13.3英寸触控笔记本 天蝎...</h4>
        						</a>
        						<p>i5-8300H/Window...</p>
        					</div>
        					<div class="laptop-tp goto" :class="animations" :style="anmiDely5">
        						<a href="#">
        							<img src="../assets/img/index/recommendation6.jpg"/>
        							<h4 title=" ThinkPad T480 笔记本电脑"> ThinkPad T480 笔记本电脑</h4>
        						</a>
        						<p>i5-8250U/Window...</p>
        					</div>
        					
        				</div>
        			</div>
        		</div>
        <!--*****************笔记本/游戏本***********************-->
        		<div class="index4">
        			<!--笔记本/游戏本标题栏-->
        			<div class="index-bg">
        				<div class="laptop-lap">
                            <router-link to="/product/laptop">笔记本/游戏本</router-link>
                            <router-link to="/product/laptop">MORE+</router-link>
        				</div>
        			</div>
        			<!--笔记本/游戏本信息-->
        			<div class="index4-laptop">
        				<div class="laptop-img" style="overflow:hidden;clear:both;">
        					<!--左边大图-->
        					<div class="laptop-lbig goto" :class="animations1" :style="anmiDely1">
        						<img src="../assets/img/index/laptop1.jpg"/>
        					</div>
        					<!--右边6小图-->
        					<div class="laptop-rsmall">
        						<!--右一-->
        						<div class="laptop-r1-small">
        							<div class="rt-tsmall-sw goto" :class="animations" :style="anmiDely1">
        								<a href="#">
        									<img src="../assets/img/index/recommendation5.jpg"/>
        									<h4 title="14英寸四核独显轻薄商务便携笔记本电脑">14英寸四核独显轻薄商务便...</h4>
        								</a>
        								<p>金属游戏本，芯八代六核I7-...</p>
        								<span>￥5999</span>
        							</div>
        							<div class="rb-small-hc goto" :class="animations" :style="anmiDely1">
        								<a href="#">
        									<img src="../assets/img/index/recommendation4.jpg"/>
        									<h4 title="15.6英寸游戏笔记本 黑色 81HC0007CD">15.6英寸游戏笔记本 黑色 8...</h4>
        								</a>
        								<p>i5-8300H/Windo...</p>
        								<span>￥5899</span>
        								
        							</div>
        						</div>
        						<!--右二-->
        						<div class="laptop-r2-small">
        							<div class="rt-tsmall-zj goto" :class="animations" :style="anmiDely2">
        								<a href="#">
        									<img src="../assets/img/index/laptop6.jpg"/>
        									<h4 title="15.6英寸游戏笔记本 黑色 80WW000TCD">15.6英寸游戏笔记本 黑色8...</h4>
        								</a>
        								<p>金属游戏本，芯八代六核I7-...</p>
        								<span>￥5999</span>
        							</div>
        							<div class="rb-small-tx goto" :class="animations" :style="anmiDely2">
        								<a href="#">
        									<img src="../assets/img/index/recommendation2.jpg"/>
        									<h4 title="13.3英寸触控笔记本 天蝎灰 81CT0001CD">13.3英寸触控笔记本 天蝎灰...</h4>
        								</a>
        								<p>i5-8300H/Window...</p>
        								<span>￥7599</span>
        							</div>
        						</div>
        						<!--右三-->
        						<div class="laptop-r3-small">
        							<div class="rt-tsmall-zjz goto" :class="animations" :style="anmiDely3">
        								<a href="#">
        									<img src="../assets/img/index/laptop3.jpg"/>
        									<h4 title=" E580 笔记本电脑 20KSA001CD"> E580 笔记本电脑 20KSA00...</h4>
        								</a>
        								<p>i5-8300H/Windo...</p>
        								<span>￥10899</span>
        							</div>
        							<div class="rb-small-x2 goto" :class="animations" :style="anmiDely3">
        								<a href="#">
        									<img src="../assets/img/index/laptop2.jpg"/>
        									<h4 title=" X280 笔记本电脑 20KFA002CD"> X280 笔记本电脑 20KFA00...</h4>
        								</a>
        								<p>i5-8300H/Windo...</p>
        								<span>￥6599</span>
        							</div>
        						</div>
        					</div>
        				</div>				
        			</div>
        		</div>
        <!--*****************台式机/一体机***********************-->
        		<div class="index5">
        			<!--台式机/一体机标题栏-->
        			<div class="index-bg">
        				<div class="desktop-desk">
                            <router-link to="/product/desktop">台式机/一体机</router-link>
                            <router-link to="/product/desktop">MORE+</router-link>
        				</div>
        			</div>
        			<!--台式机/一体机信息-->
        			<div class="index5-desktop">
        				<div class="desktop-img" style="overflow:hidden;clear:both;">
        					<!--左边大图-->
        					<div class="desktop-lbig goto" :class="animations1" :style="anmiDely1">
        						<img src="../assets/img/index/desktop1.jpg"/>
        					</div>
        					<!--右边6小图-->
        					<div class="desktop-rsmall">
        						<!--右一-->
        						<div class="desktop-r1-small">
        							<div class="rt-tsmall-sw goto" :class="animations" :style="anmiDely1">
        								<a href="#">
        									<img src="../assets/img/index/desktop5.jpg"/>
        									<h4 title="惠普（HP）暗影精灵23代 游戏台式电脑主机"> 惠普（HP）暗影精灵23代...</h4>
        								</a>
        								<p>全新戴尔灵越酷睿8代超窄边框...</p>
        								<span>￥4999</span>
        							</div>
        							<div class="rb-small-hc goto" :class="animations" :style="anmiDely1">
        								<a href="#">
        									<img src="../assets/img/index/desktop6.jpg"/>
        									<h4 title="联想（Lenovo）天逸510S 第八代英特尔酷睿i3 个人商务台式电脑主机">联想（Lenovo）天逸510S...</h4>
        								</a>
        								<p>全新戴尔灵越酷睿8代超窄边框...</p>
        								<span>￥2999</span>-<span>￥5899</span>
        								
        							</div>
        						</div>
        						<!--右二-->
        						<div class="desktop-r2-small">
        							<div class="rt-tsmall-zj goto" :class="animations" :style="anmiDely2">
        								<a href="#">
        									<img src="../assets/img/index/desktop2.jpg"/>
        									<h4 title="惠普（HP）暗影精灵3代 游戏台式电脑主机（i7-8700 16G高频 1T+256GSSD GTX1060 6G独显 三年上门）">惠普（HP）暗影精灵3代 游...</h4>
        								</a>
        								<p>全新戴尔灵越酷睿8代超窄边框...</p>
        								<span>￥4099</span>-<span>￥5999</span>
        							</div>
        							<div class="rb-small-tx goto" :class="animations" :style="anmiDely2">
        								<a href="#">
        									<img src="../assets/img/index/desktop3.jpg"/>
        									<h4 title="戴尔(DELL)灵越3670台式电脑主机">戴尔（DELL）灵越3670台式...</h4>
        								</a>
        								<p>全新戴尔灵越酷睿8代超窄边框...</p>
        								<span>￥4099</span>-<span>￥5999</span>
        							</div>
        						</div>
        						<!--右三-->
        						<div class="desktop-r3-small">
        							<div class="rt-tsmall-zjz goto" :class="animations" :style="anmiDely3">
        								<a href="#">
        									<img src="../assets/img/index/desktop4.jpg"/>
        									<h4 title="宏碁（Acer）商祺SQX4270 140N 商用办公台式电脑主机">宏碁（Acer）商祺SQX427...</h4>
        								</a>
        								<p>全新戴尔灵越酷睿8代...</p>
        								<span>￥4999</span>-<span>￥5999</span>
        							</div>
        							<div class="rb-small-x2 goto" :class="animations" :style="anmiDely3">
        								<a href="#">
        									<img src="../assets/img/index/desktop3.jpg"/>
        									<h4 title="惠普（HP）暗影精灵3代 游戏台式电脑主机（i5-8400 16G高频 1T+128GSSD GTX1060 6G独显 三年上门）">惠普（HP）暗影精灵3代 游...</h4>
        								</a>
        								<p>GTX1060-6G”十”力...</p>
        								<span>￥5199</span>-<span>￥6999</span>
        							</div>
        						</div>
        					</div>
        				</div>				
        			</div>
        		</div>
        <!--*****************外设系列***************************-->
        		<div class="index6">
        			<!--外设系列题栏-->
        			<div class="index-bg">
        				<div class="perip-per">
                            <router-link to="/product/preip">外设系列</router-link>
        					<a href="#">
        						<span>鼠标</span>
        						<span>键盘</span>
        						<span>摄像头</span>
        					</a>
        				</div>
        			</div>
        			<!--外设系列信息-->
        			<div class="index6-perip">
        				<div class="perip-img" style="overflow:hidden;clear:both;">
        					<!--左边大图-->
        					<div class="perip-lbig goto">
        						<img src="../assets/img/index/peripheral1.jpg" :class="animations1" :style="anmiDely1"/>
        						<img src="../assets/img/index/peripheral3.jpg" :class="animations1" :style="anmiDely2"/>
        					</div>
        					<!--右边6小图-->
        					<div class="perip-rsmall">
        						<!--右一-->
        						<div class="perip-r1-small">
        							<div class="rt-tsmall-sw goto" :class="animations" :style="anmiDely1">
        								<a href="#">
        									<img src="../assets/img/index/peripheral2.jpg"/>
        									<h4 title="索尼（SONY）WH-1000XM3 高解析度无线蓝牙降噪耳机（触控面板 智能降噪 长久续航）黑色">索尼（SONY）WH-1000X...</h4>
        								</a>
        								<p>新款黑科技，超强降噪，佩戴更...</p>
        								<span class="del-line"><s>￥1699</s></span><span>￥2899</span>
        							</div>
        							<div class="rb-small-hc goto" :class="animations" :style="anmiDely1">
        								<a href="#">
        									<img src="../assets/img/index/peripheral5.jpg"/>
        									<h4 title="联想大红点M120Pro有线鼠标 台式机鼠标 笔记本鼠标">联想大红点M120Pro有线...</h4>
        								</a>
        								<p>经典大红点系列，按键灵敏，精...</p>
        								<span>￥99</span>
        								
        							</div>
        						</div>
        						<!--右二-->
        						<div class="perip-r2-small">
        							<div class="rt-tsmall-zj goto" :class="animations" :style="anmiDely2">
        								<a href="#">
        									<img src="../assets/img/index/peripheral8.jpg"/>
        									<h4 title="小米米家（MIJIA）智能摄像机 云台版 白色 1080P">小米米家（MIJIA）智能摄...</h4>
        								</a>
        								<p>1080P高清／ 360度云...</p>
        								<span>￥199</span>
        							</div>
        							<div class="rb-small-tx goto" :class="animations" :style="anmiDely2">
        								<a href="#">
        									<img src="../assets/img/index/peripheral7.jpg"/>
        									<h4 title="M330 无线静音鼠标 舒适曲线 黑色 M275升级版">M330 无线静音鼠标 舒适...</h4>
        								</a>
        								<p>舒适曲线 黑色 M275升级...</p>
        								<span>￥109</span>
        							</div>
        						</div>
        						<!--右三-->
        						<div class="perip-r3-small">
        							<div class="rt-tsmall-zjz goto" :class="animations" :style="anmiDely3">
        								<a href="#">
        									<img src="../assets/img/index/peripheral4.jpg"/>
        									<h4 title="Pico G2小怪兽2 VR一体机 4K高清视频 体感游戏 VR眼镜 3D头盔">Pico G2小怪兽2 VR一体机...</h4>
        								</a>
        								<p>【爆款直降】小怪兽2VR一体...</p>
        								<span>￥1899</span>
        							</div>
        							<div class="rb-small-x2 goto" :class="animations" :style="anmiDely3">
        								<a href="#">
        									<img src="../assets/img/index/peripheral6.jpg"/>
        									<h4 title="全尺寸背光机械游戏键盘 机械键盘 红轴 吃鸡键盘 绝地求生">全尺寸背光机械游戏键盘 机...</h4>
        								</a>
        								<p>无线光学鼠标，始于简约，磨砂...</p>
        								<span>￥99</span>
        							</div>
        						</div>
        					</div>
        				</div>				
        			</div>
        		</div>
        <!--*****************热评产品***************************-->
        		<div class="index7">
        			<!--标题-->
        			<div class="hot-product-title">
        				<div class="product-hot">
        					<a>热评产品</a>
        				</div>
        			</div>
        			<!--热评产品详细列表-->
        			<div class="hot-product-list">
        				<div class="product-list" style="overflow:hidden;">
        					<div class="product-tk goto" :class="animations" :style="anmiDely1">
        						<a href="#">
        							<img src="../assets/img/index/recommendation3.jpg"/>
        							<h4 title=" ThinkPad T480 笔记本电脑"> ThinkPad T480 笔记本电脑</h4>
        						</a>
        						<p>i5-8250U/Windows 10 家庭版/8GB/1T...</p>
        						<span class="p-color">￥8999</span>
        					</div>
        					<div class="product-x2 goto" :class="animations" :style="anmiDely2">
        						<a href="#">
        							<img src="../assets/img/index/hot1.jpg"/>
        							<h4 title="X280 笔记本电脑 20KFA002CD">X280 笔记本电脑 20KFA0...</h4>
        						</a>
        						<p>i5-8300H/Windows 10 家庭中文版/15.6...</p>
        						<span class="p-color">￥6599</span>
        					</div>
        					<div class="product-e5 goto" :class="animations" :style="anmiDely3">
        						<a href="#">
        							<img src="../assets/img/index/hot2.jpg"/>
        							<h4 title="E580 笔记本电脑 20KSA001CD">E580 笔记本电脑 20KSA0...</h4>
        						</a>
        						<p>i5-8300H/Windows 10 家庭中文版/15.6...</p>
        						<span class="p-color">￥10899</span>
        					</div>
        					<div class="product-hp goto" :class="animations" :style="anmiDely4">
        						<a href="#">
        							<img class="img-hp" src="../assets/img/index/desktop-sm-h23.jpg"/>
        							<h4 title="惠普（HP）暗影精灵23代 游戏台式电脑主机">惠普（HP）暗影精灵23代...</h4>
        						</a>
        						<p>全新戴尔灵越酷睿8代超窄边框一体机京东首发，IPS高清大屏，...</p>
        						<span class="p-color">￥4999</span>
        					</div>
        					<div class="product-dell goto" :class="animations" :style="anmiDely5">
        						<a href="#">
        							<img src="../assets/img/index/hot3.jpg"/>
        							<h4 title="戴尔(DELL)灵越3670台式电脑主机">戴尔(DELL)灵越3670台式...</h4>
        						</a>
        						<p>全新戴尔灵越酷睿8代超窄边框一体机京东首发，IPS高清大屏，...</p>
        						<span class="p-color">￥4099</span>-<span>￥5999</span>
        					</div>
        				</div>
        			</div>
        		</div>
        <!--*****************评测中心***************************-->
        		<div class="index8">
        			<div class="index8-title">
        				<div class="evaluating-title">
                            <router-link to="/evaluating">评测中心</router-link>
                            <router-link to="/evaluating">MORE+</router-link>
        				</div>
        			</div>
        			<div class="evaluating-list" style="overflow:hidden;">
        				<div class="eval-e4 goto" :class="animations" :style="anmiDely1">
        					<a href="#">
        						<img src="../assets/img/index/evaluating2.jpg"/>
        						<h4 title="大屏轻薄笔记本？17英寸LG gram开箱体验">大屏轻薄笔记本？17英寸LG gram...</h4>
        					</a>
        					<p>RTX 20系显卡登陆移动平台可谓是近期笔记本市场最大的事件，虽然第八代酷睿处理器的登场为移动平台带来了六核心的强悍规格...</p>
        				</div>
        				<div class="eval-e1 goto" :class="animations" :style="anmiDely2">
        					<a href="#">
        						<img src="../assets/img/index/evaluating3.jpg"/>
        						<h4 title="八千元RTX游戏本真香 惠普暗影精灵4 Pro">八千元RTX游戏本真香 惠普暗影精...</h4>
        					</a>
        					<p>RTX独显游戏本的到来是今年初PC领域最受关注的事件之一，而在众多首发产品中，惠普暗影精灵4 Pro可以说是最受追捧的型...</p>
        				</div>
        				<div class="eval-e2 goto" :class="animations" :style="anmiDely3">
        					<a href="#">
        						<img src="../assets/img/index/evaluating.jpg"/>
        						<h4 title="一眼即世界 92%屏占比华硕灵耀U 2代体验">一眼即世界 92%屏占比华硕灵耀U...</h4>
        					</a>
        					<p>华硕顽石热血版YX570U相信很多人都有了解，这款产品采用酷睿低压处理器+GTX1050显卡的配置组合，相比游戏本拥有更...</p>
        				</div>
        				<div class="eval-e3 goto" :class="animations" :style="anmiDely4">
        					<a href="#">
        						<img src="../assets/img/index/evaluating1.jpg"/>
        						<h4 title="实测：数据佐证RTX Max-Q版与标准版差多少">实测：数据佐证RTX Max-Q版与标...</h4>
        					</a>
        					<p>与10系显卡先推标准版再推Max-Q版不同，20系RTX显卡登陆游戏本之时，同时推出了标准版和Max-Q版。近期收到多名...</p>
        				</div>
        			</div>
        		</div>
        	</div>
        <!-- ********************************脚部*************************** -->
        <sm-footer></sm-footer>
    </div>
    
   
</template>

<script>
    export default{
       data(){
           return{
            animations:{
               anim1:true,
               anim2:false
            },
            animations1:{
               anim1:true,
               anim3:false
            },
            anmiDely1:{animationDelay:"0s"},
            anmiDely2:{animationDelay:"0s"},
            anmiDely3:{animationDelay:"0s"},
            anmiDely4:{animationDelay:"0s"},
            anmiDely5:{animationDelay:"0s"},
           }
       },
       // 定义页面滚动效果函数
       created() {
            window.addEventListener('scroll',this.pageSetup)
       },
       methods:{
           // 当滚轮滑动到当前位置，当前位置图片样式发生变化
           pageSetup(){
               // 获取滑轮滚动过后到顶部的距离
               var ah=document.documentElement.scrollTop || document.body.scrollTop
               console.log(ah)
               // 获取浏览器可视窗口高度
               var ch=document.documentElement.clientHeight ||document.body.clientHeight
               console.log(ch)
               // 获取目标元素在可视窗口的距离
               var objHeight=document.querySelectorAll(".goto")
               // for(var item of objHeight){
                for(var i=0;i<objHeight.length;i++){
                  console.log(objHeight[i].offsetTop)
                  if(ch+ah-500>objHeight[i].offsetTop){
                      this.animations={
                        anim1:false,
                        anim2:true 
                      }
                      this.animations1={
                        anim1:false,
                        anim3:true 
                      }
                      this.anmiDely2.animationDelay="0.1s";
                      this.anmiDely3.animationDelay="0.2s";
                      this.anmiDely4.animationDelay="0.3s";
                      this.anmiDely5.animationDelay="0.4s";
                  }
               }
               
               
           }
       },
    }
</script>

<style scoped>
    @import url("../assets/css/index.css");
</style>
