(function(){
    // 笔记本商品详情页、台式机商品详情页**************************************
    // 搭配套餐界面
    // 当点击任意套餐时，总价显示出来，没有选中时，隐藏********************
    var shop=document.getElementById("shop");
    var combo=document.querySelectorAll("#shop>p>input");
    var dis1=document.querySelector("#shop>.con-total");
    // 找到总价所在位置
    var total=document.querySelectorAll("#shop>.con-total")[0].children[1].children[1];
    for(var p of combo){
        p.onclick=function(){
            var input=this;
            // 判断是否有选中状态的，如果没有，总价就隐藏
            var unchb=document.querySelector("#shop>p>input:checked");
            if(unchb==null){
                dis1.style.height="0px";
            }else{
                dis1.style.height="60px";
            }
           // 获取所点套餐的价格
           var tprice=parseInt(input.nextElementSibling.getAttribute("data-price"));
           // 找到套餐价格内容
           var t=document.querySelectorAll("#shop>.con-total>p>span")[1]; 
           var t1=parseInt(t.innerHTML.slice(1));
           // 查找当前商品价格
           var pprice=shop.previousElementSibling.children;
           var pprice1=parseInt(pprice[0].innerHTML.slice(1));
           if(input.checked==true){
               t1+=tprice;
           }else{
               t1-=tprice; 
           }
           t.innerHTML=`¥${t1}`;
           pprice1+=t1;
           total.innerHTML=`¥${pprice1}`;
        }
    }
    
    
    // 当点击+，总价增加，当点击-，总价减少**************************************
    var button=document.querySelectorAll("#shop>.con-shop>button")
    var price=parseFloat(
    	total.innerHTML.slice(1)
    );
    for(var btn of button){
        btn.onclick=function(){
           var btn=this;
            //   先找爹td 再找爹下第3个孩子span
           var span=btn.parentNode.children[2];
           var n=parseInt(span.innerHTML);
           if(btn.innerHTML=="+"){//如果点的是+
           	n++;//就+1
           }else if(n>1){//否则 如果点的是-，且内容>1
           	n--;//才能-1
           }
           //将修改后的内容再放回span的内容中
           span.innerHTML=n;
           // 总价变化
           var price1=price*n;
           total.innerHTML=`¥${price1}`;
        }
    }
    //商品详情部分。当点击三个按钮，下面的信息也随之变化****************************
    // 获取触发事件
    var des=document.querySelectorAll("#message>.msgs-nav>ul li a")
    var divs=document.querySelectorAll("#message>.msgs-desc>div")
    //console.log(div)
    var i=10;
    for(var item of des){
        item.onclick=function(){
            var a=document.querySelectorAll("#message>.msgs-nav>ul li a.active")
            if(a.length!=0){
                a[0].className="";
            }
            var item=this;
            item.className="active"
            //当点击按钮后，对应的信息也发生变化
            //获得保存在a上的自定义扩展属性data-target中的id名
            var id=this.getAttribute("data-target");
            for(var i=0;i<divs.length;i++){
                var did=divs[i].getAttribute("id")
                //console.log(did)
                if(id==did){
                    divs[i].style.display="block";
                }else{
                    divs[i].style.display="none";
                }
            }
        }
    }
    
})()