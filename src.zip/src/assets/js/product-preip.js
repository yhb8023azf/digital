(function(){
    // 外设系列商品页**************************************************************
    //在中屏的时候，class值为dis的显示出来，当点击a标签，导航显示出来
    var cl=document.querySelector("#r1>.left1 .dis>a"); 
    cl.onclick=function(){
        var sp=document.querySelector("#r1>.left1 .dis>a>span");
        var ul=document.querySelector("#r1>.left1 ul");
        // var left1=document.querySelector("#run>.left1 ul.dis1");
         //console.log(ul)
         if( sp.innerHTML=="按分类浏览"){
            sp.innerHTML="关闭";
            ul.className="dis2";
         }else{
            sp.innerHTML="按分类浏览";
            ul.className="dis1"; 
         }
    }
    
})();