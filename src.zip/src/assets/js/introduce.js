// 引入头和脚
$(function(){
    // 引入头
    $.ajax({
        url:"header.html",
        type:"get",
        //data可有可无
        //dataType:"json"
        success:function(result){
            //console.log(result);
            $(result).replaceAll("#header");
            $(`<link rel="stylesheet" type="text/css" href="css/header.css"/>`).appendTo("head");
        }
    })
    // 引入脚
    $.ajax({
        url:"footer.html",
        type:"get",
        //data可有可无
        //dataType:"json"
        success:function(result){
            //console.log(result);
            $(result).replaceAll("#footer");
            $(`<link rel="stylesheet" type="text/css" href="css/footer.css"/>`).appendTo("head");
        }
    })
    
})