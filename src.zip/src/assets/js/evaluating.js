(function(){
    //当点击左侧导航栏，点击后，字体变为红色，背景为灰色 
    var run=document.querySelectorAll("#run ul>li>a");
    for(var elem of run){
        elem.onclick=function(){
          var elem=this;
          var c=document.querySelectorAll("#run ul>li>a.click1");
          //console.log(c)
          if(c.length!=0){
              c[0].className="click";
          }
              elem.className="click1"
          
        }
    } 
   
    
    
    
    // 当点击加载更多按钮时，class为show的li显示出来
    var btn=document.querySelector("#conceal>div.but>a");
    //console.log(btn);
    btn.onclick=function(){
        var li=document.querySelector("#conceal>ul>.show");
        var but=document.querySelector("#conceal>div.but");
        setTimeout(function(){
            li.style.display="block";
            but.style.display="none";
        },800)   
    }
    
    
    //在中屏的时候，class值为dis的显示出来，当点击a标签，导航显示出来
    var cl=document.querySelector("#run>.left1 .dis>a"); 
    cl.onclick=function(){
        var sp=document.querySelector("#run>.left1 .dis>a>span");
        var ul=document.querySelector("#run>.left1 ul");
        // var left1=document.querySelector("#run>.left1 ul.dis1");
         //console.log(ul)
         if( sp.innerHTML=="按分类浏览"){
            sp.innerHTML="关闭";
            ul.className="dis2";
         }else{
            sp.innerHTML="按分类浏览";
            ul.className="dis1"; 
         }
        
    }
     
    
})()