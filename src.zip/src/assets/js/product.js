// 笔记本和台式商品页面**************************************************************
(function(){
	// 在笔记本和台式机商品页，当在中屏的时候，点击“筛选”按钮，导航栏出现*****************
	var pbtn=document.querySelector("#sx>.nav-second a>span");
	var d=document.getElementById("btn2")
	var rb=document.getElementById("btn1")
    var x=document.querySelector("#btn1 .close1>span");
	pbtn.onclick=function(){
		d.style.display="block";
		rb.className="ri-con1";
        x.style.display="block";
	}
	// 当class值为close1显示时，点击x,将导航栏关闭
	x.onclick=function(){
		d.style.display="none";
		rb.className="ri-con";
        x.style.display="none";
	}
	//console.log(btn);
	
})();