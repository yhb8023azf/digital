import Vue from 'vue'
import App from './App.vue'
import router from './router' 

 //配置axios模块
import axios from 'axios'
//6配置axios基础路径
axios.defaults.baseURL="http://127.0.0.1:3000/" //后端监听端口
//7配置axios保存session信息
axios.defaults.withCredentials=true
//8将axios注册到vue实例中
//由于axios不支持vue，需要将其添加到vue原型上
Vue.prototype.axios=axios

//引入vuex模块
import Vuex from "vuex"
//注册Vuex
Vue.use(Vuex);
// 创建Vuex实例存储对象
var store=new Vuex.Store({
    state:{cartCount:0},      //共享数据
    mutations:{               //添加修改数据函数 
        increment(state){     //购物车数量加1
            state.cartCount++;
        },
        clear(state){         //清空购物车
            state.cartCount=0;
        }
    },  
    getters:{                  // 添加函数通过函数获取共享数据
        getCartCount(state){
            return state.cartCount;
        }
    },    
    actions:{}     //添加函数通过函数调用使用异步操作
})

import Header from './components/Header'
import Footer from './components/Footer'

Vue.component("sm-header",Header);
Vue.component("sm-footer",Footer);
Vue.config.productionTip = false

// 跳转后返回顶部
router.afterEach((to,from,next) => {
  window.scrollTo(0,0);
})
    
new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
