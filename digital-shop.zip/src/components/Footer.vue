<template>
    <footer>
    <div class="footer font">
    	<div class="dist">
    		<div class="f-top">
    			<img src="../assets/img/headfoot/foot4.png" class="f-img2"/> 
    			<span class="">3年免费保修</span>
    		</div>
    		<div class="f-top">
    			<img src="../assets/img/headfoot/foot5.png" class="f-img2"/>
    			<span class="">7天无理由退款</span>
    		</div>
    		<div class="f-top">
    			<img src="../assets/img/headfoot/foot2.png" class="f-img2"/>
    			<span class="">15天免费换货</span>
    		</div>
    		<div class="f-top">
    			<img src="../assets/img/headfoot/foot3.png" class="f-img2"/>
    			<span class="">满150元包邮</span>
    		</div>
    		<div class="f-top">
    			<img src="../assets/img/headfootlogreg/foot1.png" class="f-img2"/>
    			<span class="">200余家售后网点</span>
    		</div>
    	</div>
    	<div class="row">
    		<div class="col-9">
    			<div class="row1">
    				<div class="col-2">
    					<ul class="list-group">
    						<li><h3>帮助中心</h3></li>
    						<li><a href="#">购物指南</a></li>
    						<li><a href="#">支付方式</a></li>
    						<li><a href="#">配送方式</a></li>
    					</ul>
    				</div>
    				<div class="col-2">
    					<ul class="list-group">
    						<li><h3>服务支持</h3></li>
    						<li><a href="#">保修政策</a></li>
    						<li><a href="#">服务标准</a></li>
    						<li><a href="#">退换货政策</a></li>
    					</ul>
    				</div>
    				<div class="col-2">
    					<ul class="list-group">
    						<li><h3>关于我们</h3></li>
    						<li><a href="#">公司介绍</a></li>
    						<li><a href="#">加入我们</a></li>
    						<li><a href="#">联系我们</a></li>
    					</ul>
    				</div>
    				<div class="col-2">
    					<ul class="list-group">
    						<li><h3>新闻资讯</h3></li>
    						<li><a href="#">营业执照</a></li>
    						<li><a href="#">新闻动态</a></li>
    						<li><a href="#">版权申明</a></li>
    					</ul>
    				</div>
    				<div class="col-2">
    					<ul class="list-group">
    						<li><h3>线下门店</h3></li>
    						<li><a href="#">法律申明</a></li>
    						<li><a href="#">隐秘政策</a></li>
    						<li><a href="#">服务条款</a></li>
    					</ul>
    				</div>
    				<div class="col-2 border-right">
    					<ul class="list-group">
    						<li><h3 class="pl-1">微信公众号</h3></li>
    						<li>
    							<img src="../assets/img/headfoot/foot6.jpg"/>
    						</li>
    					</ul>
    				</div>
    			</div>
    		</div>
    		<div class="col-3">
    			<h4>4006-999-999</h4>
    			<h5>周一至周日 8:00-18:00</h5>
    			<div class="mar">
                    <button type="button">24小时在线客服</button>
    			</div>
    		</div>
    	</div>
    </div>
    <div class="bg">
    	<p>版权所有2056-2086 数码家电在线商城模板  沪ICP备000000000号-0</p>
    </div>
    </footer>
</template>

<script>
</script>

<style>
    @import url("../assets/css/footer.css");
</style>
