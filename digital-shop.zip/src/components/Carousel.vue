<template>
    <div>
        <div id="carousel">
            <!-- 背景轮播 -->
            <div class="bg-lunbo1" :style="bgCar1"></div>
            <div class="bg-lunbo2" :style="bgCar2"></div>
        	<div class="navi">
        		<ul>
        			<li class="li-first">
                        <div class="">
                            <span>全部分类</span>
                        </div>
                        <span class="back"></span>
        			</li>
        			<li>
                        <router-link to="/laptop/1">游戏笔记本</router-link>
        			</li>
        			<li>
        				<router-link to="/desktop/2">游戏台式机</router-link>
        			</li>
        			<li>
        				<router-link to="workcomputer">办公电脑</router-link>
        			</li>
        			<li>
                       <router-link to="/preip/3">游戏鼠键/耳机</router-link>
        			</li>
        			<li>
        				<a href="#">高清摄像头</a>
        			</li>
        			<li>
        				<a href="#">VR专区</a>
        			</li>
        			<li>
                        <router-link to="/drivedown">驱动下载</router-link> 
        			</li>
        			<li>
                        <router-link to="/aftersales">保修政策</router-link>
        			</li>
        		</ul>
        	</div>
        </div>
    </div>
</template>

<script>
    export default{
        data(){
            return{
              bgCar1:{opacity:0},
              bgCar2:{opacity:1},
              bglun:true
            }
        },
        created() {
            this.load();
        },
        methods:{
            load(){
                setTimeout(()=>{
                    if(this.bglun==true){
                        this.bgCar1.opacity=0;
                        this.bgCar2.opacity=1;
                        this.bglun=false;
                    }else{
                        this.bgCar1.opacity=1;
                        this.bgCar2.opacity=0;
                        this.bglun=true;
                    }
                },100)
                setInterval(()=>{
                    if(this.bglun==true){
                        this.bgCar1.opacity=0;
                        this.bgCar2.opacity=1;
                        this.bglun=false;
                    }else{
                        this.bgCar1.opacity=1;
                        this.bgCar2.opacity=0;
                        this.bglun=true;
                    }
                },3000)
            }
        }
    }
</script>

<style scoped>
    #carousel{
        width:100%;height:auto;
        position: relative;
        }
    /*轮播背景图*********************************************/
    .bg-lunbo1{
        position:absolute;
        z-index:2;
    	width:100%;
    	background:url(../assets/img/index/bg2.jpg);
    	background-repeat:no-repeat;
    	background-size:cover;
    	background-position:center center;
    	background-attachment:scroll;
        transition:opacity 2s ease-in-out;
    }
    .bg-lunbo2{
        position:absolute;
        z-index:1;
    	width:100%;
    	background:url(../assets/img/index/bg1.jpg);
    	background-repeat:no-repeat;
    	background-size:cover;
    	background-position:center center;
    	background-attachment:scroll;
        transition:opacity 2s ease-in-out;
    }
    /*大屏*/
    @media only screen and (min-width:992px) {
    /*轮播和导航**********************************************/
    #carousel{height:516px;}
    .bg-lunbo1,.bg-lunbo2{height:516px;}
    .navi{
        padding:0 100px;
        position: absolute;
        z-index:10;
        top:0px;
        width:85%;
    }
    .navi ul li{display:block;
    	width:18%;height:56.2px;
    	background:#252525;
    	border-top:1px solid #3a3a3a;
    	min-height:1px;
        line-height:56px;
        vertical-align: middle;
        text-align:left;
        padding-left:30px;
    }
    .navi .li-first{
    	background-color:#00EEF2;
    	color:#000000;
    	border-top:1px solid #00EEF2;
    	font-size:14px;
        display:flex;
        align-items: center;
        
    }
    #carousel .navi .li-first .back{
        width:15px;height: 15px;
            background-image:url(../assets/img/headfoot/buttom.png);
            background-size:15px 15px;
            margin-left:20px;
    }
    .navi ul li a{
    	color:#ccc;
    	font-size:14px;
    }
    .navi ul li+li:hover{background-color:#3a3a3a;}
    
    }
    /*中小屏*/
    @media only screen and (max-width:991px) {
    /*轮播和导航*/
    
    .bg-lunbo1,.bg-lunbo2{height:89px;}
    .navi li{display:none;}
    }
    
    
</style>
