<template>
    <div>
        <!-- 商品详情页添加购物车数量按钮 -->
        <button type="button" id="shop_btn1" @click="addCart">加入购物车</button>
        <button type="button" id="shop_btn2" @click="jian()">-</button>
        <span id="shop_span">{{count}}</span>
        <button type="button" id="shop_btn3" @click="add()">+</button>
    </div>
</template>

<script>
    export default{
        data(){
            return{
                count:1
            }
        },
        methods:{
           addCart(){
               
           },
           add(){
               this.count++;
           },
            jian(){
               if(this.count>1){
                   this.count--;
               } 
            }
        }
    }
</script>

<style>
    #shop_btn1{
        display:inline-block;
        color:#000000;
        border-color: #00eef3;
        background-image: none;
        background-color: #00eef3;
        padding:14px 40px;
        margin-right:30px;
        cursor:pointer;
    }
    @media (max-width:576px) {
       #shop_btn1{padding:14px 25px;margin-right:25px;} 
    }
    #shop_btn2,#shop_btn3{
        height:46px;width:38px;
        background:#fff;
        border:1px solid #E2E3E5;
        margin-bottom:2px;
        cursor:pointer;
    }
    #shop_span{
        display:inline-block;
        border: 1px solid #E2E3E5;
        height:44px;width:38px;
        text-align:center;
        line-height:41px;
    }
</style>
