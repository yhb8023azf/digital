<template>
    <div>
        <div id="dragbar">
            <div id="long_bar">
                <div id="small_bar"></div>
                <span class="btn"></span>
                <span class="btn block1"></span>
            </div>
        </div>
       <div class="price">价格：<span id="min_price">¥0</span>-<span id="max_price">¥10999</span></div> 
        
    </div>
</template>

<script>
    export default{
        data(){
            return{
                        
            }
        },
        mounted() {
            (function(){
                var longbar=document.getElementById("long_bar");
                var smallbar=document.getElementById("small_bar");
                var arrbtn=longbar.getElementsByTagName("span");
                var minP=document.getElementById("min_price");
                var maxP=document.getElementById("max_price");
                // 获取价格
                var minprice=parseInt(minP.innerHTML.slice(1));
                var maxprice=parseInt(maxP.innerHTML.slice(1));
                var total=maxprice-minprice,Isclick=false,zindex=2;
                smallbar.style.width=100+"%";
                smallbar.style.left=0;
                arrbtn[0].style.left=0;
                arrbtn[1].style.left=100+"%";
                var maxwidth=longbar.offsetWidth;//最大移动值
                // 点击左边按钮
                arrbtn[0].onmousedown=function(e){
                    Isclick=true;
                    this.style.zIndex=++zindex;
                    var x=(e||window.event).clientX;//取点击位置的X轴长度值
                    console.log(x)
                    //按钮的x轴长度值
                    var lenght=this.offsetLeft+(this.offsetWidth/2-1);
                    var btn2lenght=arrbtn[1].offsetLeft+(arrbtn[1].offsetWidth/2-1);
                    var maxlenght=Math.min(maxwidth,btn2lenght);
                    var btn=this;
                    document.onmousemove=function(e){
                        if(Isclick){
                            var thisX=(e||window.event).clientX;//当前移动位置的X轴长度值
                            //被点击按钮从开始位置移动的长度
                            var golenght=Math.min(maxlenght,Math.max(0,lenght+(thisX-x)));
                            var leftVal=(golenght/maxwidth)*100;
                            btn.style.left=leftVal+"%";//使用百分比
                            smallbar.style.left=btn.style.left;
                            smallwidth();
                            price(minP,leftVal);
                        }else{
                            return false;
                        }
            //window.getSelection ? window.getSelection.removeAllRanges : document.selection.empty;//判断是否有选中项
                    }
                    //onlosecapture当元素失去鼠标移动所形成的选择焦点时触发此事件
                    document.onmouseup=window.onblur=btn.onlosecapture=function(){
                        Isclick=false;
                        btn.releaseCapture && btn.releaseCapture();
                    };
                    this.setCapture && this.setCapture();
                    return false;
                }
                // 点击右边拖动按钮
                arrbtn[1].onmousedown=function(e){
                    Isclick=true;
                    this.style.zIndex=++zindex;
                    var x=(e||window.event).clientX;
                    var lenght=this.offsetLeft+(this.offsetWidth/2-1);
                    var btn1lenght=arrbtn[0].offsetLeft+(arrbtn[0].offsetWidth/2-1);
                    var minlenght=Math.max(0,btn1lenght);
                    var btn1=this;
                    document.onmousemove=function(e){
                        if(Isclick){
                            var thisX=(e||window.event).clientX;
                            var golenght=Math.max(minlenght,Math.min(maxwidth,lenght+(thisX-x)));
                            var leftVal=(golenght/maxwidth)*100;
                            btn1.style.left=leftVal+"%";
                            smallwidth();
                            price(maxP,leftVal);
                        }else{
                            return false;
                        }
            //window.getSelection ? window.getSelection.removeAllRanges : document.selection.empty;
                    }
                    document.onmouseup=window.onblur=btn1.onlosecapture=function(){
                        Isclick=false;
                        btn1.releaseCapture && btn1.releaseCapture();
                    };
                    this.setCapture && this.setCapture();
                    return false;
                }
                function smallwidth(){
                var left=parseFloat(arrbtn[0].style.left);
                var right=parseFloat(arrbtn[1].style.left);
                smallbar.style.width=(right-left>0?Math.floor(right-left):0)+"%";
                }
                function price(obj,leftVal){
                var p=parseInt((total/100)*leftVal)+minprice;
                if(p>minprice && p<maxprice){p=p%5>3?p+(5-(p%5)):p-(p%5)}
                obj.innerHTML="¥"+p;
                }
            })()
        },
        
    }
</script>

<style scoped>
    #dragbar{
        position:relative; 
        background:#00EEF2;
        border-radius:2px;
        height:8px;
    }
    #long_bar{ 
        height:8px; 
        border-radius:4px;
    }
    #small_bar{ 
        background:#000; 
        position:absolute; 
        z-index:1; 
        top:1px; 
        height:8px; 
        line-height:8px; 
        overflow:hidden;
        width:100%;
        left:0;
    }
    #long_bar .btn{ 
        width:18px; 
        z-index:2; 
        position:absolute; 
        height:18px; 
        cursor:pointer; 
        top:-7px; 
        margin-left:-9px; 
        background:#000; 
        border-radius:4px; 
        border:1px solid #000;}
    .price{ 
        font-size:14px;
        color:#000; 
     }
    .block1{left:100%;}
    @media (min-width:992px) {
       #small_bar{top:-15px}
       #dragbar{ width:90%; margin-left:10px;margin-bottom:15px;}
    }
    @media (max-width:991px) {
        #dragbar{margin:15px 0px;}
        #small_bar{top:0px}
        #dragbar{ width:100%;}
    } 
</style>
