import Vue from 'vue'
import Router from 'vue-router'
import Index from './views/Index'
import ProductLaptop from './views/ProductLaptop'
import ProductDesktop from './views/ProductDesktop'
import ProductPreip from './views/ProductPreip'
import DetailsLaptop from './views/DetailsLaptop'
import DetailsDesktop from './views/DetailsDesktop'
import DetailsPreip from './views/DetailsPreip'
import AfterSales from './views/AfterSales'
import Evaluating from './views/Evaluating'
import DriveDown from './views/DriveDown'
import Login from './views/Login'
import Register from './views/Register'
import WorkComputer from './views/WorkComputer'
import EvaluatBaqian from './views/EvaluatBaqian'
import EvaluatYiyan from './views/EvaluatYiyan'
import EvaluatDaping from './views/EvaluatDaping'
import EvaluatShice from './views/EvaluatShice'
import EvaluatRtx from './views/EvaluatRtx'
import EvaluatRuibu from './views/EvaluatRuibu'
import EvaluatApex from './views/EvaluatApex'
import EvaluatJiju from './views/EvaluatJiju'
import ProductSearch from './views/ProductSearch'
import NotFound from './views/NotFound'
import Cart from './views/Cart'

Vue.use(Router)

export default new Router({
  mode:'history',
  routes: [
    {path: '/',component:Index},
    {path: '/laptop/:family_ids',component:ProductLaptop,props:true},
    {path: '/desktop/:family_ids',component:ProductDesktop,props:true},
    {path: '/preip/:family_ids',component:ProductPreip,props:true},
    {path: '/laptop/detail/:lid',component:DetailsLaptop,props:true},
    {path: '/desktop/detail/:did',component:DetailsDesktop,props:true},
    {path: '/preip/detail/:pid',component:DetailsPreip,props:true},
    {path: '/aftersales',component:AfterSales},
    {path: '/evaluating',component:Evaluating},
    {path: '/drivedown',component:DriveDown},
    {path: '/login',component:Login},
    {path: '/register',component:Register},
    {path: '/workcomputer',component:WorkComputer},
    {path: '/evaluating/baqian',component:EvaluatBaqian},
    {path: '/evaluating/daping',component:EvaluatDaping},
    {path: '/evaluating/yiyan',component:EvaluatYiyan},
    {path: '/evaluating/ruibu',component:EvaluatRuibu},
    {path: '/evaluating/shice',component:EvaluatShice},
    {path: '/evaluating/jizhi',component:EvaluatJiju},
    {path: '/evaluating/apex',component:EvaluatApex},
    {path: '/evaluating/rtx',component:EvaluatRtx},
    {path: '/product/search/:kw',component:ProductSearch,props:true},
    {path: '/cart',component:Cart},
    {path:"*", component:NotFound}
  ]
})
