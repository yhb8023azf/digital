<template>
    <div>
        <sm-header></sm-header>
        <div class="details-preip font">
           <!--*******************评测中心导航栏**********************-->
           		<div class="preip-first">
           			<div class="nav">
           				<router-link to="/">首页</router-link>
           				<span>&gt;</span>
           				<span><router-link to="/product/preip">外设系列</router-link></span>
           				<span>&gt;</span>
                        <span><a href="">游戏耳机</a></span>
                        <span>&gt;</span>
           				<span v-text="preipList.title"></span>
           			</div>
           		</div>
           <!--************************************内容部分******************************-->
           		<div class="preip-second">
           			<div class="preip-container">
           				<div class="content">
           					<div class="con-img">
                                   <!-- 描述上部分右侧 -->
           						<div class="con-right">
           					 		<div class="con-right-t">
           					 			<img :src="preipPicLg[i]" class="conImg1"/>
                                        <!-- 小方块 -->
                                         <div id="pmask"  :class="{'dNone':!maskShow1}" :style="pmaskStyle"></div>
                                         <!-- 遮罩层 -->
                                         <div id="psuper-mask"  @mouseover="toggle1" @mouseout="toggle1" @mousemove="maskMove1"></div>
                                         <!-- 显示背景图 -->
                                         <div id="pdiv-lg" :class="{'dNone':!maskShow1}" :style="{'background-image':`url(${preipPicLg[i]})`,'background-position':pbgPosition}"></div>
           					 		</div>
           					 		<div class="con-right-b">
                                        <ul>
                                           <li v-for="(p,i) of preipPicSm" :key="i" @click="changei(i)">
                                             <img :src="p" class="preipImg">
                                           </li>
                                        </ul>
           					 		</div>
           					 	</div>
                    <!--***************************** 描述上部分左侧**************************** -->
           					 	<div class="con-left">
           					 		<h1 v-text="preipList.title"></h1>
           					 		<div class="big-line">
           					 			<div></div>
           					 		</div>
           					 		<p class="con-details" v-text="preipList.subtitle">新款黑科技，超强降噪，佩戴更舒适，快充更方便！</p>
           					 		<p class="con-price">
                                        <del :style="dNone"><span>¥2899</span></del>
                                        <span style="margin-left:10px;" v-cloak>¥{{preipList.price}}</span>
                                    </p>
           					 		<form action="" class="con-cart">
                                        <div class="con-shop">
                                          <!-- 商品详情页添加购物车数量按钮 -->
                                          <button type="button" id="shop_btn4" 
                                          @click="addCart"
                                          :data-pid="preipList.pid"
                                          :data-title="preipList.title"
                                          :data-price="preipList.price"
                                          :data-img="preipList.img"
                                          >加入购物车</button>
                                          <button type="button" id="shop_btn5" @click="jian()">-</button>
                                          <span id="shop_span2">{{count}}</span>
                                          <button type="button" id="shop_btn6" @click="add()">+</button>
                                        </div>
                                    </form>   
                                       <div class="con-lid">
                                           <p><span>商品编号：</span><span> SONY225145</span></p>
                                           <p><span>分类：</span><span v-text="preipList.category">游戏耳机</span></p>
                                       </div>                           
           					 	</div>
           					</div> 
           				</div>
           			</div>
           		</div>
                <!--************************* 商品描述部分 ********************************-->
                <div class="preip-three">
                    <div class="preip-msg">
                        <div class="msgs">
                            <div class="msgs-nav">
                                <ul>
                                    <li><a href="javascript:;" :class="pactives[0]" @click="dpMsg(0)">描述</a></li>
                                    <li><a href="javascript:;" :class="pactives[1]" @click="dpMsg(1)">用户评价(0)</a></li>
                                </ul>
                            </div>
                            <div class="msgs-desc">
                                <div class="desc-cont" :style="pcontents[0]">
                                    <div class="desc-img">
                                        <img :src="preipPicLg[0]" >
                                    </div>
                                </div>
                                <div class="desc-com" :style="pcontents[1]">
                                    <div></div>
                                    <p>目前还未有评论</p>
                                    <p>只有买过此商品的客户登录后才能发表评论</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ********************相关商品****************************************** -->
                <div class="preip-four">
                    <div class="preip-pro">
                        <div class="relevant-pro">
                            <div class="pro-nav1">
                                <h2>热门商品</h2>
                            </div>
                            <ul>
                                <div class="pro-li1"> 
                                    <li>
                                        <div class="pro-1">
                                            <a href="" title="联想大红点M120Pro有线鼠标 台式机鼠标 笔记本鼠标">
                                            <img src="../assets/img/details_preip/md/m120p-md.jpg" class="p-img"/></a>
                                        </div>
                                        <div class="pro-2">
                                            <a href="#">联想大红点M120Pro有线鼠标 台式机鼠标 笔记本鼠标</a>
                                            <p><span>¥99</span></p>
                                        </div>
                                    </li>
                                     
                                    <li class="p-li">
                                        <div class="pro-1">
                                            <a href="" title="M330 无线静音鼠标 舒适曲线 黑色 M275升级版">
                                            <img src="../assets/img/details_preip/md/m330-md.jpg" class="p-img"/></a>
                                        </div>
                                        <div class="pro-2">
                                            <a href="#">M330 无线静音鼠标 舒适曲线 黑色 M275升级版</a>
                                            <p><span>¥109</span></p>
                                        </div>
                                    </li> 
                                </div>
                                <div class="pro-li2">
                                    <li>    
                                        <div class="pro-1">
                                           <a href="" title=" Pico G2小怪兽2 VR一体机 4K高清视频 体感游戏 VR眼镜 3D头盔">
                                            <img src="../assets/img/details_preip/sm/pico-sm.jpg" class="p-img"/></a>
                                        </div>
                                        <div class="pro-2">
                                            <a href="#">Pico G2小怪兽2 VR一体机 4K高清视频 体感游戏 VR眼镜 3D头盔</a>
                                            <p><span>¥1899</span></p>
                                        </div>
                                                                          
                                    </li>
                                    <li class="p-li">
                                        <div class="pro-1">
                                            <a href="" title=" 小米米家（MIJIA）智能摄像机 云台版 白色 1080P">
                                            <img src="../assets/img/details_preip/md/mijia-md.jpg" class="p-img"/></a>
                                        </div>
                                        <div class="pro-2">
                                            <a href="#"> 小米米家（MIJIA）智能摄像机 云台版 白色 1080P</a>
                                           <p><span>¥199</span></p>
                                        </div>
                                    </li>
                                </div>	
                            </ul>
                        </div>
                    </div>
                </div> 
        </div>
        <sm-footer></sm-footer>
    </div>
</template>

<script>
    import ShopBtn from '../components/ShopBtn.vue'
    export default{
        data(){
            return{
                // 描述部分
                pactives:[
                    {active:true},
                    {active:false}
                ],
                pcontents:[
                    {display:"block"},
                    {display:"none"}
                ],
                // 保存从数据库得到的数据
                preipList:{},
                pics:[
                    {md:"",sm:"",lg:""},//防止首次加载时pics[0].md报错
                    {md:"",sm:"",lg:""},
                    {md:"",sm:"",lg:""},
                    {md:"",sm:"",lg:""},
                    {md:"",sm:"",lg:""},
                ],
                preipPicSm:[],
                preipPicLg:[],
                dNone:{display:"none"},
                i:0,   //表示显示第几张图片
                maskShow1:false,
                pmaskStyle:{
                  left:0,
                  top:0
                },
                count:1,
                
            }
        },
        props:["pid"],
        created() {
            this.load();
        },
        computed:{
            pbgPosition(){
                var left=parseInt(this.pmaskStyle.left);
                var top=parseInt(this.pmaskStyle.top);
                 return `-${left*16/8}px -${top*16/8}px`
               },
        },
        methods:{
            addCart(e){
                var pid=e.target.dataset.pid;
                var p=e.target.dataset.price;
                var n=e.target.dataset.title;
                var i=e.target.dataset.img;
                console.log(pid)
                console.log(p)
                console.log(i)
                console.log(n)
                var obj={pid:pid,price:p,title:n,img:i}
                this.axios.get("/addcart3",{params:obj}).then(res=>{
                    if(res.data.code==-1){
                            alert("请先登录")
                             //提示交互提示/跳转登录组件
                            this.$router.push("/login");
                             return;
                        }else{
                            alert("添加成功")
                        }
                })
            },
            add(){
                this.count++;
            },
             jian(){
                if(this.count>1){
                    this.count--;
                } 
             },
            maskMove1(e){
                var left=e.offsetX-122;
                var top=e.offsetY-122;
                if(left<0){
                    left=0
                }else if(left>=390){
                    left=390
                }else{
                    left=e.offsetX-122;
                }
                if(top<0){
                    top=0
                }else if(top>=182){
                    top=182
                }else{
                    top=e.offsetY-122;
                }
                top+="px";
                left+="px";
                this.pmaskStyle={left,top}
            },
            // 移入移出
            toggle1(){
                this.maskShow1=!this.maskShow1
            },
            // 点击切换图片
            changei(i){
                this.i=i
            },
            load(){ //请求数据库数据
                this.axios.get("/detail/preip",{params:{pid:this.pid}}).then(res=>{
                    this.preipList=res.data.product
                    console.log(this.preipList)
                    this.pics=res.data.pics
                    for(var i=0;i<this.pics.length;i++){
                        this.preipPicSm.push(require("../assets/"+this.pics[i].sm));
                        this.preipPicLg.push(require("../assets/"+this.pics[i].lg));
                    }
                    if(this.pid==1){
                        this.dNone.display="inline-block"
                    }else{
                        this.dNone.display="none"
                    }
                })
            },
            dpMsg(n){
                for(var i=0;i<this.pactives.length;i++){
                    if(n==i){
                        this.pactives[i].active=true;
                        this.pcontents[i].display="block";
                    }else{
                        this.pactives[i].active=false;
                        this.pcontents[i].display="none";
                    }
                }  
            },
        },
        components:{
            "shopBtn":ShopBtn
        }
    }
</script>

<style>
    @import url("../assets/css/details-preip.css");
</style>
