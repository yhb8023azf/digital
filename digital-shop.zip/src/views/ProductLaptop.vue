<template>
   <div>
    <sm-header :active2="gender2"></sm-header>
    <div class="product font">
    <!--*************************导航***************************-->		
    		<div class="product-nav">
    			<div class="nav">
    				<router-link to="/">首页</router-link>
    				<span>&gt;</span>
    				<span>笔记本</span>
    			</div>
    		</div>
    <!--******************中屏以下时出现的导航*******************-->
    		<div class="pro-nav" id="sx">
    			<div class="nav-second">
    				<a>
    					<span @click="screen()">筛选</span>
    				</a>
    				<select name="">
    					<option value="">请选择排序类型</option>
    					<option value="">按照日期排序，新品在前</option>
    					<option value="">按照价格排序，从高到低</option>
    					<option value="">按照价格排序，从低到高</option>
    				</select>
    			</div>
    		</div>
    <!--*************************内容部分************************-->
    		<div class="product-content">
    			<div class="content">
    				<!-- ---------------------内容左侧部分------------------ -->
    				<!-- 当点击“筛选”按钮，整个屏幕变灰 -->
    				<div class="dis1" id="btn2" :style="btn"></div>
    				<div class="riCon" id="btn1" :class="rightCon">
    					<div class="md-con">
    						<!-- 中屏显示的关闭按钮 -->
    						<div class="close1">
    							<span @click="close()" :style="x">×</span>
    						</div>
    						<div class="con-select">
    							<div class="sel-1">
    								<h4>品牌</h4>
    								<select name="">
    									<option value="">--请选择--</option>
    									<option value="">ThinkPad</option>
    									<option value="">华硕</option>
    									<option value="">外星人</option>
    									<option value="">弘基</option>
    									<option value="">惠普</option>
    									<option value="">戴尔</option>
    									<option value="">拯救者</option>
    									<option value="">炫龙</option>
    									<option value="">神州</option>
    									<option value="">联想</option>
    									<option value="">雷神</option>
    								</select>
    							</div>
    							<div class="sel-2">
    								<h4>处理器</h4>
    								<select name="">
    									<option value="">--请选择--</option>
    									<option value="">AMD</option>
    									<option value="">Intel i3</option>
    									<option value="">Intel i5</option>
    									<option value="">Intel i7</option>
    									<option value="">Intel i9</option>
    									<option value="">Intel奔腾 赛场</option>
    									<option value="">Rezen锐龙</option>
    								</select>
    							</div>
    							<div class="sel-3">
    								<h4>显卡</h4>
    								<select name="">
    									<option value="">--请选择--</option>
    									<option value="">GTX9系/7系</option>
    									<option value="">GTX1060 3G/6G</option>
    									<option value="">GTX1070 8G</option>
    									<option value="">GTX750</option>
    								</select>
    							</div>
    							<div class="sel-4">
    								<h4>屏幕尺寸</h4>
    								<select name="">
    									<option value="">--请选择--</option>
    									<option value="">11.6英寸</option>
    									<option value="">12.5英寸</option>
    									<option value="">13.3英寸</option>
    									<option value="">14.0英寸</option>
    									<option value="">15.6英寸</option>
    									<option value="">17.3英寸</option>
    								</select>
    							</div>
    							<div class="sel-5">
    								<h4>内存</h4>
    								<select name="">
    									<option value="">--请选择--</option>
    									<option value="">16G</option>
    									<option value="">32G</option>
    									<option value="">4G</option>
    									<option value="">8G</option>
    								</select>
    							</div>
    							<div class="sel-6">
    								<h4>硬盘</h4>
    								<select name="">
    									<option value="">--请选择--</option>
    									<option value="">1TB HDD</option>
    									<option value="">240GB SSD</option>
    									<option value="">256GB SSD</option>
    									<option value="">500GB HDD</option>
    									<option value="">512GB SSD</option>
    								</select>
    							</div>
    							<div class="sel-7" id="sel7">
    								<h4>价格</h4>
                                    <!-- 引入滑块所搜价格子组件 -->
                                    <shopMove></shopMove>
    							</div>
    						</div>
    					</div>
    				</div>
    				<!-- ---------------内容右侧部分------------------- -->
    				<div class="ple-con">
    					<ul>
                            <span class="con1">
                                <li>
                                	<div class="">
                                		<router-link :to="`/laptop${laplist[0].href.substr(6)}`" title="14英寸四核独显轻薄商务便携笔记本电脑"><img :src="lapImg[0]"/></router-link>
                                	</div>
                                	<div class="con">
                                		<router-link :to="`/laptop${laplist[0].href.substr(6)}`" v-text="lapTitle[0]"></router-link>
                                		<p><span v-cloak>¥{{laplist[0].price}}</span></p>
                                	</div>
                                </li>
                                <li>
                                	<div class="">
                                		<router-link :to="`/laptop${laplist[1].href.substr(6)}`" title="15.6英寸游戏笔记本 黑色 80WW000TCD"><img :src="lapImg[1]"/></router-link>
                                	</div>
                                	<div class="con">
                                		<router-link :to="`/laptop${laplist[1].href.substr(6)}`" v-text="lapTitle[1]"></router-link>
                                		<p><span v-cloak>¥{{laplist[1].price}}</span></p>
                                	</div>
                                </li>
                            </span>
                            <span class="con2">
                                <li>
                                	<div class="">
                                		<router-link :to="`/laptop${laplist[2].href.substr(6)}`" title="E580 笔记本电脑 20KSA001CD"><img :src="lapImg[2]"/></router-link>
                                	</div>
                                	<div class="con">
                                		<router-link :to="`/laptop${laplist[2].href.substr(6)}`" v-text="lapTitle[2]"></router-link>
                                		<p><span v-cloak>¥{{laplist[2].price}}</span></p>
                                	</div>
                                </li>
                                <li>
    						    	<div class="">
    						    		<router-link :to="`/laptop${laplist[3].href.substr(6)}`" title="15.6英寸游戏笔记本 黑色 81HC0007CD"><img :src="lapImg[3]"/></router-link>
    						    	</div>
    						    	<div class="con">
    						    		<router-link :to="`/laptop${laplist[3].href.substr(6)}`" v-text="lapTitle[3]"></router-link>
    						    		<p><span v-cloak>¥{{laplist[3].price}}</span></p>
    						    	</div>
    						    </li>
                            </span>
                            <span class="con3">
    						    <li>
    						    	<div class="">
    						    		<router-link :to="`/laptop${laplist[4].href.substr(6)}`" title="13.3英寸触控笔记本 天蝎灰 81CT0001CD"><img :src="lapImg[4]"/></router-link>
    						    	</div>
    						    	<div class="con">
    						    		<router-link :to="`/laptop${laplist[4].href.substr(6)}`" v-text="lapTitle[4]"></router-link>
    						    		<p><span v-cloak>¥{{laplist[4].price}}</span></p>
    						    	</div>
    						    </li>
    						    <li>
    						    	<div class="">
    						    		<router-link :to="`/laptop${laplist[5].href.substr(6)}`" title="X280 笔记本电脑 20KFA002CD"><img :src="lapImg[5]"/></router-link>
    						    	</div>
    						    	<div class="con">
    						    		<router-link :to="`/laptop${laplist[5].href.substr(6)}`" v-text="lapTitle[5]"></router-link>
    						    		<p><span v-cloak>¥{{laplist[5].price}}</span></p>
    						    	</div>
    						    </li>
    						</span>
    						<span class="con4">
    						    <li>
    						    	<div class="">
    						    		<router-link :to="`/laptop${laplist[6].href.substr(6)}`" title="拯救者 Y7000 15.6英寸游戏笔记本 黑色 81FW0009CD"><img :src="lapImg[6]"/></router-link>
    						    	</div>
    						    	<div class="con">
    						    		<router-link :to="`/laptop${laplist[6].href.substr(6)}`" v-text="lapTitle[6]"></router-link>
    						    		<p><span v-cloak>¥{{laplist[6].price}}</span></p>
    						    	</div>
    						    </li>
    						    <li>
    						    	<div class="">
    						    		<router-link :to="`/laptop${laplist[7].href.substr(6)}`" title="ThinkPad T480 笔记本电脑"><img :src="lapImg[7]"/></router-link>
    						    	</div>
    						    	<div class="con">
    						    		<router-link :to="`/laptop${laplist[7].href.substr(6)}`" v-text="lapTitle[7]"></router-link>
    						    		<p><span v-cloak>¥{{laplist[7].price}}</span></p>
    						    	</div>
    						    </li>
                            </span>
                            <span class="con5">
    						    <li>
    						    	<div class="">
    						    		<router-link :to="`/laptop${laplist[8].href.substr(6)}`" title="黑武士A56游戏笔记本"><img :src="lapImg[8]"/></router-link>
    						    	</div>
    						    	<div class="con">
    						    		<router-link :to="`/laptop${laplist[8].href.substr(6)}`" v-text="lapTitle[8]"></router-link>
    						    		<p><span v-cloak>¥{{laplist[8].price}}</span></p>
    						    	</div>
    						    </li>
    						</span>
                        </ul>
    				</div>
    			</div>
    		</div>
    	</div>
        <!-- ********************************脚部*************************** -->
        <sm-footer></sm-footer>
  </div>
</template>

<script>
    // 引入子组件
    import ShopMove from '../components/ShopMove'
    export default{
        data(){
            return{
                x:{display:"none"},
                btn:{display:"none"},
                rightCon:{
                   riCon:true,
                   riCon1:false
                },
				laplist:[
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
				],
				lapImg:[],
				lapTitle:[],
				gender2:2,
            }
        },
		props:["family_ids"],
		created() {
			this.load()
		},
        methods:{
			load(){
				this.axios.get("/product/laptop",{params:{family_ids:this.family_ids}}).then(res=>{
					this.laplist=res.data
					for(var i=0;i<this.laplist.length;i++){
						this.lapImg.push(require("../assets/"+this.laplist[i].img))
						if(this.laplist[i].title.length>=10){
							
							this.lapTitle[i]=this.laplist[i].title.slice(0,13)+"..."
						}
					}
					
				});
				
			},
            screen(){
                this.x.display="block";
                this.btn.display="block";
                this.rightCon={
                   riCon:false,
                   riCon1:true 
                }
            },
            close(){
               this.x.display="none";
               this.btn.display="none";
               this.rightCon={
                  riCon:true,
                  riCon1:false 
               } 
            },
           
        },
        components:{
            "shopMove":ShopMove
        }
        
    }
</script>

<style>
    @import url("../assets/css/product.css");
</style>
