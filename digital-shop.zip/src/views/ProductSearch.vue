<template>
    <div>
        <sm-header></sm-header>
        <div id="productSearch" class="font">
            <div class="se-nav">
                <div class="search-nav">
                    <router-link to="/">首页</router-link>
                    <span>&gt;</span>
                    <span>搜索结果</span>
                </div>
            </div>
            <div class="searchContent">
                <div class="search-content">
                    <div class="p-search">
                        <div class="search-product" v-for="(plist,i) of plist" :key="i">
                        	<router-link :to="plist.href">
                        		<img :src="pics1[i]" class="se-img"/>
                        		<h4 class="se-title" v-text="plist.title"></h4>
                        	</router-link>
                        	<p class="se-price" v-cloak>¥{{plist.price}}</p>
                        </div>
                    </div>
                    
                </div>
            </div>
            <div class="no-search" :style="d_none2">
                <h4>哎呀!没找到您想要的哦</h4>
            </div>
        </div>
        <sm-footer></sm-footer>
    </div>
</template>

<script>
    export default{
        data(){
            return{
               plist:[],
               pics1:[],
               d_none2:{display:"none"}
            }
        },
        created() {
            this.load();
        },
        props:["kw"],
        methods:{
            load(){
                this.axios.get("/psearch",{params:{kw:this.kw}}).then(res=>{
                    this.plist=res.data.data;
                    for(var i=0;i<this.plist.length;i++){
                        this.pics1.push(require("../assets/"+this.plist[i].img))
                    }
                    if(this.plist.length==0){
                        this.d_none2.display="block"
                    }else{
                        this.d_none2.display="none"
                    }
                })
                
            },
        },
        watch:{
            "$route"(){
                this.load()
            }
        }
    }
</script>

<style scoped>
    *{margin:0px;padding:0px;}
    body{box-sizing:border-box;}
    .font{
        word-spacing: normal;
        font-family: "微软雅黑",Helvetica,Arial,Verdana,sans-serif;
        font-style: normal;
        font-weight: normal;
        font-size:14px;
    }
    #productSearch{background:#f2f2f2;padding-bottom:60px;width:100%;}
    /* 导航栏部分 */
    #productSearch>.se-nav{
        background:#fff;
        width:100%;
        margin-bottom:20px;
    }
    #productSearch>.se-nav .search-nav{
        padding-top:20px;
        padding-bottom:20px;
    }
    #productSearch>.se-nav .search-nav a,#productSearch>.se-nav .search-nav span{color:#757575;}
    /* 大屏导航栏样式 */
    @media only screen and (min-width:992px){
        #productSearch>.se-nav .search-nav,#productSearch>.searchContent .search-content{
        padding-left:7%;
        padding-right:7%;
        }
    }
    /* 中屏导航栏样式 */
    @media only screen and (max-width:991px){
        #productSearch>.se-nav .search-nav,#productSearch>.searchContent .search-content{
        padding-left:7%;
        padding-right:7%;
        }
    }
    /* 小屏导航栏样式 */
    @media only screen and (max-width:576px){
        #productSearch>.se-nav .search-nav,#productSearch>.searchContent .search-content{padding:10px;}
        
    }
    /* 内容部分 */
    .searchContent .search-content .p-search{
        display:flex;
        flex-direction: row;
        flex-wrap: wrap;
    }
    .searchContent .p-search .search-product{
        background:#fff;
        /* border: 1px solid #000000; */
        text-align:center;
        margin-right:15px;
        margin-bottom:15px;
    }
    .searchContent .search-product .se-img{
        width:100%;height:auto;
    }
    .searchContent .search-product .se-title{
        font-size:15px;
        color: #000000;
        font-weight:normal;
        line-height:21px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        padding:0px 8px;
    }
    .searchContent .search-product .se-price{
        color: #dd3333;
        font-size: 18px;
        margin:15px 0;
    }
    @media (min-width:992px) {
       .searchContent .p-search .search-product{
            width:23%;
       } 
    }
    @media (max-width:991px) {
        .searchContent .p-search .search-product{width:47%;} 
    }
    @media (max-width:576px) {
        .searchContent .p-search .search-product{width:45%;} 
    }
    #productSearch .no-search{
        width:100%;
    }
    #productSearch .no-search h4{
        padding:20px 40px;
        background:#fff;
        width:25%;
        margin:auto;
        text-align:center;
        font-size:26px;
        border:1px solid #fff;
        border-radius:5px;
        margin-top:70px;
        margin-bottom:50px;
    }
    
</style>
