<template>
    <div>
       <sm-header></sm-header>
        <div class="details-laptop font">
        <!--*******************评测中心导航栏**********************-->
        		<div class="laptop-first">
        			<div class="nav">
        				<router-link to="/">首页</router-link>
        				<span>&gt;</span>
        				<span><router-link to="/product/laptop">笔记本</router-link></span>
        				<span>&gt;</span>
        				<span v-text="lapList.title"></span>
        			</div>
        		</div>
        <!--************************************内容部分******************************-->
        		<div class="laptop-second">
        			<div class="laptop-container">
        				<div class="content">
        					<div class="con-img">
                                <!-- 描述上部分右侧 -->
        						<div class="con-right">
        					 		<div class="con-right-t">
                                        <img :src="picLg[n]" class="moveImg"/>
                                       <!-- 小方块 -->
                                        <div id="mask"  :class="{'d-none':!maskShow}" :style="maskStyle"></div>
                                        <!-- 遮罩层 -->
                                        <div id="super-mask"  @mouseover="toggle" @mouseout="toggle" @mousemove="maskMove"></div>
                                        <!-- 显示背景图 -->
                                        <div id="div-lg" :class="{'d-none':!maskShow}" :style="{'background-image':`url(${picLg[n]})`,'background-position':bgPosition}"></div>
        					 		</div>
        					 		<div class="con-right-b">
        					 			<img :src="picSm[0]" @click="changePic(0)"/>
        					 			<img :src="picSm[1]" @click="changePic(1)"/>
        					 			<img :src="picSm[2]" @click="changePic(2)"/>
        					 			<img :src="picSm[3]" @click="changePic(3)"/>
        					 			<img :src="picSm[4]" @click="changePic(4)"/>
        					 		</div>
        					 	</div>
                 <!--***************************** 描述上部分左侧**************************** -->
        					 	<div class="con-left">
        					 		<h1 v-text="lapList.title"></h1>
        					 		<div class="big-line">
        					 			<div></div>
        					 		</div>
        					 		<p class="con-details" v-text="lapList.subtitle"></p>
        					 		<p class="con-price"><span id="ptotal" v-cloak>¥{{lapList.price}}</span></p>
                                    <div class="md_select" @click="mdSelect()">
                                        <span>选择商品型号属性</span>
                                        <span><span></span></span>
                                    </div>
                                    <div class="con_msg" :style="conMsg">
                                        <div class="dl_msg">
                                            <div class="msg_title">
                                                <span class="s1"><img :src="picSm[0]" class="msg_img">
                                                </span>
                                                <h3 v-text="lapList.title"></h3>
                                                <span class="s1 s2" @click="xMsg()">X</span>
                                            </div>
                                            <form action="" class="con-cart" id="shop">
                                                <h3>搭配套餐:</h3>
                                                <p><input type="checkbox" name="" id="m3" value=""/><label for="m3" data-price="99">M301炫彩鼠标原价159元 (¥99)</label></p>
                                                <p><input type="checkbox" name="" id="k7" value=""/><label for="k7" data-price="240">K70红轴机械键盘原价299 (¥240)</label></p>
                                                <p><input type="checkbox" name="" id="k8" value=""/><label for="k8" data-price="399">K80樱桃茶轴键盘原价499 (¥399)</label></p>
                                                <p><input type="checkbox" name="" id="dj" value=""/><label for="dj" data-price="1499">27英寸电竞显示器原价1699元 (¥1499)</label></p>
                                                <p> <input type="checkbox" name="" id="sm" value=""/><label for="sm" data-price="349">沙漠风暴H71耳机黑色原价499 (¥349)</label></p> 
                                                <div class="con-total" style="height:0px;">
                                                    <p><span>选项累计:</span><span>¥0</span></p>
                                                    <p><span>全部总计:</span><span>¥5999</span></p>   
                                                </div>
                                                <div class="con-shop">
                                                    <button type="button" @click="addCart"
                                                    :data-lid="lapList.lid"
                                                    :data-title="lapList.title"
                                                    :data-price="lapList.price"
                                                    :data-img="lapList.img"
                                                    >加入购物车</button>
                                                    <button type="button">-</button>
                                                    <span>1</span>
                                                    <button type="button">+</button>
                                                </div>
                                            </form>   
                                        </div>
                                    </div>
                                    <div class="con-lid">
                                        <p><span>商品编号：</span> <span>82FW0209CD</span> </p>
                                        <p><span>分类：</span> <span v-text="lapList.category">笔记本</span> </p>
                                        <p><span>标签：</span> <span v-text="lapList.label">游戏笔记本</span> </p>
                                    </div>                           
        					 	</div>
        					</div> 
        				</div>
        			</div>
        		</div>
                <!--************************* 商品描述部分 ********************************-->
                <div class="laptop-three">
                    <div class="laptop-msg">
                        <div class="msgs" id="message">
                            <div class="msgs-nav">
                                <ul>
                                    <li><a href="javascript:;" class="active" data-target="content1">描述</a></li>
                                    <li><a href="javascript:;" data-target="content2">其它信息</a></li>
                                    <li><a href="javascript:;" data-target="content3">用户评价(0)</a></li>
                                </ul>
                            </div>
                            <div class="msgs-desc">
                                <div class="desc-cont" id="content1">
                                    <h1>处理器</h1>
                                    <span class="msg-span">CPU：第八代智能英特尔® 酷睿™ i5 处理器</span>
                                    <span class="msg-span">CPU型号：i5-8300H</span>
                                    <span class="msg-span">CPU主频：2.3 GHz</span>
                                    <span class="msg-span">核心数：四核</span>
                                    <h1>屏幕</h1>
                                    <span class="msg-span">屏幕尺寸：<span v-text="lapList.resolution"></span></span>
                                    <span class="msg-span">物理分辨率：1920x1080</span>
                                    <span class="msg-span">屏幕类型：全高清IPS屏幕</span>
                                    <span class="msg-span">显示比例：16:9</span> 
                                    <h1>内存</h1>
                                    <span class="msg-span">内存容量：<span v-text="lapList.memory"></span></span>
                                    <span class="msg-span">内存类型：DDR4</span>
                                    <h1>硬盘</h1>
                                    <span class="msg-span">硬盘容量：<span v-text="lapList.disk"></span></span>
                                    <span class="msg-span">硬盘类型：机械硬盘+固态硬盘</span>
                                    <div class="desc-img">
                                        <img src="../assets/img/product_details/big-laptop.png" >
                                    </div>
                                </div>
                                <div class="msgs-tab" id="content2">
                                    <table class="desc-tab">
                                        <tr>
                                            <th>屏幕尺寸</th>
                                            <td><p v-text="lapList.resolution"></p></td>
                                        </tr>
                                        <tr>
                                            <th>处理器</th>
                                            <td><p v-text="lapList.cpu"></p></td>
                                        </tr>
                                        <tr>
                                            <th>显卡</th>
                                            <td><p v-text="lapList.video_card"></p></td>
                                        </tr>
                                        <tr>
                                            <th>内存</th>
                                            <td><p v-text="lapList.memory"></p></td>
                                        </tr>
                                        <tr>
                                            <th>硬盘</th>
                                            <td><p v-text="lapList.disk"></p></td>
                                        </tr>
                                        <tr>
                                            <th>品牌</th>
                                            <td><p v-text="lapList.brand"></p></td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="desc-com" id="content3">
                                    <div></div>
                                    <p>目前还未有评论</p>
                                    <p>只有买过此商品的客户登录后才能发表评论</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ********************相关商品****************************************** -->
                <div class="laptop-four">
                    <div class="laptop-pro">
                        <div class="relevant-pro">
                            <div class="pro-nav2">
                                <h2>相关商品</h2>
                            </div>
                            <ul>
                            	<div class="pro-li1">   
                                    <li>    
                                        <div class="pro-1">
                                            <a href="" title="14英寸四核独显轻薄商务便携笔记本电脑">
                                            <img src="../assets/img/product/pro-lap6.jpg" class="lap-img"/></a>
                                        </div>
                                        <div class="pro-2">
                                            <a href="#">14英寸四核独显轻薄商务便携笔记本电脑</a>
                                            <p><span>¥5999</span></p>
                                        </div>
                                   
                                    </li>
                                    <li>
                                        <div class="pro-1">
                                            <a href="" title="15.6英寸游戏笔记本 黑色 80WW000TCD">
                                            <img src="../assets/img/product/pro-lap1.jpg" class="lap-img"/></a>
                                        </div>
                                        <div class="pro-2">
                                            <a href="#">15.6英寸游戏笔记本 黑色 80WW000TCD</a>
                                            <p><span>¥5999</span></p>
                                        </div>
                                    </li> 
                                </div>
                                <div class="pro-li2">
                                    <li>
                                        <div class="pro-1">
                                            <a href="" title="E580 笔记本电脑 20KSA001CD">
                                            <img src="../assets/img/product/pro-lap5.jpg" class="lap-img"/></a>
                                        </div>
                                        <div class="pro-2">
                                            <a href="#">E580 笔记本电脑 20KSA001CD</a>
                                            <p><span>¥10899</span></p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="pro-1">
                                            <a href="" title="15.6英寸游戏笔记本 黑色 81HC0007CD">
                                            <img src="../assets/img/product/pro-lap2.jpg" class="lap-img"/></a>
                                        </div>
                                        <div class="pro-2">
                                            <a href="#">15.6英寸游戏笔记本 黑色 81HC0007CD</a>
                                            <p><span>¥5899</span></p>
                                        </div>
                                    </li>
                                </div>	
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- 中屏的时候出现 ，顶层加入购物车按钮-->
                <div class="bto_btn">
                    <button>加入购物车</button>
                </div>
                <!-- 中屏时，点击“选择商品”，出现遮罩层 -->
                <div class="shade" :style="conShade" @click="closeShade()"></div>
            </div>
       <sm-footer></sm-footer>
        
    </div>
</template>

<script>
    export default{
        data(){
            return{
               conShade:{opacity:0,display:"none"},
               conMsg:{bottom:"-423px"},
               n:0,   //记录当前正在显示第几章图片
               lapList:{price:0},//防止首次加载时product.price.toFixed(2)报错
               pics:[{md:"",sm:"",lg:""},//防止首次加载时pics[0].md报错
                    {md:"",sm:"",lg:""},
                    {md:"",sm:"",lg:""},
                    {md:"",sm:"",lg:""},
                    {md:"",sm:"",lg:""},
               ],
               picLg:[],//接收require请求到的图片信息
               picSm:[],
               maskShow:false,
               maskStyle:{
                 left:0,
                 top:0
               },
               count:0
            }
        },
        props:["lid"],
        created(){
            //在页面加载时，发送一次请求，初始化data中的数据
            this.load();
        },
        computed:{
            bgPosition(){
              var left=parseInt(this.maskStyle.left);
              var top=parseInt(this.maskStyle.top);
              return `-${left*16/8}px -${top*16/8}px`
            },
        },
        methods:{
            // 添加到购物车
            addCart(e){
                var lid=e.target.dataset.lid;
                var p=e.target.dataset.price;
                var n=e.target.dataset.title;
                var i=e.target.dataset.img;
                var obj={lid:lid,price:p,title:n,img:i}
                this.axios.get("/addcart1",{params:obj}).then(res=>{
                    if(res.data.code==-1){
                            alert("请先登录")
                             //提示交互提示/跳转登录组件
                            this.$router.push("/login");
                             return;
                        }else{
                            alert("添加成功")
                        }
                })
            },
            // 放大镜效果-最小框移动
            maskMove(e){
              var left=e.offsetX-110;
              var top=e.offsetY-110;
              if(left<0){
                  left=0
              }else if(left>=402){
                  left=402
              }else{
                  left=e.offsetX-110;
              }
              if(top<0){
                  top=0
              }else if(top>=194){
                  top=194
              }else{
                  top=e.offsetY-110;
              }
              top+="px";
              left+="px";
              this.maskStyle={left,top}
            },
            // 移入移出隐藏效果
            toggle(){
              this.maskShow=!this.maskShow;
            },
            load(){//封装发送ajax请求和初始化数据的方法，用于反复调用
              this.axios.get("/detail/laptop",{params:{lid:this.lid}}).then(res=>{
                 this.lapList=res.data.product;
                 this.pics=res.data.pics;
                 for(var i=0;i<this.pics.length;i++){
                     this.picSm.push(require("../assets/"+this.pics[i].sm));
                     this.picLg.push(require("../assets/"+this.pics[i].lg));
                 }
                 console.log(this.count)
              })  
            },
            // 点击切换图片
            changePic(n){
                this.n=n;
            },
            // 中屏时，点击“选择商品”，出现详情框
            mdSelect(){
                this.conShade.opacity=0.8;
                this.conShade.display="block";
                this.conMsg.bottom="0";
            },
            // 关闭详情框
            xMsg(){
                this.conShade.opacity=0;
                this.conShade.display="none";
                this.conMsg.bottom="-423px";
            },
            closeShade(){
                this.conShade.opacity=0;
                this.conShade.display="none";
                this.conMsg.bottom="-423px";
            },
        },
        watch:{
            lid(){//lid变量的变化
              //只要lid发生变化
              //就重新请求服务端数据
              //更换data中的变量
              this.load();
            }
        },
        mounted() {
            (function(){
                // 笔记本商品详情页、台式机商品详情页***********************************
                // 搭配套餐界面
                // 当点击任意套餐时，总价显示出来，没有选中时，隐藏********************
                var shop=document.getElementById("shop");
                var combo=document.querySelectorAll("#shop p>input");
                var dis1=document.querySelector("#shop .con-total");
                // 找到总价所在位置
                var total=document.querySelectorAll("#shop .con-total")[0].children[1].children[1];
                for(var p of combo){
                    p.onclick=function(){
                        var input=this;
                        // 判断是否有选中状态的，如果没有，总价就隐藏
                        var unchb=document.querySelector("#shop>p>input:checked");
                        if(unchb==null){
                            dis1.style.height="0px";
                        }else{
                            dis1.style.height="60px";
                        }
                       // 获取所点套餐的价格
                       var tprice=parseInt(input.nextElementSibling.getAttribute("data-price"));
                       // 找到套餐价格内容
                       var t=document.querySelectorAll("#shop>.con-total>p>span")[1]; 
                       var t1=parseInt(t.innerHTML.slice(1));
                       // 查找当前商品价格
                       var pprice=document.getElementById("ptotal")
                       var pprice1=parseInt(pprice.innerHTML.slice(1));
                       if(input.checked==true){
                           t1+=tprice;
                       }else{
                           t1-=tprice; 
                       }
                       t.innerHTML=`¥${t1}`;
                       pprice1+=t1;
                       total.innerHTML=`¥${pprice1}`;
                    }
                }
                
                
                // 当点击+，总价增加，当点击-，总价减少**************************************
                var button=document.querySelectorAll("#shop>.con-shop>button")
                var price=parseFloat(
                	total.innerHTML.slice(1)
                );
                for(var btn of button){
                    btn.onclick=function(){
                       var btn=this;
                        //   先找爹td 再找爹下第3个孩子span
                       var span=btn.parentNode.children[2];
                       var n=parseInt(span.innerHTML);
                       if(btn.innerHTML=="+"){//如果点的是+
                       	n++;//就+1
                       }else if(n>1){//否则 如果点的是-，且内容>1
                       	n--;//才能-1
                       }
                       //将修改后的内容再放回span的内容中
                       span.innerHTML=n;
                       // 总价变化
                       var price1=price*n;
                       total.innerHTML=`¥${price1}`;
                    }
                }
                //商品详情部分。当点击三个按钮，下面的信息也随之变化****************************
                // 获取触发事件
                var des=document.querySelectorAll("#message>.msgs-nav>ul li a")
                var divs=document.querySelectorAll("#message>.msgs-desc>div")
                //console.log(div)
                var i=10;
                for(var item of des){
                    item.onclick=function(){
                        var a=document.querySelectorAll("#message>.msgs-nav>ul li a.active")
                        if(a.length!=0){
                            a[0].className="";
                        }
                        var item=this;
                        item.className="active"
                        //当点击按钮后，对应的信息也发生变化
                        //获得保存在a上的自定义扩展属性data-target中的id名
                        var id=this.getAttribute("data-target");
                        for(var i=0;i<divs.length;i++){
                            var did=divs[i].getAttribute("id")
                            //console.log(did)
                            if(id==did){
                                divs[i].style.display="block";
                            }else{
                                divs[i].style.display="none";
                            }
                        }
                    }
                }
                
            })()
        }
    }
</script>

<style>
    @import url("../assets/css/details-laptop.css");
</style>
