<template>
  <div>
    <h1 style="color:red">404:Not Found</h1>
  </div>
</template>
<script>
export default {
  
}
</script>
