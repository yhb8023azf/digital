<template>
    <div>
        <div class="login">
            <div class="login-con">
            	<div class="container">
            		<div class="text-center">
            			<img src="../assets/img/headfoot/login1.png" class="img1">
            		</div>
            		<div class="text-center log-title">
            			<h3>一个账号，玩转所有官方服务！</h3>
            		</div>
            		<div class="text-center">
            			<form action="" method="post" class="form-group">
            				<div class="form-inline">
            					<input type="text" value="" class="form-control" placeholder="手机号码" v-model="uphone">
								<p class="logMsg" :style="totalMsg1">手机号码格式不正确</p>
            				</div>
            				<div class="form-inline1">
            					<input type="password" value="" placeholder="密码" class="form-control" v-model="upwd">
								<p class="logMsg" :style="totalMsg2">密码格式不正确</p>
            				</div>
            				<div class="bor">
            					<input type="checkbox"  id="agree" ><label for="agree">我同意《用户手册》和《保密条款》</label>
            				</div>
            				<div class="text-center">
            					<button class="bg-success" @click="doLog">登录</button>
            				</div>
            				<div class="text-center">
            					<button class="bg-light" @click="doReg">注册</button>
            				</div>
            				<div class="pl-0">
            					<span>第三方账号登陆：</span>
            					<a href="">
            						<img src="../assets/img/headfoot/qq.png" class="img-qq">
            					</a>
            				</div>
            				<div class="pr-0">
            					<a href="">忘记密码？点这里找回</a>
            				</div>
            			</form>
            		</div>
            		<div class="log-font">
            			<p>用户登录注册说明：</p>
            			<p>1. 演示模板不支持注册，实际使用短信验证码需单独购买<span style="color:rgb(44,130,201)">短信资源包</span>。</p>
            			<p>2. 演示用户名：17718412654，密码：123456。</p>	
            		</div>
            	</div>
            </div>
        </div>
        
    </div>
</template>

<script>
	export default{
		data(){
			return{
				uphone:'',
				upwd:'',
				totalMsg1:{display:"none"},
				totalMsg2:{display:"none"},
			}
		},
		methods:{
			// 跳转到注册界面
			doReg(){
				this.$router.push("/register");
			},
			// 登录
			doLog(e){
                 e.preventDefault();
				//创建正则表达式，对手机号和密码进行验证
				var reg1=/^[1][3,4,5,7,8][0-9]{9}$/;
				var reg2=/^\w{6,16}$/i;
				if(!reg1.test(this.uphone)){
					this.totalMsg1.display="block";
					return;
				}else{
					this.totalMsg1.display="none";
				}
				if(!reg2.test(this.upwd)){
					this.totalMsg2.display="block";
					return;
				}else{
					this.totalMsg2.display="none";
				}
                var obj={phone:this.uphone,upwd:this.upwd};
				this.axios.get("/log",{params:obj}).then(res=>{
                    console.log(res.data.code);
					if(res.data.code==-1){
						alert("用户名或密码不正确")
					}else{
						this.$router.push("/")
					}
				})
				
			},
		},
	}
</script>

<style scoped>
        a{text-decoration:none;}
        button{cursor:pointer;outline:none;}
        input{outline:none;}
        .login{width:100%;height:100%;background-color:#f5f5f5 !important;}
        .login .container{text-align:center;}
        .text-center .img1{
            margin-top:40px;
        	vertical-align: middle;
            max-width: 100%;
            width: auto;
            height: auto;
        }
        .log-title{margin:25px 0px;}
        /* 输入框 */
        .form-group{display:block; width:100%;}
        .form-group .form-control{
            padding:13px 0px 13px 8px;
            border:1px solid #ddd !important;
            box-shadow: inset 0 -1px 4px #eee!important;
            }
        .form-group>.form-inline{margin-bottom:10px;}
		
		.login .logMsg{
			text-align:left;
			color:#f00;
			padding-top:10px;
		}
        @media only screen and (min-width:992px){
            .login .container{margin-top:70px;}
            .login>.login-con{
                padding-left:9%;
                padding-right:9%;
            }
            .login>.login-con .text-center h3{
                font-size: 26px;
                font-weight: normal;
                font-style: normal;
                color: #000000;
            } 
        }
        @media only screen and (max-width:991px){
            .login .container{margin-top:25px;}
            .login>.login-con{
                padding-left:7%;
                padding-right:7%;
            }
            .login>.login-con .text-center h3{
                font-size: 16px;
            }
        }
        @media only screen and (max-width:576px){
            .login>.login-con{
                padding-left:15px;
                padding-right:15px;
            }
        }
        
        /* 手机号码和密码框 */
        @media only screen and (min-width:576px) {
        	.form-group .form-control,.bor,.bg-success,.bg-light{
        		width:345px;
        	}
        	.bor{margin:auto;}
        	.bor input{margin-left:-65px;}
        	.pl-0{margin-left:-205px;
        		font-size:15px;
        		margin-top:15px;
        		color:#777;
        	}
			.login .logMsg{
				width:345px;
				margin:auto;
			}
            .pr-0{
               margin-left:185px;
            }
        }
        @media only screen and (max-width:575px) {
        	.form-group .form-control,.bg-success,.bg-light{width:100%!important;}
        	.bor,.pl-0{text-align:left;}
            .pl-0{margin-top:5px;}
            .pr-0{text-align:right;}
        }
        /* 同意选项 */
        .bor{
            border-bottom:1px solid #ddd;
        	border-top:1px solid #ddd;
        	margin-top:10px !important;
        	padding-top:12px;
        	padding-bottom:12px;
        }
        .bor label{
            margin-left:8px;
        	color:#aaa;
        }
        /* 按钮 */
        .form-group .form-control,.bg-success,.bg-light{
            border-width:0px;
            border-radius:5px;
            font-size:16px;
        }
        .bg-success{
            background-color:#00eef3;
            margin-bottom:10px;
            color: #000000;
        }
        .bg-success,.bg-light{height:40px;line-height:40px;}
        /* 第三方登录 */
        .pl-0 .img-qq{
            width:20px;height:20px;
            margin-top:5px;
            
        }
        .pr-0{
            margin-top:15px;
            font-size:15px;
            margin-bottom:10px;
        }
        .pr-0 a{color:#000000;}
        
        .log-font{
            font-size:14px;
        	color:#666;
            text-align:left;
        }
        .log-font p{
        line-height:20px;}
    
</style>
