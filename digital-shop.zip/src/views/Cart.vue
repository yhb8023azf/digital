<template>
	<div>
		<sm-header 
        :img="cartImg"
        :list="list"
        ></sm-header>
		<div class="cart font">
            <div :style="cartNone1">
                <div class="cart-content" >
				<!-- 内容左侧部分 -->
				<div class="cart-left">
					<table>
						<thead class="b1">
							<tr>
								<th class="tpro font1">商品</th>
								<th class="tpri font1">价格</th>
								<th class="tnum font1">数量</th>
								<th class="tto font1">合计</th>
							</tr>
						</thead>
						<tbody>
							<tr class="tr1" v-for="(item,i) of list" :key="i">	
								<td class="t-first">
									<a href="" title="移除本项" @click="removeCart" :data-cid="item.cid"></a>
									<img :src="cartImg[i]" alt="" class="cartImg">
									<span v-text="item.title"></span>
								</td>
								<td class="t-second" v-cloak>¥{{item.price}}</td>
								<td class="t-three">
									<div>
										<button type="button" class="btn" @click="jian(i)">-</button>
                                        <span class="s1" v-cloak>{{item.count}}</span>
                                        <button type="button" class="btn" @click="addCount(i)">+</button>
									</div>
								</td>
								<td class="t-four" v-cloak>¥{{allPrice[i]}}</td>
							</tr>
						</tbody>
					</table>
				</div>
				<!-- 内容右侧部分 -->
				<div class="cart-right">
					<div class="cart-top">
						<h2>购物车总价</h2>
						<div class="c-price">
							<span>购物车小计</span>
							<span v-cloak>¥{{allTotal}}</span>
						</div>
						<div class="c-price bor2">
							<span>订单总价</span>
							<span v-cloak>¥{{allTotal}}</span>
						</div>
					</div>
					<div class="cart-bot">
						<button class="bu1">前往收银台</button>
						<div>
							<h2>优惠劵2:</h2>
							<input type="text" placeholder="优惠券代码" class="cart-in">
							<button class="bu2">使用优惠券</button>
						</div>
					</div>
				</div>
			</div>
            </div>
            <div class="empty" :style="cartNone2">
                <p>您的购物车目前是空的哦</p>
                <router-link to="/" class="router">
                    <img src="../assets/img/headfoot/back1.png" alt="" class="img1">
                    <span>返回商店</span>
                </router-link>
            </div>
		</div>
		<sm-footer></sm-footer>
	</div>
</template>

<script>
	export default{
		data(){
			return{
				list:[],
                allPrice:[],
                cartImg:[],
                allTotal:0,
                cartNone1:{display:"none"},
                cartNone2:{display:"block"},
                
			}
		},
        created() {
            this.load();
        },
        methods:{
            // 移除商品
            removeCart(e){
                var cid=e.target.dataset.cid
                alert("你是否删除此商品")
                this.axios.get("/del",{params:{cid:cid}}).then(res=>{
                    if(res.data.code>0){
                        alert("删除成功")
                        // 删除后重新加载页面
                        // this.load()
                    }
                })
            },
            // 增加商品数量，计算总价
            addCount(i){
                this.list[i].count++;
                var money=0
                money+=this.list[i].count*this.list[i].price;
                this.allPrice[i]=money
                this.allTotal+=parseInt(this.list[i].price) 
                
            },
            // 减少商品，计算总价
            jian(i){
                if(this.list[i].count>1){
                    this.list[i].count--;
                    var money=0
                    money+=this.list[i].count*this.list[i].price;
                    this.allPrice[i]=money
                    this.allTotal-=parseInt(this.list[i].price) 
                }
            },
            load(){
                //功能:加载购物车数据，当组件创建成功后调用
                //发送请求，获取返回值
                this.axios.get("/list").then(res=>{
                    var list=res.data.data
                     //创建循环，遍历数组，并且为每个元素添加cd:checked属性，表示商品是否被选中状态
                     //加载之前先清空一下
                     this.$store.commit("clear");
                     for(var item of list){
                         //添加cd属性表示状态
                         //修改共享购物车中数量值
                         this.$store.commit("increment");
                     }
                     //保存购物车数据
                     this.list=list;
                     console.log(list)
                     for(var i=0;i<this.list.length;i++){
                          this.cartImg.push(require("../assets/"+this.list[i].img))
                          this.allPrice[i]=this.list[i].count*this.list[i].price
                     }
                     // 总计
                   for(var j of this.allPrice){
                       this.allTotal+=parseInt(j);
                   }
                   if(list.length!==0){
                       this.cartNone2.display="none";
                       this.cartNone1.display="block";
                   }else{
                       this.cartNone1.display="none";
                       this.cartNone2.display="block";
                   }
                     
                })
            },
        },
	}
</script>

<style scoped>
	*{margin:0px;padding:0px;}
	body{box-sizing:border-box;}
	.font{
	    word-spacing: normal;
	    font-family: "微软雅黑",Helvetica,Arial,Verdana,sans-serif;
	    font-style: normal;
	    font-weight: normal;
	    font-size:14px;
	}
	.cart{background:#fff;padding-bottom:60px;width:100%;}
	/* 内容部分 */
    /* 购物车没有商品 */
    .cart .empty{
        text-align:center;
        padding-top:90px;
        padding-bottom:90px;
    }
    .cart .empty p{
        font-size:16px;
        margin-bottom:40px;
    }
    .cart .empty .router{
        font-size:16px;
        color: #000000;
        background-color: #ffffff;
        padding-top: 12px;
        padding-bottom: 12px;
        background-image: none;
        border:1px solid #00EFF2;
        display:flex;
        align-items:center;
        width:120px;
        margin:auto;
        padding-left:10px;
    }
    .cart .empty .router .img1{margin-right:10px;}
	/* 左侧 */
	.cart .cart-content{padding-top: 35px;}
	.cart .cart-left  table .tpro{
		width:50%;
		text-align:left;
	}
	.cart .tpri,.cart .tto{
		width:15%;
		text-align:left;
	}
	.cart .tnum{
		width:20%;
		text-align:left;
	}
	.cart .cart-left  table .font1{
		font-size: 16px;
		font-weight: bold;
		color: #555555;
		font-family: 微软雅黑;
		padding-top: 4px;
		padding-bottom:8px;
		border-bottom: 3px solid #ddd;
	}
	.cart table .t-first{
		display:flex;
		align-items: center;
		width:100%;
	}
	.cart table .t-first a{
		display:block;
		width:25px;height:23px ;
		background-image: url('../assets/img/headfoot/cartClose.png');
		background-size:20px,20px;
		background-position: center;
		margin-right:10%;
	}
	.cart table .t-first img{
		margin-right:10%;
	}
	.cart table .t-first span{
		display:block;
		margin-right:15px;
	}
	.cart table .t-three .btn{
		width:26px;height:40px;
		line-height:40px;
		background: #fff;
		border:1px solid #ddd;
		cursor: pointer;
	}
	.cart table .t-three .s1{
		display:inline-block;
		width:26px;height:38px;
		line-height:40px;
		background: #fff;
		border:1px solid #ddd;
		text-align:center;
	}
	.cart table .t-second,.cart table .t-four{
		color:#777;
		font-size:14px;
	}
	.cart .cartImg{width:90px !important;height:80px;}
	.cart table tbody td{width:20%;}
	.cart .cart-left  table tbody .tr1 td{padding:8px;
		border-bottom:1px dotted #ddd;
	}
	/* 右侧 */
	.cart .cart-top{margin-bottom:20px;}
	.cart .cart-top h2,.cart .cart-bot h2{
		font-size: 16px;
		font-weight: bold;
		color: #555555;
	    padding-top: 6px;
		padding-bottom: 6px;
		border-bottom: 3px solid #ddd;
	}
	.cart .cart-top .c-price{
		display:flex;
		align-items: center;
		border-bottom:1px solid #ddd;
	}
	.cart .cart-top .bor2{
		border-bottom:3px solid #ddd;
	}
	.cart .cart-top .c-price span{
		display:block;
		width:50%;
		color:#777;
		font-size:14px;
		padding:15px 0px;
	}
	.cart .cart-top .c-price span:last-child{
		text-align:right;
	}
	.cart .cart-bot .bu1{
		width:100%;
		height:40px;
		line-height:40px;
		color:#000;
		background: #00EEF2;
		font-size:16px;
		cursor:pointer;
		margin-bottom:20px;
	}
	.cart .cart-bot .cart-in{
		display:block;
		width:100%;
		padding-top:10px;
		padding-bottom:10px;
		padding-left:5px;
		color: #dddddd;
		background-color: #ffffff;
		margin-top:15px;
		margin-bottom:15px;
		border:1px solid #e0e0e0;
		font-size:16px;
	}
	.cart .cart-bot .bu2{
		width:100%;
		width:100%;
		padding-top:10px;
		padding-bottom:10px;
		padding-left:5px;
		color: #777;
		background-color: #ffffff;
		border:1px solid #e0e0e0;
		font-size:16px;
		cursor: pointer;
	}
	.cart .cart-bot .bu2:hover{
		color: #000000;
		border-color: #000000;
	}
	@media only screen and (min-width:992px){
	   .cart .cart-content{
	    padding-left:7%;
	    padding-right:7%;
		display:flex !important;
	    }
		.cart .cart-left{
			width:70% !important;
		}
		.cart .cart-right{
			width:30%;
		}
        .cart .cart-left{
        	border-right:1px solid #ddd;
        	padding-right:20px;
        	margin-right:20px;
        }
	}
	/* 中屏导航栏样式 */
	@media only screen and (max-width:991px){
	    .cart .cart-content{
	    padding-left:7%;
	    padding-right:7%;
	    }
        .cart table .t-first a{
        	display:block;
        	width:38px;height:20px ;
        	background-image: url('../assets/img/headfoot/cartClose.png');
        	background-size:18px,18px;
        	background-position: center;
        	margin-right:10%;
        }
	}
	/* 小屏导航栏样式 */
	@media only screen and (max-width:576px){
	    .cart .cart-content{padding:10px;}
	    
	}
</style>
