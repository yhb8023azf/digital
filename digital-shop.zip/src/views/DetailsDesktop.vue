<template>
    <div>
        <sm-header></sm-header>
        <div class="details-desktop font">
           <!--*******************评测中心导航栏**********************-->
           		<div class="desktop-first">
           			<div class="nav">
           				<router-link to="/">首页</router-link>
           				<span>&gt;</span>
           				<span><router-link to="/product/desktop">台式机/一体机</router-link></span>
           				<span>&gt;</span>
           				<span v-text="deskList.title"></span>
           			</div>
           		</div>
           <!--************************************内容部分******************************-->
           		<div class="desktop-second">
           			<div class="desktop-container">
           				<div class="content">
           					<div class="con-img">
                                   <!-- 描述上部分右侧 -->
           						<div class="con-right">
           					 		<div class="con-right-t">
           					 			<img :src="picLg[n]" class="moveImg1"/>
                                        <!-- 小方块 -->
                                         <div id="mask1"  :class="{'d-none1':!maskShow2}" :style="maskStyle2"></div>
                                         <!-- 遮罩层 -->
                                         <div id="super-mask1"  @mouseover="toggle2" @mouseout="toggle2" @mousemove="maskMove2"></div>
                                         <!-- 显示背景图 -->
                                         <div id="div-lg1" :class="{'d-none1':!maskShow2}" :style="{'background-image':`url(${picLg[n]})`,'background-position':bgPosition2}"></div>
           					 		</div>
           					 		<div class="con-right-b">
           					 			<img :src="picSm[0]" @click="changePic1(0)"/>
           					 			<img :src="picSm[1]" @click="changePic1(1)"/>
           					 			<img :src="picSm[2]" @click="changePic1(2)"/>
                                        <img :src="picSm[3]" @click="changePic1(3)"/>
           					 		</div>
           					 	</div>
                    <!--***************************** 描述上部分左侧**************************** -->
           					 	<div class="con-left">
           					 		<h1 v-text="deskList.title"></h1>
           					 		<div class="big-line">
           					 			<div></div>
           					 		</div>
           					 		<p class="con-details" v-text="deskList.subtitle"></p>
           					 		<p class="con-price" :style="dNone1"><span>{{deskList.total}}</span></p>
           					 		<form action="" class="con-cart" id="shop">
                                        <div class="versions" :style="dNone1">
                                            <div class="ver-first">
                                                <span>版本</span>
                                            </div>
                                            <div v-for="(sp,i) of specs" :key="i" class="ver-second" :class="{select1:sp.did==did}">
                                                <router-link :to="`/desktop/detail/${sp.did}`" v-text="sp.spec"></router-link>
                                            </div>
                                        </div> 
                                        <p><span class="cart-co">¥{{deskList.price}}</span></p>
                                        <div class="con-shop">
                                            <!-- 商品详情页添加购物车数量按钮 -->
                                            <button type="button" id="shop_btn1" 
                                            @click="addCart"
                                            :data-did="deskList.did"
                                            :data-title="deskList.title"
                                            :data-price="deskList.price"
                                            :data-img="deskList.img"
                                            >加入购物车</button>
                                            <button type="button" id="shop_btn2" @click="jian()">-</button>
                                            <span id="shop_span1">{{count}}</span>
                                            <button type="button" id="shop_btn3" @click="add()">+</button>
                                        </div>
                                    </form>   
                                       <div class="con-lid">
                                           <p><span>商品编号：</span> <span v-text="deskList.spec"></span> </p>
                                           <p><span>分类：</span> <span v-text="deskList.category">台式机/一体机 </span> </p>
                                       </div>                           
           					 	</div>
           					</div> 
           				</div>
           			</div>
           		</div>
                   <!--************************* 商品描述部分 ********************************-->
                   <div class="desktop-three">
                       <div class="desktop-msg">
                           <div class="msgs" id="message">
                               <div class="msgs-nav">
                                   <ul>
                                       <li><a href="javascript:;" :class="actives[0]" @click="ddMsg(0)">描述</a></li>
                                       <li><a href="javascript:;" :class="actives[1]" @click="ddMsg(1)">其它信息</a></li>
                                       <li><a href="javascript:;" :class="actives[2]" @click="ddMsg(2)">用户评价(0)</a></li>
                                   </ul>
                               </div>
                               <div class="msgs-desc">
                                   <div class="desc-cont" :style="contents[0]">
                                       <div class="desc-img">
                                           <img :src="picLg[0]" >
                                       </div>
                                   </div>
                                   <div class="msgs-tab" :style="contents[1]">
                                       <table class="desc-tab">
                                           <tr>
                                               <th>版本</th>
                                               <td><p v-text="deskList.edition"></p></td>
                                           </tr>
                                           <tr>
                                               <th>处理器</th>
                                               <td><p v-text="deskList.cpu"></p></td>
                                           </tr>
                                           <tr>
                                               <th>显卡</th>
                                               <td><p v-text="deskList.video_card"></p></td>
                                           </tr>
                                           <tr>
                                               <th>内存</th>
                                               <td><p v-text="deskList.memory">4G</p></td>
                                           </tr>
                                           <tr>
                                               <th>硬盘</th>
                                               <td><p v-text="deskList.disk">256GB SSD</p></td>
                                           </tr>
                                           <tr>
                                               <th>品牌</th>
                                               <td><p v-text="deskList.brand"></p></td>
                                           </tr>
                                       </table>
                                   </div>
                                   <div class="desc-com" :style="contents[2]">
                                       <div></div>
                                       <p>目前还未有评论</p>
                                       <p>只有买过此商品的客户登录后才能发表评论</p>
                                   </div>
                               </div>
                           </div>
                       </div>
                   </div>
                   <!-- ********************相关商品****************************************** -->
                   <div class="desktop-four">
                       <div class="desktop-pro">
                           <div class="relevant-pro">
                               <div class="pro-nav3">
                                   <h2>相关商品</h2>
                               </div>
                               <ul>
                               	<div class="pro-li1"> 
                                        <li>
                                            <div class="pro-1">
                                                <a href="" title="惠普（HP）暗影精灵23代 游戏台式电脑主机">
                                                <img src="../assets/img/product_details/corre-desktop4.jpg" class="pro-img"/></a>
                                            </div>
                                            <div class="pro-2">
                                                <a href="#">惠普（HP）暗影精灵23代 游戏台式电脑主机</a>
                                                <p><span>¥4999</span></p>
                                            </div>
                                        </li>
                                     
                                       <li>
                                           <div class="pro-1">
                                               <a href="" title=" 宏碁（Acer）商祺SQX4270 140N 商用办公台式电脑主机">
                                               <img src="../assets/img/product_details/corre-desktop2.jpg" class="pro-img"/></a>
                                           </div>
                                           <div class="pro-2">
                                               <a href="#"> 宏碁（Acer）商祺SQX4270 140N 商用办公台式电脑主机</a>
                                               <p><span>¥4999</span>-<span>¥5999</span></p>
                                           </div>
                                       </li> 
                                   </div>
                                   <div class="pro-li2">
                                         <li>    
                                            <div class="pro-1">
                                                <a href="" title="惠普（HP）暗影精灵3代 游戏台式电脑主机（i5-8400 16G高频 1T+128GSSD GTX1060 6G独显 三年上门）">
                                                <img src="../assets/img/product_details/corre-desktop1.jpg" class="pro-img"/></a>
                                            </div>
                                            <div class="pro-2">
                                                <a href="#">惠普（HP）暗影精灵3代 游戏台式电脑主机（i5-8400 16G高频 1T+128GSSD GTX1060 6G独显 三年上门）</a>
                                                <p><span>¥2999</span>-<span>¥5899</span></p>
                                            </div>
                                                                          
                                        </li>
                                       <li>
                                           <div class="pro-1">
                                               <a href="" title="惠普（HP）暗影精灵3代 游戏台式电脑主机（i5-8400 16G高频 1T+128GSSD GTX1060 6G独显 三年上门）">
                                               <img src="../assets/img/product_details/corre-desktop5.jpg" class="pro-img"/></a>
                                           </div>
                                           <div class="pro-2">
                                               <a href="#">惠普（HP）暗影精灵3代 游戏台式电脑主机（i5-8400 16G高频 1T+128GSSD GTX1060 6G独显 三年上门）</a>
                                               <p><span>¥5199</span>-<span>¥6999</span></p>
                                           </div>
                                       </li>
                                   </div>	
                               </ul>
                           </div>
                       </div>
                   </div> 
        </div>
        
        <sm-footer></sm-footer>
    </div>
</template>

<script>
    // import ShopBtn from '../components/ShopBtn.vue'
    export default{
        data(){
            return{
                // 描述部分
                actives:[
                    {active:true},
                    {active:false},
                    {active:false}
                ],
                contents:[
                    {display:"block"},
                    {display:"none"},
                    {display:"none"}
                ],
                n:0,   //记录当前正在显示第几章图片
                deskList:{price:0},//防止首次加载时product.price.toFixed(2)报错
                dpics:[{md:"",sm:"",lg:""},//防止首次加载时pics[0].md报错
                     {md:"",sm:"",lg:""},
                     {md:"",sm:"",lg:""},
                     {md:"",sm:"",lg:""},
                ],
                specs:[],
                picLg:[],//接收require请求到的图片信息
                picSm:[],
                maskShow2:false,
                maskStyle2:{
                  left:0,
                  top:0
                },
                dNone1:{display:"inline-block"},
                count:1
                
            }
        },
        props:["did"],
        computed:{
            bgPosition2(){
              var left=parseInt(this.maskStyle2.left);
              var top=parseInt(this.maskStyle2.top);
              return `-${left*16/8}px -${top*16/8}px`
            },
        },
        created() {
            this.load()
        },
        watch:{
            did(){//did变量的变化
              //只要did发生变化
              //就重新请求服务端数据
              //更换data中的变量
              this.load();
            },
        },
        methods:{
            addCart(e){
                var did=e.target.dataset.did;
                var p=e.target.dataset.price;
                var n=e.target.dataset.title;
                var i=e.target.dataset.img;
                console.log(did)
                console.log(p)
                console.log(i)
                console.log(n)
                var obj={did:did,price:p,title:n,img:i,count:this.count}
                this.axios.get("/addcart2",{params:obj}).then(res=>{
                    if(res.data.code==-1){
                            alert("请先登录")
                             //提示交互提示/跳转登录组件
                            this.$router.push("/login");
                             return;
                        }else{
                            alert("添加成功")
                        }
                })
            },
            add(){
                this.count++;
            },
             jian(){
                if(this.count>1){
                    this.count--;
                } 
             },
           // 放大镜效果-最小框移动
           maskMove2(e){
             var left=e.offsetX-119;
             var top=e.offsetY-119;
             if(left<0){
                 left=0
             }else if(left>=387){
                 left=387
             }else{
                 left=e.offsetX-119;
             }
             if(top<0){
                 top=0
             }else if(top>=176){
                 top=176
             }else{
                 top=e.offsetY-119;
             }
             top+="px";
             left+="px";
             this.maskStyle2={left,top}
           },
           // 移入移出隐藏效果
           toggle2(){
             this.maskShow2=!this.maskShow2;
           },
           load(){//封装发送ajax请求和初始化数据的方法，用于反复调用
             this.axios.get("/detail/desktop",{params:{did:this.did}}).then(res=>{
                this.deskList=res.data.product;
                this.dpics=res.data.pics;
                this.specs=res.data.specs;
               
                for(var i=0;i<this.dpics.length;i++){
                    this.picSm.push(require("../assets/"+this.dpics[i].sm));
                    this.picLg.push(require("../assets/"+this.dpics[i].lg));
                }
                if(this.did==1){
                    this.dNone1.display="none"
                }else{
                    this.dNone1.display="flex"
                }
             })  
           },
           // 点击切换图片
           changePic1(n){
               this.n=n;
           },
          // 描述部分，点击切换内容
          ddMsg(n){
            for(var i=0;i<this.actives.length;i++){
                if(n==i){
                    this.actives[i].active=true;
                    this.contents[i].display="block";
                }else{
                    this.actives[i].active=false;
                    this.contents[i].display="none";
                }
            }  
          },
        },
        // components:{
        //     "shopBtn":ShopBtn
        // }
    }
</script>

<style>
    @import url("../assets/css/details-desktop.css");
</style>
