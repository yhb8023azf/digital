<template>
    <div>
       <sm-header :active4="gender4"></sm-header>
        <div class="product font">
        <!--*************************导航***************************-->		
        		<div class="product-nav">
        			<div class="nav">
        				<router-link to="/">首页</router-link>
        				<span>></span>
        				<span>外设系列</span>
        			</div>
        		</div>
        
        <!--*************************内容部分************************************-->
        <!--******************内容左侧部分****************************************-->
        		<div class="product-content">
        			<div class="content">
        				<div class="ri-cont" id="r1">
                            <div class="left1">
                                <!--******************中屏以下时出现的导航*******************-->
                                <div class="dis">
                                    <a href="javascript:;" @click="classify()">
                                        <span >{{classify1}}</span>
                                        <img src="../assets/img/eval/xia.png" >
                                    </a> 
                                </div>
                                <ul :class="btnUl">
                                    <li>
                                        <a href="javascript:;" class="click">
                                            <div class="right-img"></div>
                                            <div class="font1">
                                                <span>鼠标</span>  
                                            </div>
                                        </a>  
                                    </li>
                                    <li>
                                        <a href="javascript:;" class="click">
                                            <div class="right-img"></div>
                                            <div class="font1">
                                                <span>键盘</span>  
                                            </div>
                                        </a>  
                                    </li>
                                    <li>
                                        <a href="javascript:;" class="click">
                                            <div class="right-img"></div>
                                            <div class="font1">
                                                <span>摄像头</span>  
                                            </div>
                                        </a>  
                                    </li>
                                    <li>
                                        <a href="javascript:;" class="click">
                                            <div class="right-img"></div>
                                            <div class="font1">
                                                <span>游戏耳机</span>  
                                            </div>
                                        </a>  
                                    </li>
                                    <li>
                                        <a href="javascript:;" class="click">
                                            <div class="right-img"></div>
                                            <div class="font1">
                                                <span>VR设备</span>  
                                            </div>
                                        </a>  
                                    </li>
                                </ul>		
                            </div>
                            
        				</div>
        <!--*******************************内容右侧部分************************-->
        				<div class="ple-con">
        					<ul>
                                <span class="con1">
                                    <li>
                                    	<div class="">
                                    		<router-link :to="`/preip/detail/${preList[12].href.split('=')[1]}`" title="索尼（SONY）WH-1000XM3 高解析度无线蓝牙降噪耳机（触控面板 智能降噪 长久续航）黑色"><img :src="preImg[12]"/></router-link>
                                    	</div>
                                    	<div class="con">
                                    		<router-link :to="`/preip/detail/${preList[12].href.split('=')[1]}`" v-text="preList[12].title"></router-link>
                                    		<p><span v-cloak>¥{{preList[12].price}}</span></p>
                                    	</div>
                                    </li>
                                    <li>
                                    	<div class="">
                                    		<router-link :to="`/preip/detail/${preList[13].href.split('=')[1]}`" title="小米米家（MIJIA）智能摄像机 云台版 白色 1080P"><img :src="preImg[13]"/></router-link>
                                    	</div>
                                    	<div class="con">
                                    		<router-link :to="`/preip/detail/${preList[13].href.split('=')[1]}`" v-text="preList[13].title"></router-link>
                                    		<p><span v-cloak>¥{{preList[13].price}}</span></p>
                                    	</div>
                                    </li>
                                </span>
                                <span class="con2">
                                    <li>
                                    	<div class="">
                                    		<router-link :to="`/preip/detail/${preList[14].href.split('=')[1]}`" title="Pico G2小怪兽2 VR一体机 4K高清视频 体感游戏 VR眼镜 3D头盔"><img :src="preImg[14]"/></router-link>
                                    	</div>
                                    	<div class="con">
                                    		<router-link :to="`/preip/detail/${preList[14].href.split('=')[1]}`" v-text="preList[14].title"></router-link>
                                    		<p><span v-cloak>¥{{preList[14].price}}</span></p>
                                    	</div>
                                    </li>
                                    <li>
                                    	<div class="">
                                    		<router-link :to="`/preip/detail/${preList[15].href.split('=')[1]}`" title="联想大红点M120Pro有线鼠标 台式机鼠标 笔记本鼠标"><img :src="preImg[15]"/></router-link>
                                    	</div>
                                    	<div class="con">
                                    		<router-link :to="`/preip/detail/${preList[15].href.split('=')[1]}`" v-text="preList[15].title"></router-link>
                                    		<p><span v-cloak>¥{{preList[15].price}}</span></p>
                                    	</div>
                                    </li>
                                </span>
                                <span class="con3">
                                    <li>
                                    	<div class="">
                                    		<router-link :to="`/preip/detail/${preList[16].href.split('=')[1]}`" title="M330 无线静音鼠标 舒适曲线 黑色 M275升级版"><img :src="preImg[16]"/></router-link>
                                    	</div>
                                    	<div class="con">
                                    		<router-link :to="`/preip/detail/${preList[16].href.split('=')[1]}`" v-text="preList[16].title"></router-link>
                                    		<p><span v-cloak>¥{{preList[16].price}}</span></p>
                                    	</div>
                                    </li>
                                    <li>
                                    	<div class="">
                                    		<router-link :to="`/preip/detail/${preList[17].href.split('=')[1]}`" title="全尺寸背光机械游戏键盘 机械键盘 红轴 吃鸡键盘 绝地求生"><img :src="preImg[17]"/></router-link>
                                    	</div>
                                    	<div class="con">
                                    		<router-link :to="`/preip/detail/${preList[17].href.split('=')[1]}`" v-text="preList[17].title"></router-link>
                                    		<p><span v-cloak>¥{{preList[17].price}}</span></p>
                                    	</div>
                                    </li>
                                </span>
        					</ul>
        				</div>
        			</div>
        		</div>
        	</div>
       <sm-footer></sm-footer>
        
    </div>
</template>

<script>
    export default{
        data(){
            return{
                btnUl:{
                    dis1:true,
                    dis2:false
                },
                classify1:"按分类浏览",
				preList:[
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
				],
				preImg:[],
				gender4:4,
            }
        },
		props:["family_ids"],
		created() {
			this.load()
		},
        methods:{
			load(){
				var url='/index'
				this.axios.get(url).then(result=>{
				    this.preList=result.data;
				    for(var i=0;i<this.preList.length;i++){
				        this.preImg.push(require("../assets/"+this.preList[i].pic))
				    }
				})
				console.log(this.gender4)
			},
            classify(){
                if(this.classify1=="按分类浏览"){
                    this.btnUl={
                        dis1:false,
                        dis2:true
                    },
                    this.classify1="关闭"
                }else{
                    this.btnUl={
                        dis1:true,
                        dis2:false
                    },
                    this.classify1="按分类浏览"
                }
            }
        }
    }
</script>

<style>
    @import url("../assets/css/product-preip.css");
</style>
