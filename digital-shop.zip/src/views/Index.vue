<template>
    <div>
        <!-- ***********************************头部***************************** -->
        <sm-header :active1="gender1"/>
        <!-- *******************************首页内容********************************* -->
        <div class="index font">
        <!--*****************首页导航和轮播**********************-->
        <!-- 背景轮播组件 -->
        <carousel></carousel>
        <!--*****************导航下固定部分**********************-->
        		<div class="index1">
        			<div class="fiex">
        				<div class="fiex-left">
        					<div class="fiex1">
        						<img src="../assets/img/index/xiao3.png"/>
        						<p class="font-small">以旧换新</p>
        					</div>                                                                                                                                                                                                                                               
        					<div class="fiex2">
        						<img src="../assets/img/index/xiao2.png"/>
        						<p class="font-small">评测中心</p>
        					</div>
        				</div>
        				<div class="fiex-right">
        					<div class="fiex3">
        						<img src="../assets/img/index/xiao4.png"/>
        						<p class="font-small">驱动下载</p>
        					</div>
        					<div class="fiex4">
        						<img src="../assets/img/index/xiao1.png"/>
        						<p class="font-small">售后服务</p>
        					</div>
        				</div>
        			</div>
        			<img src="../assets/img/index/lunbo1.jpg" class="lun1 goto" :class="animations" :style="anmiDely1">
        			<img src="../assets/img/index/lonbo3.jpg" class="lun1 goto" :class="animations" :style="anmiDely2">
        			<img src="../assets/img/index/lunbo2.jpg" class="lun1 goto" :class="animations" :style="anmiDely3">
        		</div>
        <!--*****************精品单选推荐************************-->
        		<div class="index3">
        			<div class="recommendation">
        				<div class="rec-title font-small">
        					<p>精选单品推荐</p>
        				</div>
        				<div class="rec-laptop font-small">
        					<div class="laptop-y7 goto" :class="animations" :style="anmiDely1">
        						<router-link :to="`/laptop/detail/${list1[0].href.split('=')[1]}`">
        							<img :src="pic1[0]"/>
        							<h4 title="拯救者 Y7000 15.6英寸游戏本 黑色81FW0009CD" v-text="list1[0].title"></h4>
        						</router-link>
        						<p class="index3-title" v-text="list1[0].details"></p>
        					</div>
        					<div class="laptop-sw goto" :class="animations" :style="anmiDely2">
        						<router-link :to="`/laptop/detail/${list1[1].href.split('=')[1]}`">
        							<img :src="pic1[1]"/>
        							<h4 title="14英寸四核独显轻薄商务便携笔记本电脑" v-text="list1[1].title"></h4>
        						</router-link>
        						<p v-text="list1[1].details"></p>
        					</div>
        					<div class="laptop-hc goto" :class="animations" :style="anmiDely3">
        						<router-link :to="`/laptop/detail/${list1[2].href.split('=')[1]}`">
        							<img :src="pic1[2]"/>
        							<h4 title="15.6英寸游戏笔记本 黑色 81HC0007CD" v-text="list1[2].title"></h4>
        						</router-link>
        						<p v-text="list1[2].details"></p>
        					</div>
        					<div class="laptop-tx1 goto" :class="animations" :style="anmiDely4">
        						<router-link :to="`/laptop/detail/${list1[3].href.split('=')[1]}`">
        							<img :src="pic1[3]"/>
        							<h4 title="13.3英寸触控笔记本 天蝎灰 81CT0001CD" v-text="list1[3].title"></h4>
        						</router-link>
        						<p v-text="list1[3].details"></p>
        					</div>
        					<div class="laptop-tp goto" :class="animations" :style="anmiDely5">
        						<router-link :to="`/laptop/detail/${list1[4].href.split('=')[1]}`">
        							<img :src="pic1[4]"/>
        							<h4 title=" ThinkPad T480 笔记本电脑" v-text="list1[4].title"> </h4>
        						</router-link>
        						<p v-text="list1[4].details"></p>
        					</div>
        					
        				</div>
        			</div>
        		</div>
        <!--*****************笔记本/游戏本***********************-->
        		<div class="index4">
        			<!--笔记本/游戏本标题栏-->
        			<div class="index-bg">
        				<div class="laptop-lap">
                            <router-link to="/product/laptop/1">笔记本/游戏本</router-link>
                            <router-link to="/product/laptop/1">MORE+</router-link>
        				</div>
        			</div>
        			<!--笔记本/游戏本信息-->
        			<div class="index4-laptop">
        				<div class="laptop-img padTop" style="overflow:hidden;clear:both;">
        					<!--左边大图-->
        					<div class="laptop-lbig goto" :class="animations1" :style="anmiDely1">
        						<img src="../assets/img/index/laptop1.jpg"/>
        					</div>
        					<!--右边6小图-->
        					<div class="laptop-rsmall">
        						<!--右一-->
        						<div class="laptop-r1-small">
        							<div class="rt-tsmall-sw goto" :class="animations" :style="anmiDely1">
        								<router-link :to="`/laptop/detail/${list2[0].href.split('=')[1]}`">
        									<img :src="pic2[0]"/>
        									<h4 title="14英寸四核独显轻薄商务便携笔记本电脑" v-text="list2[0].title"></h4>
        								</router-link>
        								<p v-text="list2[0].details"></p>
        								<span v-cloak>¥{{list2[0].price}}</span>
        							</div>
        							<div class="rb-small-hc goto" :class="animations" :style="anmiDely1">
        								<router-link :to="`/laptop/detail/${list2[1].href.split('=')[1]}`">
        									<img :src="pic2[1]"/>
        									<h4 title="15.6英寸游戏笔记本 黑色 81HC0007CD" v-text="list2[1].title"></h4>
        								</router-link>
        								<p v-text="list2[1].details"></p>
        								<span v-cloak>¥{{list2[1].price}}</span>
        							</div>
        						</div>
        						<!--右二-->
        						<div class="laptop-r2-small">
        							<div class="rt-tsmall-zj goto" :class="animations" :style="anmiDely2">
        								<router-link :to="`/laptop/detail/${list2[2].href.split('=')[1]}`">
        									<img :src="pic2[2]"/>
        									<h4 title="15.6英寸游戏笔记本 黑色 80WW000TCD" v-text="list2[2].title"></h4>
        								</router-link>
        								<p v-text="list2[2].details"></p>
        								<span v-cloak>¥{{list2[2].price}}</span>
        							</div>
        							<div class="rb-small-tx goto" :class="animations" :style="anmiDely2">
        								<router-link :to="`/laptop/detail/${list2[3].href.split('=')[1]}`">
        									<img :src="pic2[3]"/>
        									<h4 title="13.3英寸触控笔记本 天蝎灰 81CT0001CD" v-text="list2[3].title"></h4>
        								</router-link>
        								<p v-text="list2[3].details"></p>
        								<span v-cloak>¥{{list2[3].price}}</span>
        							</div>
        						</div>
        						<!--右三-->
        						<div class="laptop-r3-small">
        							<div class="rt-tsmall-zjz goto" :class="animations" :style="anmiDely3">
        								<router-link :to="`/laptop/detail/${list2[4].href.split('=')[1]}`">
        									<img :src="pic2[4]"/>
        									<h4 title=" E580 笔记本电脑 20KSA001CD" v-text="list2[4].title"></h4>
        								</router-link>
        								<p v-text="list2[4].details"></p>
        								<span v-cloak>¥{{list2[4].price}}</span>
        							</div>
        							<div class="rb-small-x2 goto" :class="animations" :style="anmiDely3">
        								<router-link :to="`/laptop/detail/${list2[5].href.split('=')[1]}`">
        									<img :src="pic2[5]"/>
        									<h4 title=" X280 笔记本电脑 20KFA002CD" v-text="list2[5].title"></h4>
        								</router-link>
        								<p v-text="list2[5].details"></p>
        								<span v-cloak>¥{{list2[5].price}}</span>
        							</div>
        						</div>
        					</div>
        				</div>				
        			</div>
        		</div>
        <!--*****************台式机/一体机***********************-->
        		<div class="index5">
        			<!--台式机/一体机标题栏-->
        			<div class="index-bg">
        				<div class="desktop-desk">
                            <router-link to="/product/desktop/2">台式机/一体机</router-link>
                            <router-link to="/product/desktop/2">MORE+</router-link>
        				</div>
        			</div>
        			<!--台式机/一体机信息-->
        			<div class="index5-desktop">
        				<div class="desktop-img padTop" style="overflow:hidden;clear:both;">
        					<!--左边大图-->
        					<div class="desktop-lbig goto" :class="animations1" :style="anmiDely1">
        						<img src="../assets/img/index/desktop1.jpg"/>
        					</div>
        					<!--右边6小图-->
        					<div class="desktop-rsmall">
        						<!--右一-->
        						<div class="desktop-r1-small">
        							<div class="rt-tsmall-sw goto" :class="animations" :style="anmiDely1">
        								<router-link :to="`/desktop/detail/${list2[6].href.split('=')[1]}`">
        									<img :src="pic2[6]"/>
        									<h4 title="惠普（HP）暗影精灵23代 游戏台式电脑主机" v-text="list2[6].title"></h4>
        								</router-link>
        								<p v-text="list2[6].details"></p>
        								<span v-cloak>¥{{list2[6].price}}</span>
        							</div>
        							<div class="rb-small-hc goto" :class="animations" :style="anmiDely1">
        								<router-link :to="`/desktop/detail/${list2[7].href.split('=')[1]}`">
        									<img :src="pic2[7]"/>
        									<h4 title="联想（Lenovo）天逸510S 第八代英特尔酷睿i3 个人商务台式电脑主机" v-text="list2[7].title"></h4>
        								</router-link>
        								<p v-text="list2[7].details"></p>
        								<span v-cloak>{{list2[7].price}}</span>
        							</div>
        						</div>
        						<!--右二-->
        						<div class="desktop-r2-small">
        							<div class="rt-tsmall-zj goto" :class="animations" :style="anmiDely2">
        								<router-link :to="`/desktop/detail/${list2[8].href.split('=')[1]}`">
        									<img :src="pic2[8]"/>
        									<h4 title="惠普（HP）暗影精灵3代 游戏台式电脑主机（i7-8700 16G高频 1T+256GSSD GTX1060 6G独显 三年上门）" v-text="list2[8].title"></h4>
        								</router-link>
        								<p v-text="list2[8].details"></p>
        								<span v-cloak>{{list2[8].price}}</span>
        							</div>
        							<div class="rb-small-tx goto" :class="animations" :style="anmiDely2">
        								<router-link :to="`/desktop/detail/${list2[9].href.split('=')[1]}`">
        									<img :src="pic2[9]"/>
        									<h4 title="戴尔(DELL)灵越3670台式电脑主机" v-text="list2[9].title"></h4>
        								</router-link>
        								<p v-text="list2[9].details"></p>
        								<span v-cloak>{{list2[9].price}}</span>
        							</div>
        						</div>
        						<!--右三-->
        						<div class="desktop-r3-small">
        							<div class="rt-tsmall-zjz goto" :class="animations" :style="anmiDely3">
        								<router-link :to="`/desktop/detail/${list2[10].href.split('=')[1]}`">
        									<img :src="pic2[10]"/>
        									<h4 title="宏碁（Acer）商祺SQX4270 140N 商用办公台式电脑主机" v-text="list2[10].title"></h4>
        								</router-link>
        								<p v-text="list2[10].details"></p>
        								<span v-cloak>{{list2[10].price}}</span>
        							</div>
        							<div class="rb-small-x2 goto" :class="animations" :style="anmiDely3">
        								<router-link :to="`/desktop/detail/${list2[11].href.split('=')[1]}`">
        									<img :src="pic2[11]"/>
        									<h4 title="惠普（HP）暗影精灵3代 游戏台式电脑主机（i5-8400 16G高频 1T+128GSSD GTX1060 6G独显 三年上门）" v-text="list2[11].title"></h4>
        								</router-link>
        								<p v-text="list2[11].details"></p>
        								<span v-cloak>{{list2[11].price}}</span>
        							</div>
        						</div>
        					</div>
        				</div>				
        			</div>
        		</div>
        <!--*****************外设系列***************************-->
        		<div class="index6">
        			<!--外设系列题栏-->
        			<div class="index-bg">
        				<div class="perip-per">
                            <router-link to="/product/preip/3">外设系列</router-link>
        					<router-link to="/product/preip/3">
        						<span>鼠标</span>
        						<span>键盘</span>
        						<span>摄像头</span>
        					</router-link>
        				</div>
        			</div>
        			<!--外设系列信息-->
        			<div class="index6-perip">
        				<div class="perip-img padTop" style="overflow:hidden;clear:both;">
        					<!--左边大图-->
        					<div class="perip-lbig goto">
        						<img src="../assets/img/index/peripheral1.jpg" :class="animations1" :style="anmiDely1"/>
        						<img src="../assets/img/index/peripheral3.jpg" :class="animations1" :style="anmiDely2"/>
        					</div>
        					<!--右边6小图-->
        					<div class="perip-rsmall">
        						<!--右一-->
        						<div class="perip-r1-small">
        							<div class="rt-tsmall-sw goto" :class="animations" :style="anmiDely1">
        								<router-link :to="`/preip/detail/${list2[12].href.split('=')[1]}`">
        									<img :src="pic2[12]"/>
        									<h4 title="索尼（SONY）WH-1000XM3 高解析度无线蓝牙降噪耳机（触控面板 智能降噪 长久续航）黑色" v-text="list2[12].title"></h4>
        								</router-link>
        								<p v-text="list2[12].details"></p>
        								<span class="del-line"><s>￥1699</s><span v-cloak>¥{{list2[12].price}}</span></span>
        							</div>
        							<div class="rb-small-hc goto" :class="animations" :style="anmiDely1">
        								<router-link :to="`/preip/detail/${list2[13].href.split('=')[1]}`">
        									<img :src="pic2[13]"/>
        									<h4 title="联想大红点M120Pro有线鼠标 台式机鼠标 笔记本鼠标" v-text="list2[13].title"></h4>
        								</router-link>
        								<p v-text="list2[13].details"></p>
        								<span v-cloak>¥{{list2[13].price}}</span>
        							</div>
        						</div>
        						<!--右二-->
        						<div class="perip-r2-small">
        							<div class="rt-tsmall-zj goto" :class="animations" :style="anmiDely2">
        								<router-link :to="`/preip/detail/${list2[14].href.split('=')[1]}`">
        									<img :src="pic2[14]"/>
        									<h4 title="小米米家（MIJIA）智能摄像机 云台版 白色 1080P" v-text="list2[14].title"></h4>
        								</router-link>
        								<p v-text="list2[14].details"></p>
        								<span v-cloak>¥{{list2[14].price}}</span>
        							</div>
        							<div class="rb-small-tx goto" :class="animations" :style="anmiDely2">
        								<router-link :to="`/preip/detail/${list2[15].href.split('=')[1]}`">
        									<img :src="pic2[15]"/>
        									<h4 title="M330 无线静音鼠标 舒适曲线 黑色 M275升级版" v-text="list2[15].title"></h4>
        								</router-link>
        								<p v-text="list2[15].details"></p>
        								<span v-cloak>¥{{list2[15].price}}</span>
        							</div>
        						</div>
        						<!--右三-->
        						<div class="perip-r3-small">
        							<div class="rt-tsmall-zjz goto" :class="animations" :style="anmiDely3">
        								<router-link :to="`/preip/detail/${list2[16].href.split('=')[1]}`">
        									<img :src="pic2[16]"/>
        									<h4 title="Pico G2小怪兽2 VR一体机 4K高清视频 体感游戏 VR眼镜 3D头盔" v-text="list2[16].title"></h4>
        								</router-link>
        								<p v-text="list2[16].details"></p>
        								<span v-cloak>¥{{list2[16].price}}</span>
        							</div>
        							<div class="rb-small-x2 goto" :class="animations" :style="anmiDely3">
        								<router-link :to="`/preip/detail/${list2[17].href.split('=')[1]}`">
        									<img :src="pic2[17]"/>
        									<h4 title="全尺寸背光机械游戏键盘 机械键盘 红轴 吃鸡键盘 绝地求生" v-text="list2[17].title"></h4>
        								</router-link>
        								<p v-text="list2[17].details"></p>
        								<span v-cloak>¥{{list2[17].price}}</span>
        							</div>
        						</div>
        					</div>
        				</div>				
        			</div>
        		</div>
        <!--*****************热评产品***************************-->
        		<div class="index7">
        			<!--标题-->
        			<div class="hot-product-title">
        				<div class="product-hot">
        					<a>热评产品</a>
        				</div>
        			</div>
        			<!--热评产品详细列表-->
        			<div class="hot-product-list">
        				<div class="product-list padTop" style="overflow:hidden;">
        					<div class="product-tk goto" :class="animations" :style="anmiDely1">
        						<router-link :to="`/laptop/detail/${list3[0].href.split('=')[1]}`">
        							<img :src="pic3[0]"/>
        							<h4 title=" ThinkPad T480 笔记本电脑" v-text="list3[0].title"></h4>
        						</router-link>
        						<p v-text="list3[0].details"></p>
        						<span class="p-color" v-cloak>¥{{list3[0].price}}</span>
        					</div>
        					<div class="product-x2 goto" :class="animations" :style="anmiDely2">
        						<router-link :to="`/laptop/detail/${list3[1].href.split('=')[1]}`">
        							<img :src="pic3[1]"/>
        							<h4 title="X280 笔记本电脑 20KFA002CD" v-text="list3[1].title"></h4>
        						</router-link>
        						<p v-text="list3[1].details"></p>
        						<span class="p-color" v-cloak>¥{{list3[1].price}}</span>
        					</div>
        					<div class="product-e5 goto" :class="animations" :style="anmiDely3">
        						<router-link :to="`/laptop/detail/${list3[2].href.split('=')[1]}`">
        							<img :src="pic3[2]"/>
        							<h4 title="E580 笔记本电脑 20KSA001CD" v-text="list3[2].title"></h4>
        						</router-link>
        						<p v-text="list3[2].details"></p>
        						<span class="p-color" v-cloak>¥{{list3[2].price}}</span>
        					</div>
        					<div class="product-hp goto" :class="animations" :style="anmiDely4">
        						<router-link :to="`/desktop/detail/${list3[3].href.split('=')[1]}`">
        							<img :src="pic3[3]"/>
        							<h4 title="惠普（HP）暗影精灵23代 游戏台式电脑主机" v-text="list3[3].title"></h4>
        						</router-link>
        						<p v-text="list3[3].details"></p>
        						<span class="p-color" v-cloak>¥{{list3[3].price}}</span>
        					</div>
        					<div class="product-dell goto" :class="animations" :style="anmiDely5">
        						<router-link :to="`/desktop/detail/${list3[4].href.split('=')[1]}`">
        							<img :src="pic3[4]"/>
        							<h4 title="戴尔(DELL)灵越3670台式电脑主机" v-text="list3[4].title"></h4>
        						</router-link>
        						<p v-text="list3[4].details"></p>
        						<span class="p-color" v-cloak>{{list3[4].price}}</span>
        					</div>
        				</div>
        			</div>
        		</div>
        <!--*****************评测中心***************************-->
        		<div class="index8">
        			<div class="index8-title">
        				<div class="evaluating-title">
                            <router-link to="/evaluating">评测中心</router-link>
                            <router-link to="/evaluating">MORE+</router-link>
        				</div>
        			</div>
        			<div class="evaluating-list padTop" style="overflow:hidden;">
        				<div class="eval-e4 goto" :class="animations" :style="anmiDely1">
        					<router-link to="/evaluating/daping">
        						<img src="../assets/img/index/evaluating2.jpg"/>
        						<h4 title="大屏轻薄笔记本？17英寸LG gram开箱体验">大屏轻薄笔记本？17英寸LG gram...</h4>
        					</router-link>
        					<p>RTX 20系显卡登陆移动平台可谓是近期笔记本市场最大的事件，虽然第八代酷睿处理器的登场为移动平台带来了六核心的强悍规格...</p>
        				</div>
        				<div class="eval-e1 goto" :class="animations" :style="anmiDely2">
        					<router-link to="/evaluating/baqian">
        						<img src="../assets/img/index/evaluating3.jpg"/>
        						<h4 title="八千元RTX游戏本真香 惠普暗影精灵4 Pro">八千元RTX游戏本真香 惠普暗影精...</h4>
        					</router-link>
        					<p>RTX独显游戏本的到来是今年初PC领域最受关注的事件之一，而在众多首发产品中，惠普暗影精灵4 Pro可以说是最受追捧的型...</p>
        				</div>
        				<div class="eval-e2 goto" :class="animations" :style="anmiDely3">
        					<router-link to="/evaluating/yiyan">
        						<img src="../assets/img/index/evaluating.jpg"/>
        						<h4 title="一眼即世界 92%屏占比华硕灵耀U 2代体验">一眼即世界 92%屏占比华硕灵耀U...</h4>
        					</router-link>
        					<p>华硕顽石热血版YX570U相信很多人都有了解，这款产品采用酷睿低压处理器+GTX1050显卡的配置组合，相比游戏本拥有更...</p>
        				</div>
        				<div class="eval-e3 goto" :class="animations" :style="anmiDely4">
        					<router-link to="/evaluating/shice">
        						<img src="../assets/img/index/evaluating1.jpg"/>
        						<h4 title="实测：数据佐证RTX Max-Q版与标准版差多少">实测：数据佐证RTX Max-Q版与标...</h4>
        					</router-link>
        					<p>与10系显卡先推标准版再推Max-Q版不同，20系RTX显卡登陆游戏本之时，同时推出了标准版和Max-Q版。近期收到多名...</p>
        				</div>
        			</div>
        		</div>
        	</div>
        <!-- ********************************脚部*************************** -->
        <sm-footer></sm-footer>
    </div>
    
   
</template>

<script>
    // 引入轮播子组件
    import Carousel from '../components/Carousel'
    export default{
       data(){
           return{
               //保存从数据库访问到的精选商品信息
               list1:[
                  {title:'',pic:'',details:'', href:''}, 
                  {title:'',pic:'',details:'', href:''}, 
                  {title:'',pic:'',details:'', href:''}, 
                  {title:'',pic:'',details:'', href:''}, 
                  {title:'',pic:'',details:'', href:''}, 
               ],
               // 定义承接require引入图片的变量
               pic1:[],
               pic2:[],
               pic3:[],
               //保存从数据库访问到的笔记本、台式机、外设系列商品信息
               list2:[{title:'',pic:'',details:'', href:'',price:''},
                    {title:'',pic:'',details:'', href:'',price:''},
                    {title:'',pic:'',details:'', href:'',price:''},
                    {title:'',pic:'',details:'', href:'',price:''},
                    {title:'',pic:'',details:'', href:'',price:''},
                    {title:'',pic:'',details:'', href:'',price:''},
                    {title:'',pic:'',details:'', href:'',price:''},
                    {title:'',pic:'',details:'', href:'',price:''},
                    {title:'',pic:'',details:'', href:'',price:''},
                    {title:'',pic:'',details:'', href:'',price:''},
                    {title:'',pic:'',details:'', href:'',price:''},
                    {title:'',pic:'',details:'', href:'',price:''},
                    {title:'',pic:'',details:'', href:'',price:''},
                    {title:'',pic:'',details:'', href:'',price:''},
                    {title:'',pic:'',details:'', href:'',price:''},
                    {title:'',pic:'',details:'', href:'',price:''},
                    {title:'',pic:'',details:'', href:'',price:''},
                    {title:'',pic:'',details:'', href:'',price:''},
                ],
               //保存从数据库访问到的热评商品信息
               list3:[
                 {title:'',pic:'',details:'', href:'',price:''},  
                 {title:'',pic:'',details:'', href:'',price:''},  
                 {title:'',pic:'',details:'', href:'',price:''},  
                 {title:'',pic:'',details:'', href:'',price:''},  
                 {title:'',pic:'',details:'', href:'',price:''},  
               ],
               // 首次页面刷新的动画效果
               animations:{
                  anim1:true,
                  anim2:false
               },
               animations1:{
                  anim1:true,
                  anim3:false
               },
               anmiDely1:{animationDelay:"0s"},
               anmiDely2:{animationDelay:"0s"},
               anmiDely3:{animationDelay:"0s"},
               anmiDely4:{animationDelay:"0s"},
               anmiDely5:{animationDelay:"0s"},
			   // 传入子组件的值
			   gender1:1,
           }
            
       },
       
       created() {
           // 定义页面滚动效果函数
            window.addEventListener('scroll',this.pageSetup)
            // axios异步访问精选商品信息
            var url2='/index'
            this.axios.get(url2).then(result=>{
                this.list2=result.data;
                for(var i=0;i<this.list2.length;i++){
                    this.pic2.push(require("../assets/"+this.list2[i].pic))
                }
            })
            var url1='/index/selection'
            this.axios.get(url1).then(result=>{
                this.list1=result.data
                for(var i=0;i<this.list1.length;i++){
                    this.pic1.push(require("../assets/"+this.list1[i].pic))
                }
            })
            var url3='/index/hot'
            this.axios.get(url3).then(result=>{
                this.list3=result.data
                for(var i=0;i<this.list3.length;i++){
                    this.pic3.push(require("../assets/"+this.list3[i].pic))
                }
            })
       },
       methods:{
           // 当滚轮滑动到当前位置，当前位置图片样式发生变化
           pageSetup(){
               // 获取滑轮滚动过后到顶部的距离
               var ah=document.documentElement.scrollTop || document.body.scrollTop
               // 获取浏览器可视窗口高度
               var ch=document.documentElement.clientHeight ||document.body.clientHeight
               // 获取目标元素在可视窗口的距离
               var objHeight=document.querySelectorAll(".goto")
                for(var i=0;i<objHeight.length;i++){
                  if(ch+ah-500>objHeight[i].offsetTop){
                      this.animations={
                        anim1:false,
                        anim2:true 
                      }
                      this.animations1={
                        anim1:false,
                        anim3:true 
                      }
                      this.anmiDely2.animationDelay="0.1s";
                      this.anmiDely3.animationDelay="0.2s";
                      this.anmiDely4.animationDelay="0.3s";
                      this.anmiDely5.animationDelay="0.4s";
                  }
               }
               
               
           }
       },
       components:{
           'carousel':Carousel
       }
    }
</script>

<style scoped>
    @import url("../assets/css/index.css");
</style>
