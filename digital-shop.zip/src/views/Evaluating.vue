<template>
    <div>
        <sm-header :active5="gender5"></sm-header>
        <div class="evaluating">
        <!--*******************评测中心导航栏**********************-->
        		<div class="eval-first">
        			<div class="enav1">
        				<router-link to="/">首页</router-link>
        				<span>&gt;</span>
        				<span>评测中心</span>
        			</div>
        		</div>
        <!--*******************评测中心内容部分********************-->
        		<div class="eval-second">
        			<div class="eval-content1">
        				<!--左侧导航部分-->
        				<div class="content-left" id="run">
                            <div class="left1">
                                <div class="dis">
                                    <a href="javascript:;">
                                        <span>按分类浏览</span>
                                        <img src="../assets/img/eval/xia.png" >
                                    </a> 
                                </div>
                                <ul class="">
                                    <li>
                                        <a href="javascript:;" class="click">
                                            <div class="right-img"></div>
                                            <div class="font1">
                                                <span>全部资讯</span>  
                                            </div>
                                        </a>  
                                    </li>
                                    <li>
                                        <a href="javascript:;" class="click">
                                            <div class="right-img"></div>
                                            <div class="font1">
                                                <span>技术分析</span>  
                                            </div>
                                        </a>  
                                    </li>
                                    <li>
                                        <a href="javascript:;" class="click">
                                            <div class="right-img"></div>
                                            <div class="font1">
                                                <span>行业新闻</span>  
                                            </div>
                                        </a> 
                                    </li>
                                </ul>
                            </div> 
        				</div>
        				<!--右侧部分-->
        				<div class="content-right" id="conceal">
        					<ul>
        						<li>
        							<div class="first-info1">
        								<router-link to="evaluating/daping"><img src="../assets/img/eval/eval2.jpg"/></router-link>
        							</div>
        							<div class="first-info2">
                                        <div class="">
                                            <router-link to="evaluating/daping">大屏轻薄笔记本？17英寸LG gram开箱体验</router-link>
                                            <h6 class="font">发布日期：2019-03-05</h6>
                                            <p class="font">RTX 20系显卡登陆移动平台可谓是近期笔记本市场最大的事件，虽然第八代酷睿处理器的登场为移动平台带来了六核心的强悍规格，但颇为“长寿”的10系显卡始终是一些消费者换机的...</p> 
                                        </div>
        								
        							</div>
        						</li>
        						<li>
        							<div class="first-info1">
        								<router-link to="evaluating/baqian"><img src="../assets/img/eval/eval5.jpg"/></router-link>
        							</div>
        							<div class="first-info2">
                                        <div class="">
                                            <router-link to="evaluating/baqian">八千元RTX游戏本真香 惠普暗影精灵4 Pro</router-link>
                                            <h6 class="font">发布日期：2019-03-05</h6>
                                            <p class="font">RTX独显游戏本的到来是今年初PC领域最受关注的事件之一，而在众多首发产品中，惠普暗影精灵4 Pro可以说是最受追捧的型号之一，这是因为惠普暗影精灵4 Pro在拥有RTX...</p> 
                                        </div>
        								
        							</div>
        						</li>
        						<li>
        							<div class="first-info1">
        								<router-link to="evaluating/yiyan"><img src="../assets/img/eval/eval3.jpg"/></router-link>
        							</div>
        							<div class="first-info2">
                                        <div class="">
                                            <router-link to="evaluating/yiyan"> 一眼即世界 92%屏占比华硕灵耀U 2代体验</router-link>
                                            <h6 class="font">发布日期：2019-03-05</h6>
                                            <p class="font">华硕顽石热血版YX570U相信很多人都有了解，这款产品采用酷睿低压处理器+GTX1050显卡的配置组合，相比游戏本拥有更加时尚内敛的外观设计，只不过堪比游戏本的售价让人有...</p> 
                                        </div>
        								
        							</div>
        						</li>
        						<li>
        							<div class="first-info1">
        								<router-link to="evaluating/shice"><img src="../assets/img/eval/eval1.jpg"/></router-link>
        							</div>
        							<div class="first-info2">
                                        <div class="">
                                            <router-link to="evaluating/shice">实测：数据佐证RTX Max-Q版与标准版差多少</router-link>
                                            <h6 class="font">发布日期：2019-03-05</h6>
                                            <p class="font">与10系显卡先推标准版再推Max-Q版不同，20系RTX显卡登陆游戏本之时，同时推出了标准版和Max-Q版。近期收到多名网友咨询同一型号下两者性能相差多少的问题，相信很多...</p>
                                        </div>
        								
        							</div>
        						</li>
        						<li>
        							<div class="first-info1">
        								<router-link to="evaluating/ruibu"><img src="../assets/img/eval/eval6.png"/></router-link>
        							</div>
        							<div class="first-info2">
                                        <div class="">
                                            <router-link to="evaluating/ruibu">锐不可当！华硕顽石YX570锐龙版游戏测试</router-link>
                                            <h6 class="font">发布日期：2019-03-05</h6>
                                            <p class="font">华硕顽石热血版YX570U相信很多人都有了解，这款产品采用酷睿低压处理器+GTX1050显卡的配置组合，相比游戏本拥有更加时尚内敛的外观设计，只不过堪比游戏本的售价让人有...</p>
                                        </div>
        								
        							</div>
        						</li>
                                <li class="show" :style="showClick1">
                                    <ul>
                                        <li>
                                            <div class="first-info1">
                                            	<router-link to="evaluating/jizhi"><img src="../assets/img/eval/eval5.jpg"/></router-link>
                                            </div>
                                            <div class="first-info2">
                                                <div class="">
                                                    <router-link to="evaluating/jizhi">极致体验性能爆表 惠普暗影精灵4 Pro游戏测试</router-link>
                                                    <h6 class="font">发布日期：2017-05-16</h6>
                                                    <p class="font">RTX独显游戏本的到来是今年初PC领域最受关注的事件之一，而在众多首发产品中，惠普暗影精灵4 Pro可以说是最受追捧的型号之一，这是因为惠普暗影精灵4 Pro在拥有RT...</p>
                                                </div>
                                            	
                                            </div>
                                        </li>
                                        <li>
                                            <div class="first-info1">
                                            	<router-link to="evaluating/apex"><img src="../assets/img/eval/eval10.jpg"/></router-link>
                                            </div>
                                            <div class="first-info2">
                                                <div class="">
                                                    <router-link to="evaluating/apex">APEX英雄玩家必看 光影精灵4的实测表现强劲</router-link>
                                                    <h6 class="font">发布日期：2017-05-16</h6>
                                                    <p class="font">最近，《APEX英雄》火到已经被作弊器团队盯上了，网传腾讯也在与EA洽谈国服代理事宜。那么目前主流游戏本运行《APEX英雄》会有怎样表现呢，此次我们使用惠普光影精灵4绿刃...</p>
                                                </div>
                                            	
                                            </div>
                                        </li>
                                        <li>
                                           <div class="first-info1">
                                           	<router-link to="evaluating/rtx"><img src="../assets/img/eval/eval2.jpg"/></router-link>
                                           </div>
                                           <div class="first-info2">
                                               <div class="">
                                                   <router-link to="evaluating/rtx">RTX时代来临 机械革命深海幽灵Z2评测</router-link>
                                                   <h6 class="font">发布日期：2017-05-16</h6>
                                                   <p class="font">RTX 20系显卡登陆移动平台可谓是近期笔记本市场最大的事件，虽然第八代酷睿处理器的登场为移动平台带来了六核心的强悍规格，但颇为“长寿”的10系显卡始终是一些消费者换机...</p>
                                               </div>
                                           	
                                           </div> 
                                        </li>
                                    </ul>
                                </li>
        					</ul>
        					<div class="but">
        						<a href="javascript:;" @click="showClick" :style="noneBtn">查看更多</a>
        					</div>
        				</div>
        			</div>
        		</div>
        	</div>
        <sm-footer></sm-footer>
    </div>
</template>

<script>
    export default{
        data(){
            return{
              gender5:5,
               showClick1:{display:"none"},
               noneBtn:{display:"block"},
            }
        },
        mounted(){
            (function(){
                //当点击左侧导航栏，点击后，字体变为红色，背景为灰色 
                var run=document.querySelectorAll("#run ul>li>a.click");
                for(var elem of run){
                    elem.onclick=function(){
                      var elem=this;
                      var c=document.querySelectorAll("#run ul>li>a.click1");
                      if(c.length!=0){
                          c[0].className="click";
                      }
                          elem.className="click1"
                      
                    }
                } 
               
                //在中屏的时候，class值为dis的显示出来，当点击a标签，导航显示出来
                var cl=document.querySelector("#run>.left1 .dis>a"); 
                cl.onclick=function(){
                    var sp=document.querySelector("#run>.left1 .dis>a>span");
                    var ul=document.querySelector("#run>.left1 ul");
                    // var left1=document.querySelector("#run>.left1 ul.dis1");
                     //console.log(ul)
                     if( sp.innerHTML=="按分类浏览"){
                        sp.innerHTML="关闭";
                        ul.className="dis2";
                     }else{
                        sp.innerHTML="按分类浏览";
                        ul.className="dis1"; 
                     }
                    
                }
                 
                
            })()
        },
        methods:{
            showClick(){
                this.showClick1.display="block";
                this.noneBtn.display="none"
            }
        }
    }
</script>

<style>
    @import url("../assets/css/evaluating.css");
</style>
