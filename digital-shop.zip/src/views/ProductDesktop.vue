<template>
    <div>
        <sm-header :active3="gender3"></sm-header>
        <div class="product font">
        <!--*************************导航***************************-->		
        		<div class="product-nav">
        			<div class="nav">
        				<router-link to="/">首页</router-link>
        				<span>&gt;</span>
        				<span>台式机</span>
        			</div>
        		</div>
        <!--******************中屏以下时出现的导航*******************-->
        		<div class="pro-nav" id="sx">
        			<div class="nav-second">
        				<a>
        					<span @click="screen()">筛选</span>
        				</a>
        				<select name="">
        					<option value="">请选择排序类型</option>
        					<option value="">按照日期排序，新品在前</option>
        					<option value="">按照价格排序，从高到低</option>
        					<option value="">按照价格排序，从低到高</option>
        				</select>
        			</div>
        		</div>
        <!--*************************内容部分************************-->
        		<div class="product-content">
        			<div class="content">
        				<!-- ---------------------内容左侧部分------------------ -->
        				<!-- 当点击“筛选”按钮，整个屏幕变灰 -->
        				<div class="dis1" id="btn2" :style="btn"></div>
        				<div :class="rightCon" id="btn1">
        					<div class="md-con">
        						<!-- 中屏显示的关闭按钮 -->
        						<div class="close1">
        							<span @click="close()" :style="x">×</span>
        						</div>
        						<div class="con-select">
        							<div class="sel-1">
        								<h4>品牌</h4>
        								<select name="">
        									<option value="">--请选择--</option>
        									<option value="">ThinkPad</option>
        									<option value="">华硕</option>
        									<option value="">外星人</option>
        									<option value="">弘基</option>
        									<option value="">惠普</option>
        									<option value="">戴尔</option>
        									<option value="">拯救者</option>
        									<option value="">炫龙</option>
        									<option value="">神州</option>
        									<option value="">联想</option>
        									<option value="">雷神</option>
        								</select>
        							</div>
        							<div class="sel-2">
        								<h4>处理器</h4>
        								<select name="">
        									<option value="">--请选择--</option>
        									<option value="">AMD</option>
        									<option value="">Intel i3</option>
        									<option value="">Intel i5</option>
        									<option value="">Intel i7</option>
        									<option value="">Intel i9</option>
        									<option value="">Intel奔腾 赛场</option>
        									<option value="">Rezen锐龙</option>
        								</select>
        							</div>
        							<div class="sel-3">
        								<h4>显卡</h4>
        								<select name="">
        									<option value="">--请选择--</option>
        									<option value="">GTX9系/7系</option>
        									<option value="">GTX1060 3G/6G</option>
        									<option value="">GTX1070 8G</option>
        									<option value="">GTX750</option>
        								</select>
        							</div>
        							<div class="sel-4">
        								<h4>屏幕尺寸</h4>
        								<select name="">
        									<option value="">--请选择--</option>
        									<option value="">11.6英寸</option>
        									<option value="">12.5英寸</option>
        									<option value="">13.3英寸</option>
        									<option value="">14.0英寸</option>
        									<option value="">15.6英寸</option>
        									<option value="">17.3英寸</option>
        								</select>
        							</div>
        							<div class="sel-5">
        								<h4>内存</h4>
        								<select name="">
        									<option value="">--请选择--</option>
        									<option value="">16G</option>
        									<option value="">32G</option>
        									<option value="">4G</option>
        									<option value="">8G</option>
        								</select>
        							</div>
        							<div class="sel-6">
        								<h4>硬盘</h4>
        								<select name="">
        									<option value="">--请选择--</option>
        									<option value="">1TB HDD</option>
        									<option value="">240GB SSD</option>
        									<option value="">256GB SSD</option>
        									<option value="">500GB HDD</option>
        									<option value="">512GB SSD</option>
        								</select>
        							</div>
        							<div class="sel-7">
        								<h4>价格</h4>
                                        <!-- 引入滑块效果搜索效果 -->
        							    <shopMove></shopMove>
        							</div>
        						</div>
        					</div>
        				</div>
        <!--************************右侧部分********************************-->
        				<div class="ple-con">
        					<ul>
                                <span class="con1">
                                    <li>
                                    	<div class="">
                                    		<router-link :to="`/desktop/detail/${deList[6].href.split('=')[1]}`" title="惠普（HP）暗影精灵23代 游戏台式电脑主机"><img :src="deImg[6]"/></router-link>
                                    	</div>
                                    	<div class="con">
                                    		<router-link :to="`/desktop/detail/${deList[6].href.split('=')[1]}`" v-text="deList[6].title"></router-link>
                                    		<p><span v-cloak>¥{{deList[6].price}}</span></p>
                                    	</div>
                                    </li>
                                    <li>
                                    	<div class="">
                                    		<router-link :to="`/desktop/detail/${deList[7].href.split('=')[1]}`" title=" 惠普（HP）暗影精灵3代 游戏台式电脑主机（i7-8700 16G高频 1T+256GSSD GTX1060 6G独显 三年上门）"><img :src="deImg[7]"/></router-link>
                                    	</div>
                                    	<div class="con">
                                    		<router-link :to="`/desktop/detail/${deList[7].href.split('=')[1]}`" v-text="deList[7].title"></router-link>
                                    		<p><span v-cloak>{{deList[7].price}}</span></p>
                                    	</div>
                                    </li>
                                </span>
                                <span class="con2">
                                    <li>
                                    	<div class="">
                                    		<router-link :to="`/desktop/detail/${deList[8].href.split('=')[1]}`" title="宏碁（Acer）商祺SQX4270 140N 商用办公台式电脑主机"><img :src="deImg[8]"/></router-link>
                                    	</div>
                                    	<div class="con">
                                    		<router-link :to="`/desktop/detail/${deList[8].href.split('=')[1]}`" v-text="deList[8].title"></router-link>
                                    		<p><span v-cloak>{{deList[8].price}}</span></p>
                                    	</div>
                                    </li>
                                    <li>
                                    	<div class="">
                                    		<router-link :to="`/desktop/detail/${deList[9].href.split('=')[1]}`" title="联想（Lenovo）天逸510S 第八代英特尔酷睿i3 个人商务台式电脑主机"><img :src="deImg[9]"/></router-link>
                                    	</div>
                                    	<div class="con">
                                    		<router-link :to="`/desktop/detail/${deList[9].href.split('=')[1]}`" v-text="deList[9].title"></router-link>
                                    		<p><span v-cloak>{{deList[9].price}}</span></p>
                                    	</div>
                                    </li>
                                </span>
                                <span class="con3">
                                    <li>
                                    	<div class="">
                                    		<router-link :to="`/desktop/detail/${deList[10].href.split('=')[1]}`" title="1戴尔(DELL)灵越3670台式电脑主机"><img :src="deImg[10]"/></router-link>
                                    	</div>
                                    	<div class="con">
                                    		<router-link :to="`/desktop/detail/${deList[10].href.split('=')[1]}`" v-text="deList[10].title"></router-link>
                                    		<p><span v-cloak>{{deList[10].price}}</span></p>
                                    	</div>
                                    </li>
                                    <li>
                                    	<div class="">
                                    		<router-link :to="`/desktop/detail/${deList[11].href.split('=')[1]}`" title="惠普（HP）暗影精灵3代 游戏台式电脑主机（i5-8400 16G高频 1T+128GSSD GTX1060 6G独显 三年上门）"><img :src="deImg[11]"/></router-link>
                                    	</div>
                                    	<div class="con">
                                    		<router-link :to="`/desktop/detail/${deList[11].href.split('=')[1]}`" v-text="deList[11].title"></router-link>
                                    		<p><span v-cloak>{{deList[11].price}}</span></p>
                                    	</div>
                                    </li>
                                </span>
        					</ul>
        				</div>
        			</div>
        		</div>
        	</div>
        <sm-footer></sm-footer>
    </div>
</template>

<script>
    // 引入子组件
    import ShopMove from '../components/ShopMove'
    export default{
        data(){
            return{
                x:{display:"none"},
                btn:{display:"none"},
                rightCon:{
                   riCon:true,
                   riCon1:false
                },
				deList:[
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					{href:""},
					],
				deImg:[],
				gender3:3
            }
        },
		props:["family_ids"],
		created() {
			this.load()
		},
        methods:{
			load(){
				var url='/index'
				this.axios.get(url).then(result=>{
				    this.deList=result.data;
				    for(var i=0;i<this.deList.length;i++){
				        this.deImg.push(require("../assets/"+this.deList[i].pic))
				    }
				})
			},
            screen(){
                this.x.display="block";
                this.btn.display="block";
                this.rightCon={
                   riCon:false,
                   riCon1:true 
                }
            },
            close(){
               this.x.display="none";
               this.btn.display="none";
               this.rightCon={
                  riCon:true,
                  riCon1:false 
               } 
            },
           
        },
        components:{
            "shopMove":ShopMove
        }
        
    }
</script>

<style>
    @import url("../assets/css/product.css");
</style>
