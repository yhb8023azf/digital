<template>
    <div>
        <sm-header :active6="gender6"></sm-header>
        <div class="after-sales font">
        	<div class="service-nav">
        		<div class="snav">
        			<router-link to="/">首页</router-link>
        			<span>&gt;</span>
        			<span>售后服务</span>
        		</div>
        	</div>
        	<div class="service-content">
        		<div class="contenter">
        			<div class="content1">
        				<p>售后服务</p>
        			</div>
        			<div class="content2">
        				<p class="p1">一、“三包”服务承诺</p>
        				<p>以任何方式进入起飞页网站即表示您同意自己已经与起飞页订立本条款，且您将受本条款的条件约束。条款的解释权归起飞页所有。您应在第一次登录后仔细阅读修订后的“条款”，并有权选择停止继续使用“服务”；一旦您继续使用“服务”， 则表示您已接受经修订的“条款”，当您与起飞页发生争议时，应以最新的服务条款为准。除另行明确声明外，任何使“服务”范围扩大或功能增强的新内容均受本条款约束。</p>
        			</div>
        			<div class="content3">
        				<p class="p1">二、维修服务方式</p>
        				<p>以任何方式进入起飞页网站即表示您同意自己已经与起飞页订立本条款，且您将受本条款的条件约束。条款的解释权归起飞页所有。您应在第一次登录后仔细阅读修订后的“条款”，并有权选择停止继续使用“服务”；一旦您继续使用“服务”， 则表示您已接受经修订的“条款”，当您与起飞页发生争议时，应以最新的服务条款为准。除另行明确声明外，任何使“服务”范围扩大或功能增强的新内容均受本条款约束。</p>
        			</div>
        			<div class="content4">
        				<p class="p1">三、保修期及上门期</p>
        				<p>以任何方式进入起飞页网站即表示您同意自己已经与起飞页订立本条款，且您将受本条款的条件约束。条款的解释权归起飞页所有。您应在第一次登录后仔细阅读修订后的“条款”，并有权选择停止继续使用“服务”；一旦您继续使用“服务”， 则表示您已接受经修订的“条款”，当您与起飞页发生争议时，应以最新的服务条款为准。除另行明确声明外，任何使“服务”范围扩大或功能增强的新内容均受本条款约束。</p>
        			</div>
        			<div class="content5">
        				<p class="p1">四、软件维修服务</p>
        				<p>以任何方式进入起飞页网站即表示您同意自己已经与起飞页订立本条款，且您将受本条款的条件约束。条款的解释权归起飞页所有。您应在第一次登录后仔细阅读修订后的“条款”，并有权选择停止继续使用“服务”；一旦您继续使用“服务”， 则表示您已接受经修订的“条款”，当您与起飞页发生争议时，应以最新的服务条款为准。除另行明确声明外，任何使“服务”范围扩大或功能增强的新内容均受本条款约束。</p>
        			</div>
        			<div class="content6">
        				<p class="p1">五、数据备份</p>
        				<p>以任何方式进入起飞页网站即表示您同意自己已经与起飞页订立本条款，且您将受本条款的条件约束。条款的解释权归起飞页所有。您应在第一次登录后仔细阅读修订后的“条款”，并有权选择停止继续使用“服务”；一旦您继续使用“服务”， 则表示您已接受经修订的“条款”，当您与起飞页发生争议时，应以最新的服务条款为准。除另行明确声明外，任何使“服务”范围扩大或功能增强的新内容均受本条款约束。</p>
        			</div>
        		</div>
        	</div>
        </div>
        <sm-footer></sm-footer>
    </div>
</template>

<script>
    export default{
        data(){
            return{
               gender6:6 
            }
        },
        methods:{
            
        }
    }
</script>

<style scoped>
   *{margin:0px;padding:0px;}
   body{
   	background:#f2f2f2;
   	box-sizing:border-box;
   }
   .font{
       word-spacing: normal;
       font-family: "微软雅黑",Helvetica,Arial,Verdana,sans-serif;
       font-style: normal;
       font-weight: normal;
       font-size:14px;
   }
   a{
   	text-decoration:none;
   }
    .after-sales .service-nav{
    	background:#fff;
    	height:auto;width:100%;
    }
    .after-sales .service-content .p1{
        font-weight: 700;
        font-size: 15px;
        line-height: 1.5em;
    }
    .service-nav .snav{margin-bottom:20px;text-align:left;}
    .service-nav .snav a,.service-nav .snav span{
    	color: #757575;
        font-size:14px;
        }
    /*大屏*/
    @media only screen and (min-width:992px) {
    .after-sales .snav{
    	padding-left:8%;
    	padding-right:8%;
    	padding-top:20px;
    	padding-bottom:20px;
    	}
    }
    /*中屏*/
    @media only screen and (max-width:991px) {
    .after-sales .snav{
    	padding-left:8%;
    	padding-right:8%;
    	padding-top:10px;
    	padding-bottom:10px;
    	}
    }
    /*小屏*/
    @media only screen and (max-width:576px) {
    .after-sales .snav{
    	padding-left:10px;
    	padding-right:10px;
    	}
    }
    /*售后服务*******************************************************************************************************************/
    .service-content{width:100%}
    .service-content .contenter{
    	background:#fff;
    	margin-bottom:80px;
    }
    .service-content div{
    	padding-left:10px;
    	padding-right:10px;
    }
    .contenter .content1 p{
        font-size: 26px;
        color: #333333;
        text-align:center;
        padding:40px 0px 10px !important;
    }
    .contenter p:first-child{
    	font-weight:bold;
    	padding:30px 0px;
    }
    .content6 p:last-child{
    	padding-bottom:30px;
    }
    /*大屏*/
    @media only screen and (min-width:992px) {
    .service-content .contenter{
    	margin-left:8%;
    	margin-right:8%;
    }
    }
    /*中屏*/
    @media only screen and (max-width:991px) {
    .service-content .contenter{
    	margin-left:8%;
    	margin-right:8%;
    }
    }
    /*小屏*/
    @media only screen and (max-width:576px) {
    	.service-content .contenter{
    	margin-left:10px;
    	margin-right:10px;
    }
    }
    
</style>
