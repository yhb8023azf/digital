<template>
    <div>
       <div class="register">
           <div class="reg-con">
               <div class="r-container">
               	<div class="text-center1">
               		<img src="../assets/img/headfoot/login1.png" class="img2">
               	</div>
               	<div class="text-center1 h">
               		<h3>一个账号，玩转所有官方服务！</h3>				
               	</div>
               	<div class="text-center1">
               		<form action="" method="post" class="form-group1">
               			<div class="form-inline1">
               				<input type="text" placeholder="昵称" class="form-control1">
               			</div>
               			<div class="form-inline1">
               				<input type="text" placeholder="手机号" class="form-control1">
               			</div>
               			<div class="form-inline1 regBtn">
                                   <input type="text"  class="form-control2 getBtn1" placeholder="请输入验证码">
                                   <span>
                                   <button type="button" class="getBtn2">获取</button>                         </span>		
               			</div>
               			<div class="form-inline1">
               				<input type="password" placeholder="密码" class="form-control1">
               			</div>
               			<div class="form-inline1">
               				<input type="password"  placeholder="确认密码" class="form-control1">
               			</div>
               			<div class="bor1">
               				<input type="checkbox" id="agree"><label for="agree">我同意《用户手册》和《保密条款》</label>
               			</div>
               			<div class="text-center1">
               				<button class="bg-success1" @click="doReg">注册</button>
               			</div>
               			<div class="text-center1">
               				<button class="bg-light1" @click="goLog">已经有账号了？请登录</button>
               			</div>
               			<div class="rpl-0">
               				<span>第三方账号登陆：</span>
               				<a href="#">
               					<img src="../assets/img/headfoot/qq.png" class="img-qq1">
               				</a>
               			</div>
               		</form>
               	</div>
               	<div class="reg-font">
               		<p>用户登录注册说明：</p>
               		<p>1. 演示模板不支持注册，实际使用短信验证码需单独购买<span style="color:rgb(44,130,201)">短信资源包</span>。</p>
               		<p>2. 演示用户名：yanghongbin，密码：123456。</p>	
               	</div>
               </div>
           </div>
       </div>
        
    </div>
</template>

<script>
    export default{
        data(){
            return{
                
            }
        },
        methods:{
            goLog(){
                this.$router.push("/login")
            },
            // doReg(){
                
            // }
        }
    }
</script>

<style scoped>
        a{text-decoration:none;}
        button{cursor:pointer;outline:none;}
        input{outline:none;}
        .register{width:100%;background-color:#f5f5f5 !important;}
        .register .r-container{text-align:center;}
        .text-center1 .img2{
            margin-top:40px;
        	vertical-align: middle;
            max-width: 100%;
            width: auto;
            height: auto;
        }
        /* 输入框 */
        .form-group1{display:block; width:100%;}
        .form-group1 .form-control1,.form-control2,.regBtn .getBtn1{
            padding:13px 0px 13px 8px;
            border:1px solid #ddd !important;
            box-shadow: inset 0 -1px 4px #eee!important;
        }
        .form-group1>.form-inline1{margin-bottom:10px;}
        @media only screen and (min-width:992px){
            .register .r-container{margin-top:20px;}
            .register>.reg-con{
                padding-left:9%;
                padding-right:9%;
            }
            .register>.reg-con .text-center1 h3{
                font-size: 26px;
                font-weight: normal;
                font-style: normal;
                color: #000000;
                margin:25px 0px;
            } 
        }
        @media only screen and (max-width:991px){
            .register .r-container{margin-top:0px;}
            .register>.reg-con{
                padding-left:7%;
                padding-right:7%;
            }
            .register>.reg-con .text-center1 h3{
                font-size: 16px;
                margin:20px 0px;
            }
        }
        @media only screen and (max-width:576px){
            .register>.reg-con{
                padding-left:15px;
                padding-right:15px;
            }
        }
        
        /* 手机号码和密码框 */
        @media only screen and (min-width:576px) {
        	.form-group1 .form-control1,.bor1,.bg-success1,.bg-light1{
        		width:345px;
        	}
            .regBtn .getBtn2{width:67px;}
            .regBtn .getBtn1{width:278px;}
        	.bor1{margin:auto;}
        	.bor1 input{margin-left:-65px;}
        	.rpl-0{margin-left:-205px;
        		font-size:15px;
        		margin-top:15px;
        		color:#777;
        	}
        }
        @media only screen and (max-width:575px) {
        	.form-group1 .form-control1,.bg-success1,.bg-light1{width:97.4%!important;}
            .regBtn .getBtn1{width:82% !important;}
            .regBtn .getBtn2{width:15% !important;}
        	.bor1,.rpl-0{text-align:left;}
            .rpl-0{margin-top:8px;}
        }
        /* 获取按钮 */
        .regBtn .getBtn2{
            width:67px;
            background:#00eef3;
            margin-left:-5px;
            border-width:0px;
            text-align:center;
            font-size:15px;
            padding:14px 0px;
            border-top-right-radius:5px;
            border-bottom-right-radius:5px;
        }
        .regBtn .getBtn1{
            border-width:0px;font-size:15px;
            border-top-left-radius:5px;
            border-bottom-left-radius:5px;
            }
        /* 同意选项 */
        .bor1{
            border-bottom:1px solid #ddd;
        	border-top:1px solid #ddd;
        	margin-top:10px !important;
        	padding-top:12px;
        	padding-bottom:12px;
        }
        .bor1 label{
            margin-left:8px;
        	color:#aaa;
        }
        /* 按钮 */
        .form-group1 .form-control1,.bg-success1,.bg-light1{
            border-width:0px;
            border-radius:5px;
            font-size:16px;
        }
        .bg-success1{
            background-color:#00eef3;
            margin-bottom:10px;
            color: #000000;
        }
        .bg-success1,.bg-light1{height:40px;line-height:40px;}
        /* 第三方登录 */
        .rpl-0 .img-qq1{
            width:20px;height:20px;
            
        }
        .reg-font{
            font-size:14px;
        	color:#666;
            text-align:left;
            margin-top:20px;
        }
        .reg-font p{line-height:20px;}
</style>
